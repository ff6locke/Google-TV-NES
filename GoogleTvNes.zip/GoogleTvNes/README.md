# NES for Google TV（Android TV）

纯 Java 的 NES 模拟器 + Android TV 外壳。用 Android Studio 打开本目录即可编译（AGP 8.5.2 / Gradle 8.7，minSdk 24）。

## 满足的需求
| 需求 | 实现 |
|---|---|
| Mapper 16 / DBZ1 | `Mappers.java` 里的 `BandaiFcg`：FCG-1/2（$6000 窗口）与 LZ93D50（$8000 窗口）都支持，CPU 周期计数 IRQ，24C02 EEPROM（mapper 159 为 24C01）。另外支持 mapper 0/1/2/3/4/7。 |
| 写 ROM 存档 | EEPROM / 电池 RAM 变化后约 0.5 秒自动写入 `<游戏名>.sav`，暂停、退出、切后台时强制写入；菜单里有 "Save now"。 |
| 选择存档目录 | 主界面 "Save folder"：系统文件选择器（SAF，持久授权）；设备没有系统选择器时自动改用内置浏览器。未设置时用应用私有目录。 |
| 对话框不抖动 | CPU 每个总线周期推进 PPU 3 个点，PPU 逐点渲染（loopy 寄存器、取指流水线、精灵求值），IRQ 与 NMI 按硬件的一周期延迟采样。核心自测里验证了 IRQ 分屏在每一帧都落在同一行。 |
| 视频 ≥ 60 fps | 独立渲染线程 + SurfaceView 硬件画布，`Surface.setFrameRate(60)` 提示 TV 切到 60Hz；暂停菜单里可开 FPS 叠加显示；按住 R1/R2 快进。 |
| 音频不延迟 | 48 kHz 单声道 AudioTrack，LOW_LATENCY 模式，缓冲约 50 ms，只在检测到欠载（underrun）后才增大；音频阻塞写入作为时钟，音画同步。 |

## 操作
- 手柄：方向键/摇杆；`B`(右键)/`Y` = NES A；`A`(下键)/`X` = NES B；Start / Select；R1/R2 快进；Xbox 键或 L3 或遥控器 Back = 暂停菜单。
- 遥控器：方向键 + OK(=A)；菜单里有 "Press START / SELECT"。
- 键盘：方向键、Z=B、X=A、Enter=Start、右 Shift=Select。

## 核心自测（不需要 ROM）
```
java -m jdk.compiler/com.sun.tools.javac.Main -d /tmp/out app/src/main/java/com/example/nestv/core/*.java core-test/CoreTest.java
java -cp /tmp/out com.example.nestv.core.CoreTest
```
覆盖：6502 指令、24C01/24C02 读写、Bandai IRQ 时序、PPU 渲染、帧长 29780.5 周期、mapper 16 IRQ 分屏逐帧稳定、APU 音高与采样率。

## 已知限制（请如实了解）
- 我没有 DBZ1 的 ROM，也没有在真机上运行过 Android 部分；核心是用合成 ROM 验证的。第一次在设备上测试时如发现问题请告诉我日志/现象。
- 仅 NTSC 时序（PAL ROM 会按 NTSC 运行）；不支持 PAL、VS、NSF、金手指、存档状态（save state）。
- 屏幕色彩强调（emphasis）为近似实现；未实现 PPU 的 $2007 渲染期间的怪异行为。

## 新增功能（第二版）
- **屏幕按键**：半透明，可调透明度（10–100%，默认 35%）和大小；暂停菜单 → On-screen buttons → Move buttons 进入编辑，可用手指拖动，也可用遥控器方向键移动、OK 切换下一个按键、Back 完成；位置会保存。
- **即时存档**：10 个槽位（菜单 Save state / Load state，手柄 L1 快存、L2 快读），文件 `<游戏名>.ss1`…`.ss10` 保存在你选的存档目录。
- **快进**：手柄 R1 按住、R2 切换，屏幕上 >> 键切换；速度 2x / 3x / 4x / Max 可选；快进时静音，恢复后自动清空音频缓冲。
- **复古电视效果**：Scanlines（轻/强）、光栅栅格 mask、暗角 vignette，另有 smooth/sharp 与画面比例。

## 用 GitHub Actions 在线编译（不需要电脑）
1. 在 GitHub 新建一个仓库，用手机浏览器（桌面版网站）打开仓库页面 → Add file → Upload files，把 `GoogleTvNes.zip` 直接上传提交（不用解压，工作流会自己解压）。
   工作流文件在 zip 里的 `.github/workflows/build.yml`；如果你只上传 zip，需要再单独创建一次这个文件：Add file → Create new file，文件名输入 `.github/workflows/build.yml`，粘贴内容。
2. 进入 Actions 标签页，等 "Build APK" 跑完（约 5–8 分钟）。
3. 点进这次运行，页面底部 Artifacts 里下载 `NES-for-Google-TV-apk`（zip，里面是 app-debug.apk）。
4. 把 apk 传到 Google TV（例如 "Send Files to TV" 应用，或放网盘用 TV 浏览器/Downloader 下载），安装时允许"未知来源"。

## 手机支持
- 同一个 APK 同时支持手机/平板和 Google TV；手机上桌面图标是普通启动器图标。
- 竖屏：画面在上方，按键在下半屏；横屏：按键叠在画面两侧。两种方向的按键位置分别保存，可分别用 Move buttons 调整。
- 菜单（On-screen buttons）可设置透明度、大小、按下震动；Video 里可选择屏幕旋转：自动 / 锁定横屏 / 锁定竖屏。
- 屏幕按键默认在有触摸屏的设备上显示；接上蓝牙手柄后会自动隐藏。左上角 II 键打开菜单，系统返回手势同样打开菜单。

## 遥控器 / 手柄按键映射（第三版）
- 暂停菜单 → Controller / remote mapping：选一个 NES 按键（上下左右、A、B、Start、Select、快进、菜单、快速存档/读档），再按遥控器或手柄上你想用的键即可；可重复映射多个键，Reset 恢复默认。
- G60S Pro 这类遥控器：方向键、OK(=A) 默认可用；遥控器没有 B 键，请在映射里把 B 设成音量+ 或其他你顺手的键；快进可映射成"Fast forward (toggle)"。
- 如果遥控器处于"鼠标模式"，请在 On-screen buttons 里把显示方式设为 always，就可以用鼠标指针点屏幕按键。
- 快进：主菜单第一项直接开/关快进，速度可在菜单里切换（2x/3x/4x/max）；叠加层会显示实际倍速（real x.x），如果电视盒子性能不够，实际倍速会低于设定值。

## Bandai（DBZ 等）EEPROM
- 很多旧 dump 把 24C01 游戏标成 mapper 16。现在 mapper 16 的 EEPROM 芯片类型在运行时自动识别（24C01 / 24C02），存档文件大小分别为 128 / 256 字节。
- 打开 Video / CRT → FPS / debug overlay，会多显示一行 Bandai 诊断信息（寄存器写入数、IRQ 次数、EEPROM 类型和访问次数）。

## 第四版：多点触控与快进
- 快进档位：2x / 3x / 4x / 6x / 8x / 12x / 16x / max。快进时只绘制部分画面（其余帧逻辑完全照常运行，精灵 0 碰撞判定也保持精确），headless 测试中提速约 50%。
- 触摸屏同时按下的手指数量没有软件上限。如果按第三个键时所有按键都松开，通常是手机的三指手势（三指截屏/下滑）取消了触摸，或屏幕硬件只支持两点触控。
  打开 FPS / debug overlay，最下面一行会显示"同时最多几根手指"和"被系统取消的次数"，可以据此判断。
  解决办法：到手机设置里关闭"三指截屏/三指手势"；也可以把 A、B 键用 Move buttons 拖到一起，用一根拇指同时按两个键。

## 覆盖安装（不用卸载）
- 现在每次编译都用同一把固定签名密钥（`app/stable.keystore`），versionCode 每次自动递增，所以新 APK 可以直接覆盖安装。
- 从旧版（随机签名）升级到这一版需要最后卸载一次；之后就都能直接覆盖。
- 请始终使用压缩包里的这个 `stable.keystore`，不要删掉或重新生成，否则签名又会变。
- 卸载会清掉应用私有目录里的存档：如果你在 Save folder 里选的是共享存储中的自定义文件夹，存档不会丢。

## 遥控器一次只能发一个键
- 蓝牙/2.4G 电视遥控器的硬件一次只会发出一个按键，按第二个键时第一个会被"松开"，这是遥控器本身的限制，App 无法改变。
- 为此新增了可映射的动作（菜单 → Controller / remote mapping）：A+B 同时按、Turbo A / Turbo B（连发）、Hold-toggle（按一下锁住，再按一下松开）。
  例：把 Hold-toggle B 设成一个键，开着它就等于一直按住 B（跑步），再用方向键 + OK(A) 操作；屏幕左下角会显示 HOLD: B。
- 最稳妥的做法仍然是用蓝牙手柄。
