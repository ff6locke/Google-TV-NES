# NES for Google TV（Android TV）

纯 Java 的 NES 模拟器 + Android TV 外壳。用 Android Studio 打开本目录即可编译（AGP 8.5.2 / Gradle 8.7，minSdk 24）。

## 满足的需求
| 需求 | 实现 |
|---|---|
| Mapper 16 / DBZ1 | `Mappers.java` 里的 `BandaiFcg`：FCG-1/2（$6000 窗口）与 LZ93D50（$8000 窗口）都支持，CPU 周期计数 IRQ，24C02 EEPROM（mapper 159 为 24C01）。另外支持 mapper 0/1/2/3/4/7。 |
| 写 ROM 存档 | EEPROM / 电池 RAM 变化后约 0.5 秒自动写入 `<游戏名>.sav`，暂停、退出、切后台时强制写入；菜单里有 "Save now"。 |
| 选择存档目录 | 主界面 "Save folder"：系统文件选择器（SAF，持久授权）；设备没有系统选择器时自动改用内置浏览器。未设置时用应用私有目录。 |
| 对话框不抖动 | CPU 每个总线周期推进 PPU 3 个点，PPU 逐点渲染（loopy 寄存器、取指流水线、精灵求值），IRQ 与 NMI 按硬件的一周期延迟采样。核心自测里验证了 IRQ 分屏在每一帧都落在同一行。 |
| 视频 ≥ 60 fps | 独立渲染线程 + SurfaceView 硬件画布，`Surface.setFrameRate(60)` 提示 TV 切到 60Hz；暂停菜单里可开 FPS 叠加显示；按住 R1/R2 快进。 |
| 音频不延迟 | 48 kHz 单声道 AudioTrack，LOW_LATENCY 模式，缓冲约 50 ms，只在检测到欠载（underrun）后才增大；音频阻塞写入作为时钟，音画同步。 |

## 操作
- 手柄：方向键/摇杆；`B`(右键)/`Y` = NES A；`A`(下键)/`X` = NES B；Start / Select；R1/R2 快进；Xbox 键或 L3 或遥控器 Back = 暂停菜单。
- 遥控器：方向键 + OK(=A)；菜单里有 "Press START / SELECT"。
- 键盘：方向键、Z=B、X=A、Enter=Start、右 Shift=Select。

## 核心自测（不需要 ROM）
```
java -m jdk.compiler/com.sun.tools.javac.Main -d /tmp/out app/src/main/java/com/example/nestv/core/*.java core-test/CoreTest.java
java -cp /tmp/out com.example.nestv.core.CoreTest
```
覆盖：6502 指令、24C01/24C02 读写、Bandai IRQ 时序、PPU 渲染、帧长 29780.5 周期、mapper 16 IRQ 分屏逐帧稳定、APU 音高与采样率。

## 已知限制（请如实了解）
- 我没有 DBZ1 的 ROM，也没有在真机上运行过 Android 部分；核心是用合成 ROM 验证的。第一次在设备上测试时如发现问题请告诉我日志/现象。
- 仅 NTSC 时序（PAL ROM 会按 NTSC 运行）；不支持 PAL、VS、NSF、金手指、存档状态（save state）。
- 屏幕色彩强调（emphasis）为近似实现；未实现 PPU 的 $2007 渲染期间的怪异行为。
