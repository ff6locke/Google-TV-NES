package com.example.nestv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.nestv.core.Nes;
import com.example.nestv.core.Ppu;

import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class EmuActivity extends Activity implements SurfaceHolder.Callback {
    static final String EXTRA_ROM = "rom", EXTRA_NAME = "name", EXTRA_SAVE_DIR = "saveDir";
    private static final int SAMPLE_RATE = 48000;
    private static final long FRAME_NANOS = 16639267L; // NTSC 60.0988 Hz
    private static final int[] FF_SPEEDS = {2, 3, 4, 6, 8, 12, 16, 0};   // 0 = as fast as possible
    private static final int[] OPACITIES = {10, 20, 30, 40, 50, 60, 80, 100};
    private static final float[] SIZES = {0.7f, 0.85f, 1f, 1.2f, 1.4f};
    private static final int P_MAIN = 0, P_VIDEO = 1, P_CTRL = 2, P_FF = 3, P_SAVE = 4, P_LOAD = 5, P_MAP = 6;
    private static final int ACT_FF_HOLD = 1001, ACT_FF_TOGGLE = 1002, ACT_MENU = 1003, ACT_QSAVE = 1004, ACT_QLOAD = 1005,
            ACT_AB = 1006, ACT_TURBO_A = 1007, ACT_TURBO_B = 1008, ACT_LATCH = 2000;   // ACT_LATCH + button bit = hold-toggle
    private static final int[] MAP_ACTIONS = {Nes.BTN_UP, Nes.BTN_DOWN, Nes.BTN_LEFT, Nes.BTN_RIGHT, Nes.BTN_A, Nes.BTN_B,
            Nes.BTN_START, Nes.BTN_SELECT, ACT_FF_HOLD, ACT_FF_TOGGLE, ACT_MENU, ACT_QSAVE, ACT_QLOAD,
            ACT_AB, ACT_TURBO_A, ACT_TURBO_B,
            ACT_LATCH + Nes.BTN_RIGHT, ACT_LATCH + Nes.BTN_LEFT, ACT_LATCH + Nes.BTN_UP, ACT_LATCH + Nes.BTN_DOWN,
            ACT_LATCH + Nes.BTN_B, ACT_LATCH + Nes.BTN_A};
    private static final String[] MAP_NAMES = {"D-pad Up", "D-pad Down", "D-pad Left", "D-pad Right", "A button", "B button",
            "START", "SELECT", "Fast forward (hold)", "Fast forward (toggle)", "Open menu", "Quick save", "Quick load",
            "A + B together", "Turbo A (autofire)", "Turbo B (autofire)",
            "Hold-toggle Right", "Hold-toggle Left", "Hold-toggle Up", "Hold-toggle Down", "Hold-toggle B", "Hold-toggle A"};

    private SurfaceView surfaceView;
    private TextView loadingView;
    private TouchControlsView controls;
    private SharedPreferences prefs;
    private String romLoc, romName, saveDir, saveFile;
    private byte[] romBytes;

    private volatile Nes nes;
    private EmuThread emu;
    private volatile Renderer renderer;
    private AudioOut audio;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Set<String> usedNames = Collections.synchronizedSet(new HashSet<String>());

    // input
    private volatile int keyBits, axisBits, tapBits, touchBits, latchBits, turboBits;
    private int padFrame;
    private volatile boolean fastHold, fastToggle;
    private boolean gamepadSeen;

    // options (persisted)
    private volatile boolean showFps, smooth, mask, vignette;
    private volatile int aspectMode;      // 0 = 4:3, 1 = 8:7, 2 = stretch
    private volatile int scanlines;       // 0 off, 1 light, 2 strong
    private volatile int ffIdx;
    private int ctlMode, ctlAlpha, sizeIdx, curSlot, orient;
    private boolean haptics;

    private volatile float emuFps;
    private volatile int savedGen;

    private boolean resumed, menuShowing, editing;
    private int opBusy;
    private int nextPage = -1, currentPage = P_MAIN, pendingTap, pendingCapture;
    private final java.util.HashMap<Integer, Integer> customKeys = new java.util.HashMap<>();

    // ---- lifecycle -------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        prefs = getSharedPreferences("nestv", MODE_PRIVATE);
        aspectMode = prefs.getInt("aspect", 0);
        smooth = prefs.getBoolean("smooth", true);
        showFps = prefs.getBoolean("fps", false);
        scanlines = prefs.getInt("scanlines", 0);
        mask = prefs.getBoolean("mask", false);
        vignette = prefs.getBoolean("vignette", false);
        ffIdx = prefs.getInt("ffIdx", 0);
        ctlMode = prefs.getInt("ctlMode", 0);
        ctlAlpha = prefs.getInt("ctlAlpha", 35);
        sizeIdx = prefs.getInt("ctlSize", 2);
        curSlot = prefs.getInt("slot", 1);
        orient = prefs.getInt("orient", 0);
        haptics = prefs.getBoolean("haptics", true);
        applyOrientation();
        loadKeymap();

        romLoc = getIntent().getStringExtra(EXTRA_ROM);
        romName = getIntent().getStringExtra(EXTRA_NAME);
        saveDir = getIntent().getStringExtra(EXTRA_SAVE_DIR);
        if (romName == null) romName = "game.nes";
        saveFile = Storage.saveFileName(romName);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        surfaceView = new SurfaceView(this);
        surfaceView.getHolder().addCallback(this);
        root.addView(surfaceView, new FrameLayout.LayoutParams(-1, -1));

        controls = new TouchControlsView(this);
        controls.loadLayout(prefs);
        controls.setAlphaPct(ctlAlpha);
        controls.setScale(SIZES[sizeIdx]);
        controls.setHaptics(haptics);
        controls.setListener(new TouchControlsView.Listener() {
            @Override public void onPad(int bits) { touchBits = bits; }
            @Override public void onFastForwardToggle() { toggleFast(); }
            @Override public void onMenu() { showMenu(); }
            @Override public void onLayoutChanged() { controls.saveLayout(prefs); }
            @Override public void onEditDone() { finishEdit(); }
        });
        root.addView(controls, new FrameLayout.LayoutParams(-1, -1));
        if (Build.VERSION.SDK_INT >= 29) {
            controls.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) ->
                    controls.setSystemGestureExclusionRects(Collections.singletonList(new Rect(0, 0, r - l, b - t))));
        }
        applyControlsVisibility();

        loadingView = new TextView(this);
        loadingView.setText("Loading...");
        loadingView.setTextColor(Color.WHITE);
        loadingView.setTextSize(24);
        root.addView(loadingView, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setContentView(root);
        hideSystemUi();

        new Thread(() -> {
            try {
                byte[] rom = Storage.readAll(this, romLoc);
                byte[] save = Storage.readSave(this, saveDir, saveFile);
                Nes n = new Nes(rom, SAMPLE_RATE);
                if (save != null) n.loadSave(save);
                final int gen = n.saveGeneration();
                ui.post(() -> {
                    romBytes = rom;
                    savedGen = gen;
                    nes = n;
                    Log.i("NesTv", "ROM: " + n.cart);
                    Toast.makeText(this, n.cart.toString(), Toast.LENGTH_LONG).show();
                    loadingView.setVisibility(View.GONE);
                    startEmulation();
                });
            } catch (Throwable e) {
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> {
                    Toast.makeText(this, "Cannot start ROM: " + msg, Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        }, "rom-loader").start();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        hideSystemUi();
        updateRun();
    }

    @Override
    protected void onPause() {
        resumed = false;
        keyBits = 0;
        axisBits = 0;
        touchBits = 0;
        if (editing) finishEdit();
        updateRun();            // waits until the emulation thread is parked
        flushSaveBlocking();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        EmuThread t = emu;
        if (t != null) {
            t.quit = true;
            synchronized (t) { t.notifyAll(); }
            try { t.join(1500); } catch (InterruptedException ignored) { }
        }
        if (audio != null) audio.release();
        io.shutdown();
        super.onDestroy();
    }

    private void startEmulation() {
        if (emu != null || nes == null) return;
        audio = new AudioOut();
        audio.init();
        emu = new EmuThread();
        emu.start();
        updateRun();
    }

    private void updateRun() {
        EmuThread t = emu;
        if (t != null) t.setPaused(!(resumed && !menuShowing && !editing && opBusy == 0 && nes != null));
    }

    private void toast(final String s) {
        ui.post(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
    }

    // ---- surface ---------------------------------------------------------------------------------

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                holder.getSurface().setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
            } catch (Throwable ignored) { }
        }
        if (renderer == null) {
            Renderer r = new Renderer(holder);
            renderer = r;
            r.start();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) { }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Renderer r = renderer;
        renderer = null;
        if (r != null) {
            r.shutdown();
            try { r.join(1000); } catch (InterruptedException ignored) { }
        }
    }

    // ---- input -----------------------------------------------------------------------------------

    private static int mapKey(int kc) {
        switch (kc) {
            case KeyEvent.KEYCODE_DPAD_UP: return Nes.BTN_UP;
            case KeyEvent.KEYCODE_DPAD_DOWN: return Nes.BTN_DOWN;
            case KeyEvent.KEYCODE_DPAD_LEFT: return Nes.BTN_LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return Nes.BTN_RIGHT;
            case KeyEvent.KEYCODE_DPAD_CENTER:       // TV remote OK button
            case KeyEvent.KEYCODE_BUTTON_B:
            case KeyEvent.KEYCODE_BUTTON_Y:
            case KeyEvent.KEYCODE_X:
                return Nes.BTN_A;
            case KeyEvent.KEYCODE_BUTTON_A:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_Z:
                return Nes.BTN_B;
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                return Nes.BTN_START;
            case KeyEvent.KEYCODE_BUTTON_SELECT:
            case KeyEvent.KEYCODE_SHIFT_RIGHT:
            case KeyEvent.KEYCODE_DEL:
            case KeyEvent.KEYCODE_MENU:
                return Nes.BTN_SELECT;
            default: return 0;
        }
    }

    private int currentPad() {
        int p = keyBits | axisBits | tapBits | touchBits | latchBits;
        padFrame++;
        if (turboBits != 0 && ((padFrame >> 1) & 1) == 0) p |= turboBits;      // autofire ~15 Hz
        if ((p & (Nes.BTN_UP | Nes.BTN_DOWN)) == (Nes.BTN_UP | Nes.BTN_DOWN)) p &= ~(Nes.BTN_UP | Nes.BTN_DOWN);
        if ((p & (Nes.BTN_LEFT | Nes.BTN_RIGHT)) == (Nes.BTN_LEFT | Nes.BTN_RIGHT)) p &= ~(Nes.BTN_LEFT | Nes.BTN_RIGHT);
        return p;
    }

    private void toggleFast() {
        fastToggle = !fastToggle;
        controls.setFastForwardOn(fastToggle);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (menuShowing) return super.dispatchKeyEvent(e);
        int kc = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        if (editing) {
            if (down && e.getRepeatCount() >= 0) controls.editKey(kc);
            return true;
        }
        if ((e.getSource() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD && !gamepadSeen) {
            gamepadSeen = true;
            applyControlsVisibility();
        }
        int act = actionFor(kc);
        if (act == 0) return super.dispatchKeyEvent(e);
        boolean first = down && e.getRepeatCount() == 0;
        switch (act) {
            case ACT_MENU: if (!down) showMenu(); return true;
            case ACT_FF_HOLD: fastHold = down; return true;
            case ACT_FF_TOGGLE: if (first) toggleFast(); return true;
            case ACT_QSAVE: if (first) doSaveState(curSlot); return true;
            case ACT_QLOAD: if (first) doLoadState(curSlot); return true;
            case ACT_TURBO_A: if (down) turboBits |= Nes.BTN_A; else turboBits &= ~Nes.BTN_A; return true;
            case ACT_TURBO_B: if (down) turboBits |= Nes.BTN_B; else turboBits &= ~Nes.BTN_B; return true;
            case ACT_AB: {
                int ab = Nes.BTN_A | Nes.BTN_B;
                if (down) keyBits |= ab; else keyBits &= ~ab;
                return true;
            }
            default:
                if (act >= ACT_LATCH) {                       // sticky button: press once to hold, again to release
                    if (first) latchBits ^= (act - ACT_LATCH);
                    return true;
                }
                if (down) keyBits |= act; else keyBits &= ~act;
                return true;
        }
    }

    /** User mapping first, then the built-in defaults for remotes, gamepads and keyboards. */
    private int actionFor(int kc) {
        Integer c = customKeys.get(kc);
        if (c != null) return c;
        switch (kc) {
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_BUTTON_MODE:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_BUTTON_THUMBL:
                return ACT_MENU;
            case KeyEvent.KEYCODE_BUTTON_R1: return ACT_FF_HOLD;
            case KeyEvent.KEYCODE_BUTTON_R2:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                return ACT_FF_TOGGLE;
            case KeyEvent.KEYCODE_BUTTON_L1: return ACT_QSAVE;
            case KeyEvent.KEYCODE_BUTTON_L2: return ACT_QLOAD;
            default: return mapKey(kc);
        }
    }

    private void saveKeymap() {
        StringBuilder sb = new StringBuilder();
        for (java.util.Map.Entry<Integer, Integer> en : customKeys.entrySet()) {
            sb.append(en.getKey()).append('=').append(en.getValue()).append(';');
        }
        prefs.edit().putString("keymap", sb.toString()).apply();
    }

    private void loadKeymap() {
        customKeys.clear();
        String str = prefs.getString("keymap", "");
        for (String part : str.split(";")) {
            int k = part.indexOf('=');
            if (k <= 0) continue;
            try {
                customKeys.put(Integer.parseInt(part.substring(0, k)), Integer.parseInt(part.substring(k + 1)));
            } catch (NumberFormatException ignored) { }
        }
    }

    private String keysFor(int action) {
        StringBuilder sb = new StringBuilder();
        for (java.util.Map.Entry<Integer, Integer> en : customKeys.entrySet()) {
            if (en.getValue() == action) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(KeyEvent.keyCodeToString(en.getKey()).replace("KEYCODE_", ""));
            }
        }
        return sb.length() == 0 ? "default" : sb.toString();
    }

    private void showCapture(final int act) {
        menuShowing = true;
        String nm = "";
        for (int i = 0; i < MAP_ACTIONS.length; i++) if (MAP_ACTIONS[i] == act) nm = MAP_NAMES[i];
        final String name = nm;
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Map: " + name)
                .setMessage("Press the remote / gamepad key you want to use for this.\n\n(Back = cancel)").create();
        d.setOnKeyListener((dlg, kc, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return true;
            if (kc == KeyEvent.KEYCODE_BACK) { dlg.cancel(); return true; }
            customKeys.put(kc, act);
            saveKeymap();
            toast(KeyEvent.keyCodeToString(kc).replace("KEYCODE_", "") + "  ->  " + name);
            dlg.dismiss();
            return true;
        });
        d.setOnDismissListener(x -> openPage(P_MAP));
        d.show();
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != 0 && e.getAction() == MotionEvent.ACTION_MOVE) {
            float hx = e.getAxisValue(MotionEvent.AXIS_HAT_X), hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
            float lx = e.getAxisValue(MotionEvent.AXIS_X), ly = e.getAxisValue(MotionEvent.AXIS_Y);
            int b = 0;
            if (hx < -0.5f || lx < -0.5f) b |= Nes.BTN_LEFT;
            if (hx > 0.5f || lx > 0.5f) b |= Nes.BTN_RIGHT;
            if (hy < -0.5f || ly < -0.5f) b |= Nes.BTN_UP;
            if (hy > 0.5f || ly > 0.5f) b |= Nes.BTN_DOWN;
            axisBits = b;
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    @Override
    public void onBackPressed() { if (editing) finishEdit(); else showMenu(); }

    // ---- on-screen controls ------------------------------------------------------------------------

    private void applyOrientation() {
        setRequestedOrientation(orient == 1 ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : orient == 2 ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
    }

    private void applyControlsVisibility() {
        boolean touch = getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
        boolean show;
        if (editing) show = true;
        else if (ctlMode == 1) show = true;
        else if (ctlMode == 2) show = false;
        else show = touch && !gamepadSeen;
        controls.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) touchBits = 0;
    }

    private void startEdit() {
        editing = true;
        controls.setEditMode(true);
        applyControlsVisibility();
        updateRun();
        Toast.makeText(this, "Drag buttons. Remote: arrows move, OK = next, Back = done", Toast.LENGTH_LONG).show();
    }

    private void finishEdit() {
        if (!editing) return;
        editing = false;
        controls.setEditMode(false);
        controls.saveLayout(prefs);
        applyControlsVisibility();
        openPage(P_CTRL);
    }

    // ---- menu ------------------------------------------------------------------------------------

    private void showMenu() {
        if (menuShowing || editing) return;
        refreshStateNames();
        openPage(P_MAIN);
    }

    private void refreshStateNames() {
        io.execute(() -> {
            Set<String> names = Storage.listNames(this, saveDir);
            synchronized (usedNames) {
                usedNames.clear();
                usedNames.addAll(names);
            }
        });
    }

    private String onOff(boolean b) { return b ? "on" : "off"; }

    private String[] pageItems(int page) {
        switch (page) {
            case P_VIDEO: {
                String[] asp = {"4:3", "8:7 (square pixels)", "Stretch"};
                String[] sl = {"off", "light", "strong"};
                return new String[]{
                        "Aspect: " + asp[aspectMode],
                        "Filter: " + (smooth ? "smooth" : "sharp"),
                        "Scanlines: " + sl[scanlines],
                        "CRT aperture mask: " + onOff(mask),
                        "CRT vignette: " + onOff(vignette),
                        "Screen rotation: " + new String[]{"auto", "landscape", "portrait"}[orient],
                        "FPS / debug overlay: " + onOff(showFps),
                        "< Back"};
            }
            case P_CTRL: {
                String[] mode = {"auto (touchscreens only)", "always", "never"};
                return new String[]{
                        "Show on-screen buttons: " + mode[ctlMode],
                        "Opacity: " + ctlAlpha + "%",
                        "Size: " + Math.round(SIZES[sizeIdx] * 100) + "%",
                        "Vibrate on press: " + onOff(haptics),
                        "Move buttons...",
                        "Reset button positions",
                        "< Back"};
            }
            case P_MAP: {
                String[] it = new String[MAP_ACTIONS.length + 2];
                for (int i = 0; i < MAP_ACTIONS.length; i++) it[i] = MAP_NAMES[i] + ":  " + keysFor(MAP_ACTIONS[i]);
                it[MAP_ACTIONS.length] = "Reset mapping to default";
                it[MAP_ACTIONS.length + 1] = "< Back";
                return it;
            }
            case P_SAVE:
            case P_LOAD: {
                String[] it = new String[11];
                for (int i = 1; i <= 10; i++) {
                    boolean used = usedNames.contains(Storage.stateFileName(romName, i));
                    it[i - 1] = "Slot " + i + (used ? "  (used)" : "  (empty)") + (i == curSlot ? "  *" : "");
                }
                it[10] = "< Back";
                return it;
            }
            default:
                return new String[]{
                        "Resume",
                        "Save state...",
                        "Load state...",
                        "Fast forward: " + onOff(fastToggle) + "   (select = switch and resume)",
                        "Fast forward speed: " + (FF_SPEEDS[ffIdx] == 0 ? "max" : FF_SPEEDS[ffIdx] + "x"),
                        "Video / CRT...",
                        "On-screen buttons...",
                        "Controller / remote mapping...",
                        "Press START",
                        "Press SELECT",
                        "Write game save now",
                        "Reset",
                        "Exit to menu"};
        }
    }

    private String pageTitle(int page) {
        switch (page) {
            case P_VIDEO: return "Video / CRT";
            case P_CTRL: return "On-screen buttons";
            case P_MAP: return "Controller / remote mapping";
            case P_SAVE: return "Save state  (L1 = quick save)";
            case P_LOAD: return "Load state  (L2 = quick load)";
            default: return romName;
        }
    }

    private void openPage(final int page) {
        menuShowing = true;
        currentPage = page;
        keyBits = 0;
        axisBits = 0;
        latchBits = 0;
        turboBits = 0;
        fastHold = false;
        updateRun();
        AlertDialog d = new AlertDialog.Builder(this).setTitle(pageTitle(page))
                .setItems(pageItems(page), (dlg, which) -> onMenuItem(page, which)).create();
        d.setOnCancelListener(x -> { if (page != P_MAIN) nextPage = P_MAIN; });
        d.setOnDismissListener(x -> {
            if (pendingCapture != 0) {
                int a = pendingCapture;
                pendingCapture = 0;
                showCapture(a);
                return;
            }
            if (nextPage >= 0) {
                int p = nextPage;
                nextPage = -1;
                openPage(p);
            } else {
                menuShowing = false;
                updateRun();
                if (pendingTap != 0) {
                    final int bit = pendingTap;
                    pendingTap = 0;
                    ui.postDelayed(() -> {
                        tapBits |= bit;
                        ui.postDelayed(() -> tapBits &= ~bit, 160);
                    }, 80);
                }
            }
        });
        d.show();
    }

    private void onMenuItem(int page, int which) {
        switch (page) {
            case P_VIDEO:
                switch (which) {
                    case 0: aspectMode = (aspectMode + 1) % 3; prefs.edit().putInt("aspect", aspectMode).apply(); break;
                    case 1: smooth = !smooth; prefs.edit().putBoolean("smooth", smooth).apply(); break;
                    case 2: scanlines = (scanlines + 1) % 3; prefs.edit().putInt("scanlines", scanlines).apply(); break;
                    case 3: mask = !mask; prefs.edit().putBoolean("mask", mask).apply(); break;
                    case 4: vignette = !vignette; prefs.edit().putBoolean("vignette", vignette).apply(); break;
                    case 5: orient = (orient + 1) % 3; prefs.edit().putInt("orient", orient).apply(); applyOrientation(); break;
                    case 6: showFps = !showFps; prefs.edit().putBoolean("fps", showFps).apply(); break;
                    default: nextPage = P_MAIN; return;
                }
                nextPage = P_VIDEO;
                break;
            case P_CTRL:
                switch (which) {
                    case 0: ctlMode = (ctlMode + 1) % 3; prefs.edit().putInt("ctlMode", ctlMode).apply(); applyControlsVisibility(); break;
                    case 1: {
                        int nx = OPACITIES[0];
                        for (int o : OPACITIES) if (o > ctlAlpha) { nx = o; break; }
                        ctlAlpha = nx;
                        prefs.edit().putInt("ctlAlpha", ctlAlpha).apply();
                        controls.setAlphaPct(ctlAlpha);
                        break;
                    }
                    case 2:
                        sizeIdx = (sizeIdx + 1) % SIZES.length;
                        prefs.edit().putInt("ctlSize", sizeIdx).apply();
                        controls.setScale(SIZES[sizeIdx]);
                        break;
                    case 3: haptics = !haptics; prefs.edit().putBoolean("haptics", haptics).apply(); controls.setHaptics(haptics); break;
                    case 4: startEdit(); return;
                    case 5: controls.resetLayout(); controls.saveLayout(prefs); break;
                    default: nextPage = P_MAIN; return;
                }
                nextPage = P_CTRL;
                break;
            case P_MAP:
                if (which < MAP_ACTIONS.length) {
                    pendingCapture = MAP_ACTIONS[which];
                } else if (which == MAP_ACTIONS.length) {
                    customKeys.clear();
                    saveKeymap();
                    nextPage = P_MAP;
                } else {
                    nextPage = P_MAIN;
                }
                break;
            case P_SAVE:
                if (which < 10) doSaveState(which + 1);
                else nextPage = P_MAIN;
                break;
            case P_LOAD:
                if (which < 10) {
                    int slot = which + 1;
                    if (!usedNames.contains(Storage.stateFileName(romName, slot))) {
                        toast("Slot " + slot + " is empty");
                        nextPage = P_LOAD;
                    } else {
                        doLoadState(slot);
                    }
                } else {
                    nextPage = P_MAIN;
                }
                break;
            default:
                switch (which) {
                    case 1: nextPage = P_SAVE; break;
                    case 2: nextPage = P_LOAD; break;
                    case 3: toggleFast(); break;                       // closes the menu and resumes
                    case 4:
                        ffIdx = (ffIdx + 1) % FF_SPEEDS.length;
                        prefs.edit().putInt("ffIdx", ffIdx).apply();
                        nextPage = P_MAIN;
                        break;
                    case 5: nextPage = P_VIDEO; break;
                    case 6: nextPage = P_CTRL; break;
                    case 7: nextPage = P_MAP; break;
                    case 8: pendingTap = Nes.BTN_START; break;
                    case 9: pendingTap = Nes.BTN_SELECT; break;
                    case 10: flushSaveBlocking(); toast("Game save written"); nextPage = P_MAIN; break;
                    case 11: if (emu != null) emu.resetRequested = true; break;
                    case 12: finish(); break;
                    default: break;
                }
                break;
        }
    }

    // ---- savestates --------------------------------------------------------------------------------

    private void doSaveState(final int slot) {
        final Nes n = nes;
        if (n == null || emu == null) return;
        opBusy++;
        updateRun();
        try {
            final byte[] s = n.saveState();
            final String name = Storage.stateFileName(romName, slot);
            curSlot = slot;
            prefs.edit().putInt("slot", slot).apply();
            io.execute(() -> {
                try {
                    Storage.writeSave(this, saveDir, name, s);
                    usedNames.add(name);
                    toast("State saved to slot " + slot);
                } catch (Exception e) {
                    toast("State save failed: " + e.getMessage());
                }
            });
        } catch (Exception e) {
            toast("State save failed: " + e.getMessage());
        } finally {
            opBusy--;
            updateRun();
        }
    }

    private void doLoadState(final int slot) {
        if (nes == null || emu == null) return;
        opBusy++;
        updateRun();
        final String name = Storage.stateFileName(romName, slot);
        io.execute(() -> {
            byte[] d = null;
            String err = null;
            try {
                d = Storage.readSave(this, saveDir, name);
                if (d == null) err = "Slot " + slot + " is empty";
            } catch (Exception e) {
                err = "Cannot read state: " + e.getMessage();
            }
            final byte[] data = d;
            final String error = err;
            ui.post(() -> {
                if (data != null) {
                    try {
                        nes.loadState(data);
                        curSlot = slot;
                        prefs.edit().putInt("slot", slot).apply();
                        toast("State loaded from slot " + slot);
                    } catch (Exception e) {
                        toast("Cannot load state: " + e.getMessage());
                        if (emu != null) emu.resetRequested = true;   // machine may be half-restored
                    }
                } else {
                    toast(error);
                }
                opBusy--;
                updateRun();
            });
        });
    }

    // ---- battery / EEPROM saves ---------------------------------------------------------------------

    private void writeSaveNow(byte[] data, int gen) {
        try {
            Storage.writeSave(this, saveDir, saveFile, data);
            savedGen = gen;
        } catch (final Exception e) {
            toast("Save failed: " + e.getMessage() + " (check the save folder)");
        }
    }

    private void flushSaveAsync(Nes n) {
        final byte[] d = n.getSaveData();
        if (d == null) return;
        final int gen = n.saveGeneration();
        io.execute(() -> writeSaveNow(d, gen));
    }

    /** Call only while the emulation thread is parked (or not running). */
    private void flushSaveBlocking() {
        final Nes n = nes;
        if (n == null || n.saveGeneration() == savedGen) return;
        final byte[] d = n.getSaveData();
        if (d == null) return;
        final int gen = n.saveGeneration();
        try {
            Future<?> f = io.submit(() -> writeSaveNow(d, gen));
            f.get(4, TimeUnit.SECONDS);
        } catch (Exception ignored) { }
    }

    // ---- emulation thread --------------------------------------------------------------------------

    private final class EmuThread extends Thread {
        volatile boolean quit;
        volatile boolean pauseRequested = true;
        volatile boolean resetRequested;
        private boolean parked;

        EmuThread() { super("emulation"); }

        synchronized void setPaused(boolean p) {
            pauseRequested = p;
            notifyAll();
            if (p) {
                long end = System.nanoTime() + 600_000_000L;
                while (!parked && !quit && isAlive() && System.nanoTime() < end) {
                    try { wait(20); } catch (InterruptedException e) { return; }
                }
            }
        }

        private void park() {
            audio.pause();
            synchronized (this) {
                parked = true;
                notifyAll();
                while (pauseRequested && !quit) {
                    try { wait(100); } catch (InterruptedException e) { return; }
                }
                parked = false;
            }
            if (!quit) audio.resume();
        }

        @Override
        public void run() {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO); } catch (Throwable ignored) { }
            Nes n = nes;
            int seenGen = n.saveGeneration();
            int quiet = 0;
            boolean pending = false, wasFast = false;
            int ffFrame = 0;
            long nextNs = System.nanoTime();
            long fpsT = nextNs;
            int fpsFrames = 0;

            while (!quit) {
                if (pauseRequested) {
                    park();
                    nextNs = System.nanoTime();
                    continue;
                }
                if (resetRequested) {
                    resetRequested = false;
                    try {
                        byte[] sv = n.getSaveData();
                        Nes fresh = new Nes(romBytes, SAMPLE_RATE);
                        if (sv != null) fresh.loadSave(sv);
                        nes = fresh;
                        n = fresh;
                        seenGen = n.saveGeneration();
                    } catch (Exception ignored) { }
                }
                n.pad0 = currentPad();
                // While fast-forwarding only about every Nth frame is drawn (display is 60 Hz anyway);
                // the skipped frames still run all game-visible logic exactly.
                boolean ffNow = fastHold || fastToggle;
                int spd = FF_SPEEDS[ffIdx];
                int drawEvery = ffNow ? (spd == 0 ? 6 : Math.max(1, Math.min(spd, 6))) : 1;
                n.ppu.skipRender = ffNow && (ffFrame++ % drawEvery != 0);
                n.runFrame();

                Renderer r = renderer;
                if (r != null && !n.ppu.skipRender) r.submit(n.ppu.frame);
                n.ppu.skipRender = false;

                int cnt = n.apu.sampleCount;
                boolean ff = fastHold || fastToggle;
                if (ff) {
                    if (!wasFast) { wasFast = true; nextNs = System.nanoTime(); }
                    int sp = FF_SPEEDS[ffIdx];
                    if (sp > 0) {
                        nextNs += FRAME_NANOS / sp;
                        long wait = nextNs - System.nanoTime();
                        if (wait > 0) {
                            try { Thread.sleep(wait / 1_000_000L, (int) (wait % 1_000_000L)); } catch (InterruptedException e) { return; }
                        } else if (wait < -100_000_000L) {
                            nextNs = System.nanoTime();
                        }
                    } else {
                        nextNs = System.nanoTime();
                    }
                } else {
                    if (wasFast) {                       // drop audio that piled up while skipping ahead
                        wasFast = false;
                        audio.pause();
                        audio.resume();
                        nextNs = System.nanoTime();
                    }
                    if (audio.active) {
                        audio.write(n.apu.samples, cnt);  // blocks: audio clock paces the emulator
                    } else {
                        nextNs += FRAME_NANOS;
                        long wait = nextNs - System.nanoTime();
                        if (wait > 0) {
                            try { Thread.sleep(wait / 1_000_000L, (int) (wait % 1_000_000L)); } catch (InterruptedException e) { return; }
                        } else if (wait < -100_000_000L) {
                            nextNs = System.nanoTime();
                        }
                    }
                }
                n.apu.sampleCount = 0;

                // persist battery / EEPROM data half a second after the last change
                int g = n.saveGeneration();
                if (g != seenGen) {
                    seenGen = g;
                    quiet = 0;
                    pending = true;
                } else if (pending && ++quiet >= 30) {
                    pending = false;
                    flushSaveAsync(n);
                }

                fpsFrames++;
                long now = System.nanoTime();
                if (now - fpsT >= 1_000_000_000L) {
                    emuFps = fpsFrames * 1e9f / (now - fpsT);
                    fpsFrames = 0;
                    fpsT = now;
                }
            }
        }
    }

    // ---- video -----------------------------------------------------------------------------------

    private final class Renderer extends Thread {
        private final SurfaceHolder holder;
        private final int[] pending = new int[Ppu.WIDTH * Ppu.HEIGHT];
        private boolean has;
        private volatile boolean quit;
        private final Bitmap bmp = Bitmap.createBitmap(Ppu.WIDTH, Ppu.HEIGHT, Bitmap.Config.ARGB_8888);
        private final Paint paint = new Paint();
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint scan = new Paint();
        private final Paint maskPaint = new Paint();
        private final Paint vigPaint = new Paint();
        private final Rect src = new Rect(0, 0, Ppu.WIDTH, Ppu.HEIGHT);
        private final RectF dst = new RectF();
        private int drawFrames;
        private long drawT = System.nanoTime();
        private float drawFps;
        private int vigW, vigH;
        private boolean useHw = Build.VERSION.SDK_INT >= 26;
        private String lastError = "";

        Renderer(SurfaceHolder h) {
            super("renderer");
            holder = h;
            text.setColor(Color.YELLOW);
            text.setShadowLayer(3f, 1f, 1f, Color.BLACK);
            // aperture-grille pattern: every third screen column is darkened
            Bitmap m = Bitmap.createBitmap(3, 1, Bitmap.Config.ARGB_8888);
            m.setPixel(0, 0, 0x00000000);
            m.setPixel(1, 0, 0x00000000);
            m.setPixel(2, 0, 0x78000000);
            maskPaint.setShader(new BitmapShader(m, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        }

        synchronized void submit(int[] f) {
            System.arraycopy(f, 0, pending, 0, pending.length);
            has = true;
            notifyAll();
        }

        synchronized void shutdown() {
            quit = true;
            notifyAll();
        }

        @Override
        public void run() {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_DISPLAY); } catch (Throwable ignored) { }
            bmp.eraseColor(Color.BLACK);
            while (!quit) {
                synchronized (this) {
                    if (!has) {
                        try { wait(100); } catch (InterruptedException e) { return; }
                    }
                    if (quit) return;
                    if (has) {
                        bmp.setPixels(pending, 0, Ppu.WIDTH, 0, 0, Ppu.WIDTH, Ppu.HEIGHT);
                        has = false;
                    }
                }
                draw();
            }
        }

        private void draw() {
            Surface s = holder.getSurface();
            if (s == null || !s.isValid()) return;
            Canvas c = null;
            try {
                c = useHw ? s.lockHardwareCanvas() : s.lockCanvas(null);
                if (c == null) return;
                int w = c.getWidth(), h = c.getHeight();
                c.drawColor(Color.BLACK);
                int mode = aspectMode;
                boolean portrait = h > w;     // phone held upright: picture at the top, buttons below
                float aspect = mode == 0 ? 4f / 3f : mode == 1 ? (Ppu.WIDTH * 8f / 7f) / Ppu.HEIGHT
                        : (portrait ? (float) Ppu.WIDTH / Ppu.HEIGHT : (float) w / h);
                float dw, dh;
                if ((float) w / h > aspect) { dh = h; dw = h * aspect; } else { dw = w; dh = w / aspect; }
                float top = portrait ? h * 0.04f : (h - dh) / 2f;
                dst.set((w - dw) / 2f, top, (w + dw) / 2f, top + dh);
                paint.setFilterBitmap(smooth);
                c.drawBitmap(bmp, src, dst, paint);
                drawCrt(c, dw, dh);

                drawFrames++;
                long now = System.nanoTime();
                if (now - drawT >= 1_000_000_000L) {
                    drawFps = drawFrames * 1e9f / (now - drawT);
                    drawFrames = 0;
                    drawT = now;
                }
                text.setTextSize(h / 28f);
                if (showFps) {
                    c.drawText(String.format(Locale.US, "emu %.1f fps  draw %.1f fps", emuFps, drawFps), h / 40f, h / 18f, text);
                }
                Nes dn = nes;
                if (dn != null && showFps) {
                    AudioOut au = audio;
                    c.drawText(String.format(Locale.US, "map %d  PC %04X  CTRL %02X MASK %02X  frame %d  aud %s%s %s",
                            dn.cart.mapperId, dn.cpu.getPc(), dn.ppu.debugCtrl(), dn.ppu.debugMask(), dn.frames,
                            au == null ? "-" : au.status(), useHw ? "" : "  [sw]", lastError), h / 40f, h / 9f, text);
                    String di = dn.mapper.debugInfo();
                    if (di.length() > 0) c.drawText(di, h / 40f, h / 9f + h / 26f, text);
                    c.drawText("touch: most fingers at once " + controls.maxPointers() + ", cancelled by system "
                            + controls.cancelCount(), h / 40f, h / 9f + h / 13f, text);
                }
                int lb = latchBits;
                if (lb != 0) {
                    String[] nm = {"A", "B", "SELECT", "START", "UP", "DOWN", "LEFT", "RIGHT"};
                    StringBuilder sb = new StringBuilder("HOLD:");
                    for (int i = 0; i < 8; i++) if ((lb & (1 << i)) != 0) sb.append(' ').append(nm[i]);
                    c.drawText(sb.toString(), h / 40f, h - h / 30f, text);
                }
                if (fastHold || fastToggle) {
                    int sp = FF_SPEEDS[ffIdx];
                    String label = ">> FAST " + (sp == 0 ? "MAX" : sp + "x") + String.format(Locale.US, "  (real %.1fx)", emuFps / 60.1f);
                    c.drawText(label, w - text.measureText(label) - h / 40f, h / 18f, text);
                }
            } catch (Exception ex) {
                useHw = false;                      // fall back to the software canvas
                lastError = String.valueOf(ex);
                Log.e("NesTv", "draw failed", ex);
            } finally {
                if (c != null) {
                    try { s.unlockCanvasAndPost(c); } catch (Exception ignored) { }
                }
            }
        }

        /** Old-TV look: scanlines, aperture mask and vignette drawn over the scaled image. */
        private void drawCrt(Canvas c, float dw, float dh) {
            int sl = scanlines;
            if (sl > 0) {
                float rowH = dh / Ppu.HEIGHT;
                scan.setColor(Color.argb(sl == 1 ? 70 : 150, 0, 0, 0));
                for (int r = 0; r < Ppu.HEIGHT; r++) {
                    float top = dst.top + r * rowH + rowH * 0.55f;
                    c.drawRect(dst.left, top, dst.right, dst.top + (r + 1) * rowH, scan);
                }
            }
            if (mask) c.drawRect(dst, maskPaint);
            if (vignette) {
                int iw = Math.round(dw), ih = Math.round(dh);
                if (iw != vigW || ih != vigH) {
                    vigW = iw;
                    vigH = ih;
                    float rad = (float) Math.hypot(dw, dh) / 2f;
                    vigPaint.setShader(new RadialGradient(dst.centerX(), dst.centerY(), rad,
                            new int[]{0x00000000, 0x00000000, 0xB4000000}, new float[]{0f, 0.55f, 1f},
                            Shader.TileMode.CLAMP));
                }
                c.drawRect(dst, vigPaint);
            }
        }
    }

    // ---- audio -----------------------------------------------------------------------------------

    /** Mono 16-bit AudioTrack in low-latency mode; blocking writes pace the emulator. */
    private static final class AudioOut {
        private AudioTrack track;
        volatile boolean active;
        private int target, capacity, lastUnderruns, writes, stalls;
        private volatile String state = "init";

        String status() { return (active ? "ok/" : "off/") + state; }

        void init() {
            try {
                int minBytes = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT);
                int capBytes = Math.max(minBytes, 6000 * 2);
                AudioTrack.Builder b = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setSampleRate(SAMPLE_RATE)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .setBufferSizeInBytes(capBytes);
                if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
                track = b.build();
                capacity = track.getBufferCapacityInFrames();
                target = Math.min(capacity, 2400);               // ~50 ms, grows only after underruns
                track.setBufferSizeInFrames(target);
                lastUnderruns = track.getUnderrunCount();
                active = true;
                state = "ready";
            } catch (Throwable t) {
                active = false;
                state = "init-fail";
            }
        }

        void resume() {
            if (track == null) return;
            try {
                short[] silence = new short[Math.max(1, target / 2)];
                track.write(silence, 0, silence.length);
                track.play();
                lastUnderruns = track.getUnderrunCount();
                state = track.getPlayState() == AudioTrack.PLAYSTATE_PLAYING ? "playing" : "not-playing";
            } catch (Throwable t) {
                state = "play-fail";
            }
        }

        void pause() {
            if (track == null) return;
            try {
                track.pause();
                track.flush();
            } catch (Throwable ignored) { }
        }

        /**
         * Non-blocking writes with a watchdog: if the device stops consuming audio the emulator falls
         * back to clock-based pacing instead of freezing.
         */
        void write(short[] d, int n) {
            if (track == null) { active = false; return; }
            try {
                if (track.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                    track.play();
                    state = "replay";
                }
            } catch (Throwable t) {
                state = "play-fail";
                active = false;
                return;
            }
            int off = 0;
            long deadline = System.nanoTime() + 200_000_000L;
            while (off < n) {
                int w = track.write(d, off, n - off, AudioTrack.WRITE_NON_BLOCKING);
                if (w < 0) { state = "write-err"; active = false; return; }
                off += w;
                if (off < n) {
                    if (System.nanoTime() > deadline) {
                        if (++stalls >= 3) { active = false; state = "stalled"; }
                        return;
                    }
                    try { Thread.sleep(2); } catch (InterruptedException ex) { return; }
                }
            }
            stalls = 0;
            if (++writes % 120 == 0) {
                int u = track.getUnderrunCount();
                if (u > lastUnderruns) {
                    lastUnderruns = u;
                    if (target + 400 <= capacity) {
                        target += 400;
                        track.setBufferSizeInFrames(target);
                    }
                }
            }
        }

        void release() {
            if (track != null) {
                try { track.stop(); } catch (Throwable ignored) { }
                track.release();
                track = null;
            }
        }
    }
}
