package com.example.nestv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.nestv.core.Nes;
import com.example.nestv.core.Ppu;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class EmuActivity extends Activity implements SurfaceHolder.Callback {
    static final String EXTRA_ROM = "rom", EXTRA_NAME = "name", EXTRA_SAVE_DIR = "saveDir";
    private static final int SAMPLE_RATE = 48000;
    private static final long FRAME_NANOS = 16639267L; // NTSC 60.0988 Hz

    private SurfaceView surfaceView;
    private TextView loadingView;
    private SharedPreferences prefs;
    private String romLoc, romName, saveDir, saveFile;
    private byte[] romBytes;

    private volatile Nes nes;
    private EmuThread emu;
    private volatile Renderer renderer;
    private AudioOut audio;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private volatile int keyBits, axisBits, tapBits;
    private volatile boolean fast;
    private volatile boolean showFps;
    private volatile boolean smooth;
    private volatile int aspectMode;            // 0 = 4:3, 1 = 8:7, 2 = stretch
    private volatile float emuFps;
    private volatile int savedGen;

    private boolean resumed, menuShowing, surfaceReady, reopenMenu;
    private int pendingTap;

    // ---- lifecycle -------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        prefs = getSharedPreferences("nestv", MODE_PRIVATE);
        aspectMode = prefs.getInt("aspect", 0);
        smooth = prefs.getBoolean("smooth", true);
        showFps = prefs.getBoolean("fps", false);

        romLoc = getIntent().getStringExtra(EXTRA_ROM);
        romName = getIntent().getStringExtra(EXTRA_NAME);
        saveDir = getIntent().getStringExtra(EXTRA_SAVE_DIR);
        if (romName == null) romName = "game.nes";
        saveFile = Storage.saveFileName(romName);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        surfaceView = new SurfaceView(this);
        surfaceView.getHolder().addCallback(this);
        root.addView(surfaceView, new FrameLayout.LayoutParams(-1, -1));
        loadingView = new TextView(this);
        loadingView.setText("Loading...");
        loadingView.setTextColor(Color.WHITE);
        loadingView.setTextSize(24);
        root.addView(loadingView, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setContentView(root);
        hideSystemUi();

        new Thread(() -> {
            try {
                byte[] rom = Storage.readAll(this, romLoc);
                byte[] save = Storage.readSave(this, saveDir, saveFile);
                Nes n = new Nes(rom, SAMPLE_RATE);
                if (save != null) n.loadSave(save);
                final int gen = n.saveGeneration();
                ui.post(() -> {
                    romBytes = rom;
                    savedGen = gen;
                    nes = n;
                    loadingView.setVisibility(View.GONE);
                    startEmulation();
                });
            } catch (Throwable e) {
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                ui.post(() -> {
                    Toast.makeText(this, "Cannot start ROM: " + msg, Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        }, "rom-loader").start();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        hideSystemUi();
        updateRun();
    }

    @Override
    protected void onPause() {
        resumed = false;
        keyBits = 0;
        axisBits = 0;
        updateRun();            // waits until the emulation thread is parked
        flushSaveBlocking();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        EmuThread t = emu;
        if (t != null) {
            t.quit = true;
            synchronized (t) { t.notifyAll(); }
            try { t.join(1500); } catch (InterruptedException ignored) { }
        }
        if (audio != null) audio.release();
        io.shutdown();
        super.onDestroy();
    }

    private void startEmulation() {
        if (emu != null || nes == null) return;
        audio = new AudioOut();
        audio.init();
        emu = new EmuThread();
        emu.start();
        updateRun();
    }

    private void updateRun() {
        EmuThread t = emu;
        if (t != null) t.setPaused(!(resumed && !menuShowing && nes != null));
    }

    // ---- surface ---------------------------------------------------------------------------------

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                holder.getSurface().setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
            } catch (Throwable ignored) { }
        }
        if (renderer == null) {
            Renderer r = new Renderer(holder);
            renderer = r;
            r.start();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) { }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        Renderer r = renderer;
        renderer = null;
        if (r != null) {
            r.shutdown();
            try { r.join(1000); } catch (InterruptedException ignored) { }
        }
    }

    // ---- input -----------------------------------------------------------------------------------

    private static int mapKey(int kc) {
        switch (kc) {
            case KeyEvent.KEYCODE_DPAD_UP: return Nes.BTN_UP;
            case KeyEvent.KEYCODE_DPAD_DOWN: return Nes.BTN_DOWN;
            case KeyEvent.KEYCODE_DPAD_LEFT: return Nes.BTN_LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return Nes.BTN_RIGHT;
            case KeyEvent.KEYCODE_DPAD_CENTER:       // TV remote OK button
            case KeyEvent.KEYCODE_BUTTON_B:
            case KeyEvent.KEYCODE_BUTTON_Y:
            case KeyEvent.KEYCODE_X:
                return Nes.BTN_A;
            case KeyEvent.KEYCODE_BUTTON_A:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_Z:
                return Nes.BTN_B;
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                return Nes.BTN_START;
            case KeyEvent.KEYCODE_BUTTON_SELECT:
            case KeyEvent.KEYCODE_SHIFT_RIGHT:
            case KeyEvent.KEYCODE_DEL:
            case KeyEvent.KEYCODE_MENU:
                return Nes.BTN_SELECT;
            default: return 0;
        }
    }

    private int currentPad() {
        int p = keyBits | axisBits | tapBits;
        if ((p & (Nes.BTN_UP | Nes.BTN_DOWN)) == (Nes.BTN_UP | Nes.BTN_DOWN)) p &= ~(Nes.BTN_UP | Nes.BTN_DOWN);
        if ((p & (Nes.BTN_LEFT | Nes.BTN_RIGHT)) == (Nes.BTN_LEFT | Nes.BTN_RIGHT)) p &= ~(Nes.BTN_LEFT | Nes.BTN_RIGHT);
        return p;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (menuShowing) return super.dispatchKeyEvent(e);
        int kc = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        if (kc == KeyEvent.KEYCODE_BACK || kc == KeyEvent.KEYCODE_BUTTON_MODE
                || kc == KeyEvent.KEYCODE_ESCAPE || kc == KeyEvent.KEYCODE_BUTTON_THUMBL) {
            if (!down) showMenu();
            return true;
        }
        if (kc == KeyEvent.KEYCODE_BUTTON_R1 || kc == KeyEvent.KEYCODE_BUTTON_R2) { // hold = fast forward
            fast = down;
            return true;
        }
        int bit = mapKey(kc);
        if (bit != 0) {
            if (down) keyBits |= bit; else keyBits &= ~bit;
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != 0 && e.getAction() == MotionEvent.ACTION_MOVE) {
            float hx = e.getAxisValue(MotionEvent.AXIS_HAT_X), hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
            float lx = e.getAxisValue(MotionEvent.AXIS_X), ly = e.getAxisValue(MotionEvent.AXIS_Y);
            int b = 0;
            if (hx < -0.5f || lx < -0.5f) b |= Nes.BTN_LEFT;
            if (hx > 0.5f || lx > 0.5f) b |= Nes.BTN_RIGHT;
            if (hy < -0.5f || ly < -0.5f) b |= Nes.BTN_UP;
            if (hy > 0.5f || ly > 0.5f) b |= Nes.BTN_DOWN;
            axisBits = b;
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    @Override
    public void onBackPressed() { showMenu(); }

    // ---- menu ------------------------------------------------------------------------------------

    private void showMenu() {
        if (menuShowing) return;
        menuShowing = true;
        keyBits = 0;
        axisBits = 0;
        fast = false;
        updateRun();
        String[] aspects = {"4:3", "8:7 (square pixels)", "Stretch"};
        final String[] items = {
                "Resume",
                "Press START",
                "Press SELECT",
                "Save now",
                "Reset",
                "Aspect: " + aspects[aspectMode],
                "Filter: " + (smooth ? "smooth" : "sharp"),
                "FPS overlay: " + (showFps ? "on" : "off"),
                "Exit to menu"
        };
        AlertDialog d = new AlertDialog.Builder(this).setTitle(romName).setItems(items, (dlg, which) -> {
            switch (which) {
                case 1: pendingTap = Nes.BTN_START; break;
                case 2: pendingTap = Nes.BTN_SELECT; break;
                case 3: flushSaveBlocking(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show(); reopenMenu = true; break;
                case 4: if (emu != null) emu.resetRequested = true; break;
                case 5: aspectMode = (aspectMode + 1) % 3; prefs.edit().putInt("aspect", aspectMode).apply(); reopenMenu = true; break;
                case 6: smooth = !smooth; prefs.edit().putBoolean("smooth", smooth).apply(); reopenMenu = true; break;
                case 7: showFps = !showFps; prefs.edit().putBoolean("fps", showFps).apply(); reopenMenu = true; break;
                case 8: finish(); break;
                default: break;
            }
        }).create();
        d.setOnDismissListener(x -> {
            menuShowing = false;
            if (reopenMenu) {
                reopenMenu = false;
                showMenu();
            } else {
                updateRun();
                if (pendingTap != 0) {
                    final int bit = pendingTap;
                    pendingTap = 0;
                    ui.postDelayed(() -> {
                        tapBits |= bit;
                        ui.postDelayed(() -> tapBits &= ~bit, 160);
                    }, 80);
                }
            }
        });
        d.show();
    }

    // ---- saves -----------------------------------------------------------------------------------

    private void writeSaveNow(byte[] data, int gen) {
        try {
            Storage.writeSave(this, saveDir, saveFile, data);
            savedGen = gen;
        } catch (final Exception e) {
            ui.post(() -> Toast.makeText(this, "Save failed: " + e.getMessage()
                    + " (check the save folder)", Toast.LENGTH_LONG).show());
        }
    }

    /** Asynchronous write; safe to call from the emulation thread. */
    private void flushSaveAsync(Nes n) {
        final byte[] d = n.getSaveData();
        if (d == null) return;
        final int gen = n.saveGeneration();
        io.execute(() -> writeSaveNow(d, gen));
    }

    /** Synchronous write; call only while the emulation thread is parked (or not running). */
    private void flushSaveBlocking() {
        final Nes n = nes;
        if (n == null || n.saveGeneration() == savedGen) return;
        final byte[] d = n.getSaveData();
        if (d == null) return;
        final int gen = n.saveGeneration();
        try {
            Future<?> f = io.submit(() -> writeSaveNow(d, gen));
            f.get(4, TimeUnit.SECONDS);
        } catch (Exception ignored) { }
    }

    // ---- emulation thread --------------------------------------------------------------------------

    private final class EmuThread extends Thread {
        volatile boolean quit;
        volatile boolean pauseRequested = true;
        volatile boolean resetRequested;
        private boolean parked;

        EmuThread() { super("emulation"); }

        synchronized void setPaused(boolean p) {
            pauseRequested = p;
            notifyAll();
            if (p) {
                long end = System.nanoTime() + 600_000_000L;
                while (!parked && !quit && isAlive() && System.nanoTime() < end) {
                    try { wait(20); } catch (InterruptedException e) { return; }
                }
            }
        }

        private void park() {
            audio.pause();
            synchronized (this) {
                parked = true;
                notifyAll();
                while (pauseRequested && !quit) {
                    try { wait(100); } catch (InterruptedException e) { return; }
                }
                parked = false;
            }
            if (!quit) audio.resume();
        }

        @Override
        public void run() {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO); } catch (Throwable ignored) { }
            Nes n = nes;
            int seenGen = n.saveGeneration();
            int quiet = 0;
            boolean pending = false;
            long nextNs = System.nanoTime();
            long fpsT = nextNs;
            int fpsFrames = 0;

            while (!quit) {
                if (pauseRequested) {
                    park();
                    nextNs = System.nanoTime();
                    continue;
                }
                if (resetRequested) {
                    resetRequested = false;
                    try {
                        byte[] sv = n.getSaveData();
                        Nes fresh = new Nes(romBytes, SAMPLE_RATE);
                        if (sv != null) fresh.loadSave(sv);
                        nes = fresh;
                        n = fresh;
                        seenGen = n.saveGeneration();
                    } catch (Exception ignored) { }
                }
                n.pad0 = currentPad();
                n.runFrame();

                Renderer r = renderer;
                if (r != null) r.submit(n.ppu.frame);

                int cnt = n.apu.sampleCount;
                if (fast) {
                    nextNs = System.nanoTime();
                } else if (audio.active) {
                    audio.write(n.apu.samples, cnt);      // blocks: audio clock paces the emulator
                } else {
                    nextNs += FRAME_NANOS;
                    long wait = nextNs - System.nanoTime();
                    if (wait > 0) {
                        try { Thread.sleep(wait / 1_000_000L, (int) (wait % 1_000_000L)); } catch (InterruptedException e) { return; }
                    } else if (wait < -100_000_000L) {
                        nextNs = System.nanoTime();
                    }
                }
                n.apu.sampleCount = 0;

                // persist battery / EEPROM data half a second after the last change
                int g = n.saveGeneration();
                if (g != seenGen) {
                    seenGen = g;
                    quiet = 0;
                    pending = true;
                } else if (pending && ++quiet >= 30) {
                    pending = false;
                    flushSaveAsync(n);
                }

                fpsFrames++;
                long now = System.nanoTime();
                if (now - fpsT >= 1_000_000_000L) {
                    emuFps = fpsFrames * 1e9f / (now - fpsT);
                    fpsFrames = 0;
                    fpsT = now;
                }
            }
        }
    }

    // ---- video -----------------------------------------------------------------------------------

    private final class Renderer extends Thread {
        private final SurfaceHolder holder;
        private final int[] pending = new int[Ppu.WIDTH * Ppu.HEIGHT];
        private boolean has;
        private volatile boolean quit;
        private final Bitmap bmp = Bitmap.createBitmap(Ppu.WIDTH, Ppu.HEIGHT, Bitmap.Config.ARGB_8888);
        private final Paint paint = new Paint();
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect src = new Rect(0, 0, Ppu.WIDTH, Ppu.HEIGHT);
        private final RectF dst = new RectF();
        private int drawFrames;
        private long drawT = System.nanoTime();
        private float drawFps;

        Renderer(SurfaceHolder h) {
            super("renderer");
            holder = h;
            text.setColor(Color.YELLOW);
            text.setShadowLayer(3f, 1f, 1f, Color.BLACK);
        }

        synchronized void submit(int[] f) {
            System.arraycopy(f, 0, pending, 0, pending.length);
            has = true;
            notifyAll();
        }

        synchronized void shutdown() {
            quit = true;
            notifyAll();
        }

        @Override
        public void run() {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_DISPLAY); } catch (Throwable ignored) { }
            bmp.eraseColor(Color.BLACK);
            while (!quit) {
                synchronized (this) {
                    if (!has) {
                        try { wait(100); } catch (InterruptedException e) { return; }
                    }
                    if (quit) return;
                    if (has) {
                        bmp.setPixels(pending, 0, Ppu.WIDTH, 0, 0, Ppu.WIDTH, Ppu.HEIGHT);
                        has = false;
                    }
                }
                draw();
            }
        }

        private void draw() {
            Surface s = holder.getSurface();
            if (s == null || !s.isValid()) return;
            Canvas c = null;
            try {
                c = Build.VERSION.SDK_INT >= 26 ? s.lockHardwareCanvas() : s.lockCanvas(null);
                if (c == null) return;
                int w = c.getWidth(), h = c.getHeight();
                c.drawColor(Color.BLACK);
                int mode = aspectMode;
                float aspect = mode == 0 ? 4f / 3f : mode == 1 ? (Ppu.WIDTH * 8f / 7f) / Ppu.HEIGHT : (float) w / h;
                float dw, dh;
                if ((float) w / h > aspect) { dh = h; dw = h * aspect; } else { dw = w; dh = w / aspect; }
                dst.set((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f);
                paint.setFilterBitmap(smooth);
                c.drawBitmap(bmp, src, dst, paint);

                drawFrames++;
                long now = System.nanoTime();
                if (now - drawT >= 1_000_000_000L) {
                    drawFps = drawFrames * 1e9f / (now - drawT);
                    drawFrames = 0;
                    drawT = now;
                }
                if (showFps) {
                    text.setTextSize(h / 28f);
                    c.drawText(String.format("emu %.1f fps  draw %.1f fps", emuFps, drawFps), h / 40f, h / 18f, text);
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) {
                    try { s.unlockCanvasAndPost(c); } catch (Exception ignored) { }
                }
            }
        }
    }

    // ---- audio -----------------------------------------------------------------------------------

    /** Mono 16-bit AudioTrack in low-latency mode; blocking writes pace the emulator. */
    private static final class AudioOut {
        private AudioTrack track;
        volatile boolean active;
        private int target, capacity, lastUnderruns, writes;

        void init() {
            try {
                int minBytes = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT);
                int capBytes = Math.max(minBytes, 6000 * 2);
                AudioTrack.Builder b = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setSampleRate(SAMPLE_RATE)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .setBufferSizeInBytes(capBytes);
                if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
                track = b.build();
                capacity = track.getBufferCapacityInFrames();
                target = Math.min(capacity, 2400);               // ~50 ms, grows only after underruns
                track.setBufferSizeInFrames(target);
                lastUnderruns = track.getUnderrunCount();
                active = true;
            } catch (Throwable t) {
                active = false;
            }
        }

        void resume() {
            if (track == null) return;
            try {
                short[] silence = new short[Math.max(1, target / 2)];
                track.write(silence, 0, silence.length);
                track.play();
            } catch (Throwable ignored) { }
        }

        void pause() {
            if (track == null) return;
            try {
                track.pause();
                track.flush();
            } catch (Throwable ignored) { }
        }

        void write(short[] d, int n) {
            int off = 0;
            while (off < n) {
                int w = track.write(d, off, n - off);
                if (w < 0) { active = false; return; }
                off += w;
            }
            if (++writes % 120 == 0) {
                int u = track.getUnderrunCount();
                if (u > lastUnderruns) {
                    lastUnderruns = u;
                    if (target + 400 <= capacity) {
                        target += 400;
                        track.setBufferSizeInFrames(target);
                    }
                }
            }
        }

        void release() {
            if (track != null) {
                try { track.stop(); } catch (Throwable ignored) { }
                track.release();
                track = null;
            }
        }
    }
}
