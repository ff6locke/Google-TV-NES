package com.example.nestv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Environment;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** D-pad friendly folder / .nes file browser used when ACTION_OPEN_DOCUMENT(_TREE) is unavailable. */
final class FileChooser {
    interface Callback { void onChosen(File f); }

    private static final Object SELECT = new Object();
    private static final Object UP = new Object();

    private final Activity act;
    private final boolean dirMode;
    private final Callback cb;
    private final List<Object> entries = new ArrayList<>();
    private final ArrayAdapter<String> adapter;
    private final AlertDialog dialog;
    private File cur;

    static void show(Activity act, boolean dirMode, String title, Callback cb) {
        new FileChooser(act, dirMode, title, cb);
    }

    private FileChooser(Activity act, boolean dirMode, String title, Callback cb) {
        this.act = act;
        this.dirMode = dirMode;
        this.cb = cb;
        ListView lv = new ListView(act);
        adapter = new ArrayAdapter<>(act, android.R.layout.simple_list_item_1);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((p, v, pos, id) -> onClick(entries.get(pos)));
        dialog = new AlertDialog.Builder(act).setTitle(title).setView(lv)
                .setNegativeButton("Cancel", null).create();
        load(null);
        dialog.show();
    }

    private void load(File dir) {
        cur = dir;
        entries.clear();
        adapter.clear();
        if (dir == null) {
            addRoot(Environment.getExternalStorageDirectory(), "Internal storage");
            File[] vols = new File("/storage").listFiles();
            if (vols != null) {
                for (File v : vols) {
                    String n = v.getName();
                    if (n.equals("emulated") || n.equals("self") || !v.isDirectory()) continue;
                    addRoot(v, "USB / SD: " + n);
                }
            }
            dialog.setTitle(dialogTitle("Choose location"));
        } else {
            if (dirMode) add(SELECT, "[ Use this folder ]");
            add(UP, ".. (up)");
            File[] kids = dir.listFiles();
            if (kids == null) {
                Toast.makeText(act, "Cannot read this folder (storage permission?)", Toast.LENGTH_LONG).show();
            } else {
                Arrays.sort(kids, (a, b) -> {
                    if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                    return a.getName().compareToIgnoreCase(b.getName());
                });
                for (File k : kids) {
                    if (k.getName().startsWith(".")) continue;
                    if (k.isDirectory()) add(k, k.getName() + "/");
                    else if (!dirMode && k.getName().toLowerCase(Locale.ROOT).endsWith(".nes")) add(k, k.getName());
                }
            }
            dialog.setTitle(dialogTitle(dir.getAbsolutePath()));
        }
        adapter.notifyDataSetChanged();
    }

    private String dialogTitle(String s) { return s; }

    private void addRoot(File f, String label) { add(f, label); }

    private void add(Object entry, String label) {
        entries.add(entry);
        adapter.add(label);
    }

    private void onClick(Object e) {
        if (e == SELECT) {
            dialog.dismiss();
            cb.onChosen(cur);
        } else if (e == UP) {
            File parent = cur == null ? null : cur.getParentFile();
            // stop at the storage roots
            if (parent == null || parent.getAbsolutePath().equals("/") || parent.getAbsolutePath().equals("/storage")) {
                load(null);
            } else {
                load(parent);
            }
        } else if (e instanceof File) {
            File f = (File) e;
            if (f.isDirectory()) {
                load(f);
            } else {
                dialog.dismiss();
                cb.onChosen(f);
            }
        }
    }
}
