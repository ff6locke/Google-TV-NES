package com.example.nestv;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int RC_ROM = 1, RC_ROM_DIR = 2, RC_SAVE_DIR = 3, RC_PERM = 4;

    private SharedPreferences prefs;
    private Button continueBtn, romDirBtn, saveDirBtn;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private final List<Storage.Rom> roms = new ArrayList<>();
    private int pendingFallback = -1;

    @Override
    protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("nestv", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF101418);
        int pad = dp(40);
        root.setPadding(pad, dp(24), pad, dp(24));

        TextView title = new TextView(this);
        title.setText("NES for Google TV");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        root.addView(title);

        continueBtn = button(v -> continueLast());
        Button openBtn = button(v -> pick(RC_ROM));
        openBtn.setText("Open ROM file...");
        romDirBtn = button(v -> pick(RC_ROM_DIR));
        saveDirBtn = button(v -> pick(RC_SAVE_DIR));
        root.addView(continueBtn);
        root.addView(openBtn);
        root.addView(romDirBtn);
        root.addView(saveDirBtn);

        listView = new ListView(this);
        listView.setSelector(new ColorDrawable(0x553399FF));
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1) {
            @Override
            public View getView(int pos, View cv, android.view.ViewGroup parent) {
                TextView t = (TextView) super.getView(pos, cv, parent);
                t.setTextColor(Color.WHITE);
                t.setTextSize(20);
                return t;
            }
        };
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < roms.size()) launch(roms.get(pos).loc, roms.get(pos).name);
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = dp(12);
        root.addView(listView, lp);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLabels();
        refreshRoms();
        continueBtn.requestFocus();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private Button button(View.OnClickListener l) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setTextSize(18);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setOnClickListener(l);
        b.setFocusable(true);
        return b;
    }

    private void refreshLabels() {
        String last = prefs.getString("lastName", null);
        continueBtn.setVisibility(last == null ? View.GONE : View.VISIBLE);
        if (last != null) continueBtn.setText("Continue: " + last);
        romDirBtn.setText("ROM folder: " + (prefs.getString("romDir", null) == null
                ? "(not set)" : Storage.describe(this, prefs.getString("romDir", null))));
        saveDirBtn.setText("Save folder: " + Storage.describe(this, prefs.getString("saveDir", null)));
    }

    private void refreshRoms() {
        final String dir = prefs.getString("romDir", null);
        new Thread(() -> {
            final List<Storage.Rom> found = Storage.listRoms(this, dir);
            runOnUiThread(() -> {
                roms.clear();
                roms.addAll(found);
                adapter.clear();
                for (Storage.Rom r : found) adapter.add(r.name);
                if (dir == null) adapter.add("Set a ROM folder (or use \"Open ROM file...\")");
                else if (found.isEmpty()) adapter.add("No .nes files found in the ROM folder");
                adapter.notifyDataSetChanged();
            });
        }).start();
    }

    private void continueLast() {
        String loc = prefs.getString("lastRom", null);
        String name = prefs.getString("lastName", null);
        if (loc != null && name != null) launch(loc, name);
    }

    private void launch(String loc, String name) {
        prefs.edit().putString("lastRom", loc).putString("lastName", name).apply();
        Intent i = new Intent(this, EmuActivity.class);
        i.putExtra(EmuActivity.EXTRA_ROM, loc);
        i.putExtra(EmuActivity.EXTRA_NAME, name);
        i.putExtra(EmuActivity.EXTRA_SAVE_DIR, prefs.getString("saveDir", null));
        startActivity(i);
    }

    // ---- pickers --------------------------------------------------------------------------------

    private void pick(int kind) {
        Intent i;
        if (kind == RC_ROM) {
            i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        } else {
            i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        }
        try {
            startActivityForResult(i, kind);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, "No system file picker found - using built-in browser", Toast.LENGTH_LONG).show();
            fallback(kind);
        }
    }

    private void fallback(int kind) {
        if (!ensureFileAccess()) {
            pendingFallback = kind;
            return;
        }
        pendingFallback = -1;
        final boolean dirMode = kind != RC_ROM;
        String title = kind == RC_ROM ? "Choose a .nes file" : kind == RC_ROM_DIR ? "Choose ROM folder" : "Choose save folder";
        FileChooser.show(this, dirMode, title, (File f) -> {
            if (kind == RC_ROM) {
                launch(f.getAbsolutePath(), f.getName());
            } else if (kind == RC_ROM_DIR) {
                prefs.edit().putString("romDir", f.getAbsolutePath()).apply();
                refreshLabels();
                refreshRoms();
            } else {
                prefs.edit().putString("saveDir", f.getAbsolutePath()).apply();
                refreshLabels();
            }
        });
    }

    private boolean ensureFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Environment.isExternalStorageManager()) return true;
            Toast.makeText(this, "Grant \"All files access\" to browse storage, then try again", Toast.LENGTH_LONG).show();
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception ignored) { }
            }
            return false;
        }
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, RC_PERM);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == RC_PERM && pendingFallback >= 0) fallback(pendingFallback);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
        if (req != RC_ROM) flags |= Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        try {
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) { }
        if (req == RC_ROM) {
            launch(uri.toString(), Storage.nameOf(this, uri.toString()));
        } else if (req == RC_ROM_DIR) {
            prefs.edit().putString("romDir", uri.toString()).apply();
        } else if (req == RC_SAVE_DIR) {
            prefs.edit().putString("saveDir", uri.toString()).apply();
            Toast.makeText(this, "Save folder set", Toast.LENGTH_SHORT).show();
        }
    }
}
