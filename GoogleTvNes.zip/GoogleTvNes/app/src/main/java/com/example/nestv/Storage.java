package com.example.nestv;

import android.content.Context;
import android.net.Uri;
import android.provider.DocumentsContract;

import androidx.documentfile.provider.DocumentFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Locations are plain strings: "content://..." (Storage Access Framework) or an absolute file path.
 * An empty / null save folder means the app-private default folder.
 */
final class Storage {
    private Storage() {}

    static final class Rom {
        final String name;
        final String loc;

        Rom(String name, String loc) {
            this.name = name;
            this.loc = loc;
        }
    }

    static boolean isContent(String s) { return s != null && s.startsWith("content:"); }

    static File defaultSaveDir(Context c) {
        File base = c.getExternalFilesDir(null);
        if (base == null) base = c.getFilesDir();
        File d = new File(base, "saves");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    /** Human readable name for a folder / file location. */
    static String describe(Context c, String loc) {
        if (loc == null || loc.isEmpty()) return "App folder (" + defaultSaveDir(c).getAbsolutePath() + ")";
        if (isContent(loc)) {
            try {
                Uri u = Uri.parse(loc);
                DocumentFile f = DocumentsContract.isTreeUri(u) ? DocumentFile.fromTreeUri(c, u)
                        : DocumentFile.fromSingleUri(c, u);
                if (f != null && f.getName() != null) return f.getName();
            } catch (Exception ignored) { }
            return loc;
        }
        return loc;
    }

    static String nameOf(Context c, String loc) {
        if (isContent(loc)) {
            try {
                DocumentFile f = DocumentFile.fromSingleUri(c, Uri.parse(loc));
                if (f != null && f.getName() != null) return f.getName();
            } catch (Exception ignored) { }
            return "game.nes";
        }
        return new File(loc).getName();
    }

    static byte[] readAll(Context c, String loc) throws IOException {
        try (InputStream in = isContent(loc) ? c.getContentResolver().openInputStream(Uri.parse(loc))
                : new FileInputStream(loc)) {
            if (in == null) throw new IOException("Cannot open " + loc);
            return readStream(in);
        }
    }

    private static byte[] readStream(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
        byte[] buf = new byte[32 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            if (bo.size() > 32 * 1024 * 1024) throw new IOException("File too large");
        }
        return bo.toByteArray();
    }

    // ---- ROM listing ------------------------------------------------------------------------

    static List<Rom> listRoms(Context c, String dirLoc) {
        List<Rom> out = new ArrayList<>();
        if (dirLoc == null || dirLoc.isEmpty()) return out;
        try {
            if (isContent(dirLoc)) {
                DocumentFile dir = DocumentFile.fromTreeUri(c, Uri.parse(dirLoc));
                if (dir != null) scanTree(dir, 1, out);
            } else {
                scanFiles(new File(dirLoc), 2, out);
            }
        } catch (Exception ignored) { }
        Collections.sort(out, (a, b) -> a.name.compareToIgnoreCase(b.name));
        return out;
    }

    private static void scanTree(DocumentFile dir, int depth, List<Rom> out) {
        DocumentFile[] kids = dir.listFiles();
        for (DocumentFile f : kids) {
            String n = f.getName();
            if (n == null) continue;
            if (f.isDirectory()) {
                if (depth > 0) scanTree(f, depth - 1, out);
            } else if (n.toLowerCase(Locale.ROOT).endsWith(".nes")) {
                out.add(new Rom(n, f.getUri().toString()));
            }
        }
    }

    private static void scanFiles(File dir, int depth, List<Rom> out) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File f : kids) {
            if (f.isDirectory()) {
                if (depth > 0 && !f.getName().startsWith(".")) scanFiles(f, depth - 1, out);
            } else if (f.getName().toLowerCase(Locale.ROOT).endsWith(".nes")) {
                out.add(new Rom(f.getName(), f.getAbsolutePath()));
            }
        }
    }

    // ---- saves ------------------------------------------------------------------------------

    static String saveFileName(String romName) {
        String base = romName;
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        return base.replaceAll("[\\\\/:*?\"<>|]", "_") + ".sav";
    }

    static String stateFileName(String romName, int slot) {
        return saveFileName(romName).replaceAll("\\.sav$", "") + ".ss" + slot;
    }

    /** Names of all files directly inside the save folder (used to show which state slots are filled). */
    static java.util.Set<String> listNames(Context c, String dirLoc) {
        java.util.Set<String> out = new java.util.HashSet<>();
        try {
            if (isContent(dirLoc)) {
                DocumentFile dir = DocumentFile.fromTreeUri(c, Uri.parse(dirLoc));
                if (dir != null) for (DocumentFile f : dir.listFiles()) if (f.getName() != null) out.add(f.getName());
            } else {
                File dir = (dirLoc == null || dirLoc.isEmpty()) ? defaultSaveDir(c) : new File(dirLoc);
                String[] names = dir.list();
                if (names != null) java.util.Collections.addAll(out, names);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static DocumentFile findSaveDoc(Context c, String dirLoc, String name) {
        DocumentFile dir = DocumentFile.fromTreeUri(c, Uri.parse(dirLoc));
        if (dir == null) return null;
        DocumentFile f = dir.findFile(name);
        if (f == null) f = dir.findFile(name + ".bin"); // some providers append an extension
        return f;
    }

    /** @return save bytes, or null if no save exists yet. */
    static byte[] readSave(Context c, String dirLoc, String name) throws IOException {
        if (isContent(dirLoc)) {
            DocumentFile f = findSaveDoc(c, dirLoc, name);
            if (f == null || !f.isFile()) return null;
            try (InputStream in = c.getContentResolver().openInputStream(f.getUri())) {
                return in == null ? null : readStream(in);
            }
        }
        File dir = (dirLoc == null || dirLoc.isEmpty()) ? defaultSaveDir(c) : new File(dirLoc);
        File f = new File(dir, name);
        if (!f.isFile()) return null;
        try (InputStream in = new FileInputStream(f)) {
            return readStream(in);
        }
    }

    static void writeSave(Context c, String dirLoc, String name, byte[] data) throws IOException {
        if (isContent(dirLoc)) {
            DocumentFile dir = DocumentFile.fromTreeUri(c, Uri.parse(dirLoc));
            if (dir == null) throw new IOException("Save folder is not accessible");
            DocumentFile f = findSaveDoc(c, dirLoc, name);
            if (f == null) f = dir.createFile("application/octet-stream", name);
            if (f == null) throw new IOException("Cannot create " + name);
            try (OutputStream os = c.getContentResolver().openOutputStream(f.getUri(), "wt")) {
                if (os == null) throw new IOException("Cannot open " + name);
                os.write(data);
                os.flush();
            }
            return;
        }
        File dir = (dirLoc == null || dirLoc.isEmpty()) ? defaultSaveDir(c) : new File(dirLoc);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File tmp = new File(dir, name + ".tmp");
        try (FileOutputStream os = new FileOutputStream(tmp)) {
            os.write(data);
            os.getFD().sync();
        }
        File dest = new File(dir, name);
        //noinspection ResultOfMethodCallIgnored
        dest.delete();
        if (!tmp.renameTo(dest)) throw new IOException("Cannot write " + dest);
    }
}
