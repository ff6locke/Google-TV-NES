package com.example.nestv;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import com.example.nestv.core.Nes;

/**
 * On-screen NES controller. Every element can be dragged to a new place in edit mode, the whole
 * overlay has an adjustable opacity and size, and positions are stored as screen fractions.
 */
final class TouchControlsView extends View {
    interface Listener {
        void onPad(int bits);
        void onFastForwardToggle();
        void onMenu();
        void onLayoutChanged();
        void onEditDone();
    }

    static final int DPAD = 0, BTN_A = 1, BTN_B = 2, SELECT = 3, START = 4, FF = 5, MENU = 6, COUNT = 7;
    private static final String[] NAMES = {"dpad", "a", "b", "select", "start", "ff", "menu"};
    private static final float[] DEF_X = {0.13f, 0.91f, 0.81f, 0.40f, 0.60f, 0.91f, 0.09f};
    private static final float[] DEF_Y = {0.70f, 0.60f, 0.76f, 0.92f, 0.92f, 0.12f, 0.12f};
    // portrait (phone held upright): picture at the top, buttons in the lower half
    private static final float[] DEF_PX = {0.27f, 0.87f, 0.69f, 0.36f, 0.64f, 0.90f, 0.10f};
    private static final float[] DEF_PY = {0.78f, 0.71f, 0.84f, 0.50f, 0.50f, 0.50f, 0.50f};

    /** Layouts per orientation: index 0 = landscape, 1 = portrait. cx/cy point at the active one. */
    private final float[][] lx = new float[2][COUNT], ly = new float[2][COUNT];
    private float[] cx = lx[0], cy = ly[0];
    private int orient;
    private boolean haptics = true;
    private int alphaPct = 35;
    private float scale = 1f;
    private boolean editMode;
    private int selected;
    private int dragging = -1;
    private float dragDx, dragDy;
    private int pressedBits;
    private boolean ffOn;
    private Listener listener;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();

    TouchControlsView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        for (int i = 0; i < COUNT; i++) {
            lx[0][i] = DEF_X[i]; ly[0][i] = DEF_Y[i];
            lx[1][i] = DEF_PX[i]; ly[1][i] = DEF_PY[i];
        }
    }

    void setHaptics(boolean on) { haptics = on; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        int o = h > w ? 1 : 0;
        if (o != orient) {
            orient = o;
            cx = lx[o];
            cy = ly[o];
        }
    }

    void setListener(Listener l) { listener = l; }

    void setAlphaPct(int p) { alphaPct = Math.max(5, Math.min(100, p)); invalidate(); }

    void setScale(float s) { scale = s; invalidate(); }

    void setFastForwardOn(boolean on) { ffOn = on; invalidate(); }

    boolean isEditMode() { return editMode; }

    void setEditMode(boolean on) {
        editMode = on;
        dragging = -1;
        if (!on) { pressedBits = 0; }
        invalidate();
    }

    void resetLayout() {
        float[] dx = orient == 1 ? DEF_PX : DEF_X, dy = orient == 1 ? DEF_PY : DEF_Y;
        for (int i = 0; i < COUNT; i++) { cx[i] = dx[i]; cy[i] = dy[i]; }
        invalidate();
    }

    void loadLayout(SharedPreferences p) {
        for (int o = 0; o < 2; o++) {
            String pre = o == 1 ? "ctl_p_" : "ctl_";
            for (int i = 0; i < COUNT; i++) {
                lx[o][i] = p.getFloat(pre + NAMES[i] + "_x", o == 1 ? DEF_PX[i] : DEF_X[i]);
                ly[o][i] = p.getFloat(pre + NAMES[i] + "_y", o == 1 ? DEF_PY[i] : DEF_Y[i]);
            }
        }
        invalidate();
    }

    void saveLayout(SharedPreferences p) {
        SharedPreferences.Editor e = p.edit();
        for (int o = 0; o < 2; o++) {
            String pre = o == 1 ? "ctl_p_" : "ctl_";
            for (int i = 0; i < COUNT; i++) {
                e.putFloat(pre + NAMES[i] + "_x", lx[o][i]);
                e.putFloat(pre + NAMES[i] + "_y", ly[o][i]);
            }
        }
        e.apply();
    }

    // ---- geometry -----------------------------------------------------------------------------

    private float unit() { return Math.min(getWidth(), getHeight()) * scale; }

    private float radius(int i) {
        switch (i) {
            case DPAD: return 0.20f * unit();
            case BTN_A:
            case BTN_B: return 0.085f * unit();
            case FF: return 0.055f * unit();
            case MENU: return 0.045f * unit();
            default: return 0.05f * unit();   // select / start: used for the pill's half height * 1.4
        }
    }

    private float halfW(int i) { return (i == SELECT || i == START) ? 0.085f * unit() : radius(i); }

    private float halfH(int i) { return (i == SELECT || i == START) ? 0.035f * unit() : radius(i); }

    private boolean hit(int i, float x, float y, float slop) {
        float px = cx[i] * getWidth(), py = cy[i] * getHeight();
        if (i == SELECT || i == START) {
            return Math.abs(x - px) <= halfW(i) * slop && Math.abs(y - py) <= halfH(i) * slop * 1.8f;
        }
        float dx = x - px, dy = y - py, r = radius(i) * slop;
        return dx * dx + dy * dy <= r * r;
    }

    private int bitsAt(float x, float y) {
        int bits = 0;
        float px = cx[DPAD] * getWidth(), py = cy[DPAD] * getHeight(), r = radius(DPAD);
        float dx = x - px, dy = y - py;
        if (dx * dx + dy * dy <= r * r * 1.9f) {
            float th = r * 0.30f;
            if (dx > th) bits |= Nes.BTN_RIGHT;
            if (dx < -th) bits |= Nes.BTN_LEFT;
            if (dy > th) bits |= Nes.BTN_DOWN;
            if (dy < -th) bits |= Nes.BTN_UP;
        }
        if (hit(BTN_A, x, y, 1.25f)) bits |= Nes.BTN_A;
        if (hit(BTN_B, x, y, 1.25f)) bits |= Nes.BTN_B;
        if (hit(SELECT, x, y, 1.2f)) bits |= Nes.BTN_SELECT;
        if (hit(START, x, y, 1.2f)) bits |= Nes.BTN_START;
        return bits;
    }

    // ---- touch --------------------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (editMode) return editTouch(e);
        int action = e.getActionMasked();
        int skip = (action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_UP) ? e.getActionIndex() : -1;
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex();
            float x = e.getX(i), y = e.getY(i);
            if (listener != null) {
                if (hit(FF, x, y, 1.3f)) listener.onFastForwardToggle();
                else if (hit(MENU, x, y, 1.3f)) listener.onMenu();
            }
        }
        int bits = 0;
        if (action != MotionEvent.ACTION_CANCEL) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (i == skip) continue;
                bits |= bitsAt(e.getX(i), e.getY(i));
            }
        }
        if (bits != pressedBits) {
            if (haptics && (bits & ~pressedBits) != 0) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            pressedBits = bits;
            if (listener != null) listener.onPad(bits);
            invalidate();
        }
        return true;
    }

    private boolean doneHit(float x, float y) {
        float w = getWidth(), h = getHeight();
        return Math.abs(x - w / 2f) < 0.09f * w && y < 0.16f * h && y > 0.04f * h;
    }

    private boolean editTouch(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (doneHit(x, y)) {
                    if (listener != null) listener.onEditDone();
                    return true;
                }
                dragging = -1;
                for (int i = COUNT - 1; i >= 0; i--) {
                    if (hit(i, x, y, 1.2f)) {
                        dragging = i;
                        selected = i;
                        dragDx = x - cx[i] * getWidth();
                        dragDy = y - cy[i] * getHeight();
                        break;
                    }
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging >= 0) {
                    cx[dragging] = clamp((x - dragDx) / getWidth());
                    cy[dragging] = clamp((y - dragDy) / getHeight());
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging >= 0 && listener != null) listener.onLayoutChanged();
                dragging = -1;
                return true;
            default:
                return true;
        }
    }

    private static float clamp(float v) { return Math.max(0.03f, Math.min(0.97f, v)); }

    /** Remote / keyboard control in edit mode. @return true if the key was used. */
    boolean editKey(int keyCode) {
        float step = 0.015f;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT: cx[selected] = clamp(cx[selected] - step); break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: cx[selected] = clamp(cx[selected] + step); break;
            case KeyEvent.KEYCODE_DPAD_UP: cy[selected] = clamp(cy[selected] - step); break;
            case KeyEvent.KEYCODE_DPAD_DOWN: cy[selected] = clamp(cy[selected] + step); break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                selected = (selected + 1) % COUNT;
                break;
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_BUTTON_B:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_START:
                if (listener != null) listener.onEditDone();
                return true;
            default:
                return false;
        }
        if (listener != null) listener.onLayoutChanged();
        invalidate();
        return true;
    }

    // ---- drawing ------------------------------------------------------------------------------

    private int a(float f) { return Math.max(0, Math.min(255, (int) (alphaPct * 2.55f * f))); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float boost = editMode ? 1.8f : 1f;
        stroke.setStrokeWidth(Math.max(2f, unit() * 0.008f));

        // d-pad
        {
            float px = cx[DPAD] * w, py = cy[DPAD] * h, r = radius(DPAD);
            fill.setColor(Color.argb(a(0.35f * boost), 255, 255, 255));
            c.drawCircle(px, py, r, fill);
            stroke.setColor(Color.argb(a(1f * boost), 255, 255, 255));
            c.drawCircle(px, py, r, stroke);
            drawArrow(c, px, py, r, 0, -1, (pressedBits & Nes.BTN_UP) != 0, boost);
            drawArrow(c, px, py, r, 0, 1, (pressedBits & Nes.BTN_DOWN) != 0, boost);
            drawArrow(c, px, py, r, -1, 0, (pressedBits & Nes.BTN_LEFT) != 0, boost);
            drawArrow(c, px, py, r, 1, 0, (pressedBits & Nes.BTN_RIGHT) != 0, boost);
            if (editMode && selected == DPAD) highlight(c, px, py, r * 1.1f);
        }
        round(c, BTN_A, "A", (pressedBits & Nes.BTN_A) != 0, w, h, boost);
        round(c, BTN_B, "B", (pressedBits & Nes.BTN_B) != 0, w, h, boost);
        round(c, FF, ffOn ? ">>*" : ">>", ffOn, w, h, boost);
        round(c, MENU, "II", false, w, h, boost);
        pill(c, SELECT, "SELECT", (pressedBits & Nes.BTN_SELECT) != 0, w, h, boost);
        pill(c, START, "START", (pressedBits & Nes.BTN_START) != 0, w, h, boost);

        if (editMode) {
            text.setColor(Color.WHITE);
            text.setTextSize(h / 28f);
            c.drawText("Drag buttons to move them  -  remote: arrows move, OK picks next", w / 2f, h * 0.30f, text);
            rect.set(w / 2f - 0.09f * w, 0.04f * h, w / 2f + 0.09f * w, 0.16f * h);
            fill.setColor(Color.argb(220, 40, 160, 80));
            c.drawRoundRect(rect, 16f, 16f, fill);
            text.setTextSize(h / 20f);
            c.drawText("DONE", w / 2f, 0.04f * h + 0.08f * h + h / 60f, text);
        }
    }

    private void highlight(Canvas c, float x, float y, float r) {
        stroke.setColor(Color.YELLOW);
        c.drawCircle(x, y, r, stroke);
    }

    private void drawArrow(Canvas c, float px, float py, float r, int dx, int dy, boolean on, float boost) {
        float d = r * 0.62f, s = r * 0.16f;
        float ax = px + dx * d, ay = py + dy * d;
        path.reset();
        if (dx == 0) {
            path.moveTo(ax, ay + dy * s);
            path.lineTo(ax - s * 1.3f, ay - dy * s);
            path.lineTo(ax + s * 1.3f, ay - dy * s);
        } else {
            path.moveTo(ax + dx * s, ay);
            path.lineTo(ax - dx * s, ay - s * 1.3f);
            path.lineTo(ax - dx * s, ay + s * 1.3f);
        }
        path.close();
        fill.setColor(Color.argb(a((on ? 1f : 0.6f) * boost), 255, 255, 255));
        c.drawPath(path, fill);
    }

    private void round(Canvas c, int i, String label, boolean on, float w, float h, float boost) {
        float px = cx[i] * w, py = cy[i] * h, r = radius(i);
        fill.setColor(Color.argb(a((on ? 0.8f : 0.35f) * boost), 255, 255, 255));
        c.drawCircle(px, py, r, fill);
        stroke.setColor(Color.argb(a(boost), 255, 255, 255));
        c.drawCircle(px, py, r, stroke);
        text.setColor(Color.argb(a(1f * boost), 255, 255, 255));
        text.setTextSize(r * 0.9f);
        c.drawText(label, px, py + r * 0.32f, text);
        if (editMode && selected == i) highlight(c, px, py, r * 1.15f);
    }

    private void pill(Canvas c, int i, String label, boolean on, float w, float h, float boost) {
        float px = cx[i] * w, py = cy[i] * h, hw = halfW(i), hh = halfH(i);
        rect.set(px - hw, py - hh, px + hw, py + hh);
        fill.setColor(Color.argb(a((on ? 0.8f : 0.35f) * boost), 255, 255, 255));
        c.drawRoundRect(rect, hh, hh, fill);
        stroke.setColor(Color.argb(a(boost), 255, 255, 255));
        c.drawRoundRect(rect, hh, hh, stroke);
        text.setColor(Color.argb(a(1f * boost), 255, 255, 255));
        text.setTextSize(hh * 1.1f);
        c.drawText(label, px, py + hh * 0.38f, text);
        if (editMode && selected == i) {
            stroke.setColor(Color.YELLOW);
            rect.inset(-hh * 0.3f, -hh * 0.3f);
            c.drawRoundRect(rect, hh, hh, stroke);
        }
    }
}
