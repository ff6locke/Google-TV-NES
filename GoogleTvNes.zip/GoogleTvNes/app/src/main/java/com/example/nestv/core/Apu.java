package com.example.nestv.core;

/** NES APU, clocked once per CPU cycle, producing 16-bit mono PCM at the requested sample rate. */
public final class Apu {
    private static final int CPU_HZ = 1789773;

    private static final int[] LENGTHS = {
        10, 254, 20, 2, 40, 4, 80, 6, 160, 8, 60, 10, 14, 12, 26, 14,
        12, 16, 24, 18, 48, 20, 96, 22, 192, 24, 72, 26, 16, 28, 32, 30
    };
    private static final int[][] DUTY = {
        {0, 1, 0, 0, 0, 0, 0, 0}, {0, 1, 1, 0, 0, 0, 0, 0}, {0, 1, 1, 1, 1, 0, 0, 0}, {1, 0, 0, 1, 1, 1, 1, 1}
    };
    private static final int[] NOISE_PERIODS = {4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068};
    private static final int[] DMC_RATES = {428, 380, 340, 320, 286, 254, 226, 214, 190, 160, 142, 128, 106, 84, 72, 54};

    private static final float[] PULSE_TABLE = new float[31];
    private static final float[] TND_TABLE = new float[203];

    static {
        for (int i = 1; i < 31; i++) PULSE_TABLE[i] = 95.52f / (8128f / i + 100f);
        for (int i = 1; i < 203; i++) TND_TABLE[i] = 163.67f / (24329f / i + 100f);
    }

    // ---- channels -----------------------------------------------------------------------------

    private static final class Envelope {
        boolean start, loop, constant;
        int volume, divider, decay;

        void clock() {
            if (start) {
                start = false;
                decay = 15;
                divider = volume;
            } else if (divider == 0) {
                divider = volume;
                if (decay > 0) decay--;
                else if (loop) decay = 15;
            } else {
                divider--;
            }
        }

        int output() { return constant ? volume : decay; }
    }

    private static final class Pulse {
        final boolean isPulse1;
        final Envelope env = new Envelope();
        boolean enabled, sweepEnabled, sweepNegate, sweepReload;
        int duty, seq, timer, period, length, sweepPeriod, sweepShift, sweepDivider;
        int out;

        Pulse(boolean p1) { isPulse1 = p1; }

        void write(int reg, int v) {
            switch (reg) {
                case 0:
                    duty = v >> 6;
                    env.loop = (v & 0x20) != 0;
                    env.constant = (v & 0x10) != 0;
                    env.volume = v & 0x0F;
                    break;
                case 1:
                    sweepEnabled = (v & 0x80) != 0;
                    sweepPeriod = (v >> 4) & 7;
                    sweepNegate = (v & 8) != 0;
                    sweepShift = v & 7;
                    sweepReload = true;
                    break;
                case 2:
                    period = (period & 0x700) | v;
                    break;
                default:
                    period = (period & 0xFF) | ((v & 7) << 8);
                    if (enabled) length = LENGTHS[v >> 3];
                    seq = 0;
                    env.start = true;
                    break;
            }
            update();
        }

        int target() {
            int d = period >> sweepShift;
            int t = sweepNegate ? period - d - (isPulse1 ? 1 : 0) : period + d;
            return Math.max(t, 0);
        }

        boolean muted() { return period < 8 || (!sweepNegate && target() > 0x7FF); }

        void tickTimer() {
            if (timer == 0) {
                timer = period;
                seq = (seq + 1) & 7;
                update();
            } else {
                timer--;
            }
        }

        void clockLength() {
            if (!env.loop && length > 0) {
                length--;
                update();
            }
        }

        void clockSweep() {
            if (sweepDivider == 0 && sweepEnabled && sweepShift > 0 && !muted()) period = target();
            if (sweepDivider == 0 || sweepReload) {
                sweepDivider = sweepPeriod;
                sweepReload = false;
            } else {
                sweepDivider--;
            }
            update();
        }

        void clockEnvelope() {
            env.clock();
            update();
        }

        void update() {
            out = (length == 0 || DUTY[duty][seq] == 0 || muted()) ? 0 : env.output();
        }
    }

    private static final class Triangle {
        boolean enabled, control, reloadFlag;
        int reloadValue, linear, period, timer, seq, length, out;

        void write(int reg, int v) {
            switch (reg) {
                case 0:
                    control = (v & 0x80) != 0;
                    reloadValue = v & 0x7F;
                    break;
                case 2:
                    period = (period & 0x700) | v;
                    break;
                case 3:
                    period = (period & 0xFF) | ((v & 7) << 8);
                    if (enabled) length = LENGTHS[v >> 3];
                    reloadFlag = true;
                    break;
                default:
                    break;
            }
        }

        void tick() {
            if (timer == 0) {
                timer = period;
                if (length > 0 && linear > 0 && period >= 2) {
                    seq = (seq + 1) & 31;
                    out = seq < 16 ? 15 - seq : seq - 16;
                }
            } else {
                timer--;
            }
        }

        void clockLinear() {
            if (reloadFlag) linear = reloadValue;
            else if (linear > 0) linear--;
            if (!control) reloadFlag = false;
        }

        void clockLength() {
            if (!control && length > 0) length--;
        }
    }

    private static final class Noise {
        final Envelope env = new Envelope();
        boolean enabled, mode;
        int shift = 1, timer = 4, period = 4, length, out;

        void write(int reg, int v) {
            switch (reg) {
                case 0:
                    env.loop = (v & 0x20) != 0;
                    env.constant = (v & 0x10) != 0;
                    env.volume = v & 0x0F;
                    break;
                case 2:
                    mode = (v & 0x80) != 0;
                    period = NOISE_PERIODS[v & 0x0F];
                    break;
                case 3:
                    if (enabled) length = LENGTHS[v >> 3];
                    env.start = true;
                    break;
                default:
                    break;
            }
            update();
        }

        void tick() {
            if (--timer <= 0) {
                timer = period;
                int fb = (shift & 1) ^ ((shift >> (mode ? 6 : 1)) & 1);
                shift = (shift >> 1) | (fb << 14);
                update();
            }
        }

        void clockLength() {
            if (!env.loop && length > 0) {
                length--;
                update();
            }
        }

        void clockEnvelope() {
            env.clock();
            update();
        }

        void update() { out = ((shift & 1) == 0 && length > 0) ? env.output() : 0; }
    }

    private final Pulse p1 = new Pulse(true), p2 = new Pulse(false);
    private final Triangle tri = new Triangle();
    private final Noise noise = new Noise();

    // DMC
    private boolean dmcIrqEnable, dmcLoop, dmcIrq, dmcSilence = true, dmcBufferEmpty = true;
    private int dmcRate = DMC_RATES[0], dmcTimer = DMC_RATES[0], dmcLevel, dmcShift, dmcBitsLeft = 8, dmcBuffer;
    private int dmcSampleAddr = 0xC000, dmcSampleLen = 1, dmcAddr = 0xC000, dmcBytesLeft;
    /** Set when the DMC wants a sample byte; the CPU services it by stalling for a few cycles. */
    public boolean dmcDmaPending;
    public int dmcDmaAddr;

    // frame counter
    private boolean fiveStep, irqInhibit, frameIrq;
    private int frameCycle, frameResetDelay;
    private long cycle;

    // output
    private final int sampleRate;
    private int sampleCounter;
    private float accum;
    private int accumCount;
    private float hpPrevIn, hpPrevOut, lp;
    private final float hpR, lpAlpha;
    public final transient short[] samples = new short[16384];
    public int sampleCount;

    public Apu(int sampleRate) {
        this.sampleRate = sampleRate;
        hpR = 1f - (float) (2 * Math.PI * 90.0 / sampleRate);
        float dt = 1f / sampleRate;
        float rc = (float) (1.0 / (2 * Math.PI * 14000.0));
        lpAlpha = dt / (rc + dt);
    }

    public boolean irq() { return frameIrq || dmcIrq; }

    // ---- registers ----------------------------------------------------------------------------

    public void write(int addr, int v) {
        if (addr < 0x4004) p1.write(addr & 3, v);
        else if (addr < 0x4008) p2.write(addr & 3, v);
        else if (addr < 0x400C) tri.write(addr & 3, v);
        else if (addr < 0x4010) noise.write(addr & 3, v);
        else if (addr < 0x4014) writeDmc(addr & 3, v);
        else if (addr == 0x4015) writeStatus(v);
        else if (addr == 0x4017) {
            fiveStep = (v & 0x80) != 0;
            irqInhibit = (v & 0x40) != 0;
            if (irqInhibit) frameIrq = false;
            frameResetDelay = (cycle & 1) == 0 ? 3 : 4;
        }
    }

    private void writeDmc(int reg, int v) {
        switch (reg) {
            case 0:
                dmcIrqEnable = (v & 0x80) != 0;
                dmcLoop = (v & 0x40) != 0;
                dmcRate = DMC_RATES[v & 0x0F];
                if (!dmcIrqEnable) dmcIrq = false;
                break;
            case 1:
                dmcLevel = v & 0x7F;
                break;
            case 2:
                dmcSampleAddr = 0xC000 | (v << 6);
                break;
            default:
                dmcSampleLen = (v << 4) | 1;
                break;
        }
    }

    private void writeStatus(int v) {
        p1.enabled = (v & 1) != 0;
        if (!p1.enabled) { p1.length = 0; p1.update(); }
        p2.enabled = (v & 2) != 0;
        if (!p2.enabled) { p2.length = 0; p2.update(); }
        tri.enabled = (v & 4) != 0;
        if (!tri.enabled) tri.length = 0;
        noise.enabled = (v & 8) != 0;
        if (!noise.enabled) { noise.length = 0; noise.update(); }
        if ((v & 0x10) != 0) {
            if (dmcBytesLeft == 0) {
                dmcAddr = dmcSampleAddr;
                dmcBytesLeft = dmcSampleLen;
                dmcRequestFill();
            }
        } else {
            dmcBytesLeft = 0;
        }
        dmcIrq = false;
    }

    public int readStatus() {
        int s = 0;
        if (p1.length > 0) s |= 1;
        if (p2.length > 0) s |= 2;
        if (tri.length > 0) s |= 4;
        if (noise.length > 0) s |= 8;
        if (dmcBytesLeft > 0) s |= 0x10;
        if (frameIrq) s |= 0x40;
        if (dmcIrq) s |= 0x80;
        frameIrq = false;
        return s;
    }

    // ---- DMC ------------------------------------------------------------------------------------

    private void dmcRequestFill() {
        if (dmcBufferEmpty && dmcBytesLeft > 0 && !dmcDmaPending) {
            dmcDmaPending = true;
            dmcDmaAddr = dmcAddr;
        }
    }

    /** Called by the CPU once the stalled DMA read has completed. */
    public void dmcDmaDone(int value) {
        dmcBuffer = value;
        dmcBufferEmpty = false;
        dmcAddr = (dmcAddr + 1) | 0x8000;
        dmcAddr &= 0xFFFF;
        if (--dmcBytesLeft == 0) {
            if (dmcLoop) {
                dmcAddr = dmcSampleAddr;
                dmcBytesLeft = dmcSampleLen;
            } else if (dmcIrqEnable) {
                dmcIrq = true;
            }
        }
    }

    private void dmcTick() {
        if (--dmcTimer <= 0) {
            dmcTimer = dmcRate;
            if (!dmcSilence) {
                if ((dmcShift & 1) != 0) {
                    if (dmcLevel <= 125) dmcLevel += 2;
                } else if (dmcLevel >= 2) {
                    dmcLevel -= 2;
                }
            }
            dmcShift >>= 1;
            if (--dmcBitsLeft == 0) {
                dmcBitsLeft = 8;
                if (dmcBufferEmpty) {
                    dmcSilence = true;
                } else {
                    dmcSilence = false;
                    dmcShift = dmcBuffer;
                    dmcBufferEmpty = true;
                    dmcRequestFill();
                }
            }
        }
    }

    // ---- frame counter ------------------------------------------------------------------------

    private void quarter() {
        p1.clockEnvelope();
        p2.clockEnvelope();
        tri.clockLinear();
        noise.clockEnvelope();
    }

    private void half() {
        p1.clockLength(); p1.clockSweep();
        p2.clockLength(); p2.clockSweep();
        tri.clockLength();
        noise.clockLength();
    }

    private void frameTick() {
        frameCycle++;
        if (frameResetDelay > 0 && --frameResetDelay == 0) {
            frameCycle = 0;
            if (fiveStep) { quarter(); half(); }
        }
        if (!fiveStep) {
            switch (frameCycle) {
                case 7457: quarter(); break;
                case 14913: quarter(); half(); break;
                case 22371: quarter(); break;
                case 29828: if (!irqInhibit) frameIrq = true; break;
                case 29829: quarter(); half(); if (!irqInhibit) frameIrq = true; break;
                case 29830: if (!irqInhibit) frameIrq = true; frameCycle = 0; break;
                default: break;
            }
        } else {
            switch (frameCycle) {
                case 7457: quarter(); break;
                case 14913: quarter(); half(); break;
                case 22371: quarter(); break;
                case 37281: quarter(); half(); break;
                case 37282: frameCycle = 0; break;
                default: break;
            }
        }
    }

    // ---- per-cycle ----------------------------------------------------------------------------

    public void tick() {
        frameTick();
        tri.tick();
        noise.tick();
        dmcTick();
        if ((cycle & 1) != 0) {
            p1.tickTimer();
            p2.tickTimer();
        }
        cycle++;

        float mix = PULSE_TABLE[p1.out + p2.out] + TND_TABLE[3 * tri.out + 2 * noise.out + dmcLevel];
        accum += mix;
        accumCount++;
        sampleCounter += sampleRate;
        if (sampleCounter >= CPU_HZ) {
            sampleCounter -= CPU_HZ;
            emit(accum / accumCount);
            accum = 0;
            accumCount = 0;
        }
    }

    private void emit(float x) {
        float hp = x - hpPrevIn + hpR * hpPrevOut;
        hpPrevIn = x;
        hpPrevOut = hp;
        lp += lpAlpha * (hp - lp);
        int s = (int) (lp * 50000f);
        if (s > 32767) s = 32767;
        else if (s < -32768) s = -32768;
        if (sampleCount < samples.length) samples[sampleCount++] = (short) s;
    }
}
