package com.example.nestv.core;

import java.io.IOException;
import java.util.Arrays;

/** Parsed iNES / NES 2.0 ROM image. */
public final class Cartridge {
    public byte[] prg;
    public byte[] chr;          // CHR-ROM, or 8 KB of CHR-RAM when chrRam == true
    public boolean chrRam;
    public int mapperId;
    public int submapper;
    public boolean battery;
    public boolean nes2;
    public int mirroring;       // one of Ppu.MIRROR_*
    public int nvramSize;       // NES 2.0 only (bytes), 0 = unknown

    private Cartridge() {}

    public static Cartridge parse(byte[] d) throws IOException {
        if (d == null || d.length < 16 || d[0] != 'N' || d[1] != 'E' || d[2] != 'S' || d[3] != 0x1A) {
            throw new IOException("Not an iNES ROM (missing NES<1A> header)");
        }
        Cartridge c = new Cartridge();
        int prgBanks = d[4] & 0xFF;
        int chrBanks = d[5] & 0xFF;
        int f6 = d[6] & 0xFF;
        int f7 = d[7] & 0xFF;

        c.nes2 = (f7 & 0x0C) == 0x08;
        c.battery = (f6 & 0x02) != 0;
        int mapper = f6 >> 4;
        if (c.nes2) {
            mapper |= (f7 & 0xF0) | ((d[8] & 0x0F) << 8);
            c.submapper = (d[8] >> 4) & 0x0F;
            prgBanks |= (d[9] & 0x0F) << 8;
            chrBanks |= ((d[9] >> 4) & 0x0F) << 8;
            int nv = (d[10] >> 4) & 0x0F;
            c.nvramSize = nv == 0 ? 0 : (64 << nv);
        } else {
            boolean clean = d[12] == 0 && d[13] == 0 && d[14] == 0 && d[15] == 0;
            if (clean) mapper |= (f7 & 0xF0);
        }
        c.mapperId = mapper;

        if ((f6 & 0x08) != 0) c.mirroring = Ppu.MIRROR_FOUR;
        else c.mirroring = (f6 & 0x01) != 0 ? Ppu.MIRROR_V : Ppu.MIRROR_H;

        int pos = 16;
        if ((f6 & 0x04) != 0) pos += 512; // trainer

        int prgSize = Math.max(1, prgBanks) * 0x4000;
        c.prg = new byte[prgSize];
        int avail = Math.max(0, Math.min(prgSize, d.length - pos));
        System.arraycopy(d, pos, c.prg, 0, avail);
        pos += prgSize;

        if (chrBanks == 0) {
            c.chrRam = true;
            c.chr = new byte[0x2000];
        } else {
            int chrSize = chrBanks * 0x2000;
            c.chr = new byte[chrSize];
            int a2 = Math.max(0, Math.min(chrSize, d.length - pos));
            if (a2 > 0) System.arraycopy(d, pos, c.chr, 0, a2);
        }
        return c;
    }

    @Override
    public String toString() {
        return "mapper=" + mapperId + " sub=" + submapper + " prg=" + (prg.length / 1024) + "K chr="
                + (chrRam ? "RAM" : (chr.length / 1024) + "K") + " battery=" + battery
                + " mirroring=" + mirroring + (nes2 ? " (NES2.0)" : "");
    }

    static boolean isPow2(int n) { return n > 0 && (n & (n - 1)) == 0; }

    @SuppressWarnings("unused")
    private static byte[] copy(byte[] a) { return Arrays.copyOf(a, a.length); }
}
