package com.example.nestv.core;

/**
 * 6502 (2A03). Every bus access is one CPU cycle: the PPU is advanced three dots, the APU and the
 * mapper one cycle, and interrupt lines are sampled with the same one-cycle delay as hardware.
 */
public final class Cpu {
    private static final int M_INDX = 0, M_ZP = 1, M_IMM = 2, M_ABS = 3, M_INDY = 4, M_ZPX = 5,
            M_ABSY = 6, M_ABSX = 7, M_ZPY = 8;

    private final transient Nes nes;
    private final transient Ppu ppu;
    private final transient Apu apu;
    private transient Mapper mapper;
    private final byte[] ram = new byte[0x800];

    private int a, x, y, sp, pc;
    private int fc, fz, fi, fd, fv, fn;
    public int openBus;
    public long cycles;

    private boolean needNmi, prevNeedNmi, prevNmiLine, runIrq, prevRunIrq;
    private int pendingDmaPage = -1;

    Cpu(Nes nes, Ppu ppu, Apu apu) {
        this.nes = nes;
        this.ppu = ppu;
        this.apu = apu;
    }

    void attach(Mapper m) { mapper = m; }

    /** Debug / test helper: read internal RAM without side effects. */
    public int peek(int addr) { return ram[addr & 0x7FF] & 0xFF; }

    public int getPc() { return pc; }

    /** Test helpers. */
    public void poke(int addr, int v) { ram[addr & 0x7FF] = (byte) v; }

    public void debugSet(int a, int x, int y, int sp, int pc, int p) {
        this.a = a; this.x = x; this.y = y; this.sp = sp; this.pc = pc;
        setP(p);
        needNmi = prevNeedNmi = runIrq = prevRunIrq = false;
    }

    public int[] debugGet() { return new int[]{a, x, y, sp, pc, getP(false)}; }

    public void reset() {
        a = x = y = 0;
        sp = 0xFD;
        fc = fz = fd = fv = fn = 0;
        fi = 1;
        needNmi = prevNeedNmi = prevNmiLine = runIrq = prevRunIrq = false;
        for (int i = 0; i < 5; i++) idle();
        int lo = read(0xFFFC);
        int hi = read(0xFFFD);
        pc = lo | (hi << 8);
    }

    // ---- bus ----------------------------------------------------------------------------------

    private int busRead(int addr) {
        int val;
        if (addr < 0x2000) {
            val = ram[addr & 0x7FF] & 0xFF;
        } else if (addr < 0x4000) {
            val = ppu.readReg(addr & 7);
        } else if (addr < 0x4020) {
            if (addr == 0x4015) {
                return apu.readStatus() | (openBus & 0x20);
            } else if (addr == 0x4016) {
                val = (openBus & 0xE0) | nes.readPad(0);
            } else if (addr == 0x4017) {
                val = (openBus & 0xE0) | nes.readPad(1);
            } else {
                val = openBus;
            }
        } else {
            val = mapper.cpuRead(addr);
            if (val < 0) val = openBus;
        }
        openBus = val;
        return val;
    }

    private void busWrite(int addr, int val) {
        openBus = val;
        if (addr < 0x2000) {
            ram[addr & 0x7FF] = (byte) val;
        } else if (addr < 0x4000) {
            ppu.writeReg(addr & 7, val);
        } else if (addr < 0x4020) {
            if (addr == 0x4014) pendingDmaPage = val;
            else if (addr == 0x4016) nes.writePadStrobe(val);
            else apu.write(addr, val);
        } else {
            mapper.cpuWrite(addr, val);
        }
    }

    private void startCycle(boolean read) {
        ppu.tick();
        if (!read) ppu.tick();
    }

    private void endCycle(boolean read) {
        ppu.tick();
        if (read) ppu.tick();
        cycles++;
        apu.tick();
        if (mapper.needsCpuClock) mapper.cpuClock();

        prevNeedNmi = needNmi;
        boolean nmi = ppu.nmiLine();
        if (!prevNmiLine && nmi) needNmi = true;
        prevNmiLine = nmi;
        prevRunIrq = runIrq;
        runIrq = (apu.irq() || mapper.irqAsserted) && fi == 0;
    }

    private int read(int addr) {
        if (apu.dmcDmaPending) dmcDma();
        startCycle(true);
        int v = busRead(addr);
        endCycle(true);
        return v;
    }

    private void write(int addr, int val) {
        startCycle(false);
        busWrite(addr, val & 0xFF);
        endCycle(false);
        if (pendingDmaPage >= 0) {
            int page = pendingDmaPage;
            pendingDmaPage = -1;
            runOamDma(page);
        }
    }

    private void idle() {
        startCycle(true);
        endCycle(true);
    }

    private void dmcDma() {
        apu.dmcDmaPending = false;
        idle();
        idle();
        idle();
        startCycle(true);
        int v = busRead(apu.dmcDmaAddr);
        endCycle(true);
        apu.dmcDmaDone(v);
    }

    private void runOamDma(int page) {
        idle();
        if ((cycles & 1) != 0) idle();
        int base = page << 8;
        for (int i = 0; i < 256; i++) {
            int v = read(base + i);
            write(0x2004, v);
        }
    }

    // ---- helpers -------------------------------------------------------------------------------

    private int fetch() {
        int v = read(pc);
        pc = (pc + 1) & 0xFFFF;
        return v;
    }

    private void push(int v) {
        write(0x100 | sp, v);
        sp = (sp - 1) & 0xFF;
    }

    private int pull() {
        sp = (sp + 1) & 0xFF;
        return read(0x100 | sp);
    }

    private int getP(boolean brk) {
        return fc | (fz << 1) | (fi << 2) | (fd << 3) | (brk ? 0x10 : 0) | 0x20 | (fv << 6) | (fn << 7);
    }

    private void setP(int p) {
        fc = p & 1;
        fz = (p >> 1) & 1;
        fi = (p >> 2) & 1;
        fd = (p >> 3) & 1;
        fv = (p >> 6) & 1;
        fn = (p >> 7) & 1;
    }

    private void setZN(int v) {
        fz = v == 0 ? 1 : 0;
        fn = (v >> 7) & 1;
    }

    private void adc(int m) {
        int r = a + m + fc;
        fv = ((~(a ^ m) & (a ^ r)) >> 7) & 1;
        fc = r >> 8;
        a = r & 0xFF;
        setZN(a);
    }

    private void sbc(int m) { adc(m ^ 0xFF); }

    private void cmp(int reg, int m) {
        int r = reg - m;
        fc = r >= 0 ? 1 : 0;
        setZN(r & 0xFF);
    }

    private int asl(int m) { fc = m >> 7; int r = (m << 1) & 0xFF; setZN(r); return r; }

    private int lsr(int m) { fc = m & 1; int r = m >> 1; setZN(r); return r; }

    private int rol(int m) { int c = fc; fc = m >> 7; int r = ((m << 1) | c) & 0xFF; setZN(r); return r; }

    private int ror(int m) { int c = fc; fc = m & 1; int r = (m >> 1) | (c << 7); setZN(r); return r; }

    /** Effective address for an addressing mode, with the dummy reads hardware performs. */
    private int ea(int mode, boolean write) {
        switch (mode) {
            case M_IMM: {
                int p = pc;
                pc = (pc + 1) & 0xFFFF;
                return p;
            }
            case M_ZP:
                return fetch();
            case M_ZPX: {
                int z = fetch();
                idle();
                return (z + x) & 0xFF;
            }
            case M_ZPY: {
                int z = fetch();
                idle();
                return (z + y) & 0xFF;
            }
            case M_ABS: {
                int lo = fetch();
                int hi = fetch();
                return lo | (hi << 8);
            }
            case M_ABSX: {
                int lo = fetch();
                int hi = fetch();
                int base = lo | (hi << 8);
                int addr = (base + x) & 0xFFFF;
                if (write || ((base ^ addr) & 0xFF00) != 0) read((base & 0xFF00) | (addr & 0xFF));
                return addr;
            }
            case M_ABSY: {
                int lo = fetch();
                int hi = fetch();
                int base = lo | (hi << 8);
                int addr = (base + y) & 0xFFFF;
                if (write || ((base ^ addr) & 0xFF00) != 0) read((base & 0xFF00) | (addr & 0xFF));
                return addr;
            }
            case M_INDX: {
                int z = fetch();
                idle();
                z = (z + x) & 0xFF;
                int lo = read(z);
                int hi = read((z + 1) & 0xFF);
                return lo | (hi << 8);
            }
            default: { // M_INDY
                int z = fetch();
                int lo = read(z);
                int hi = read((z + 1) & 0xFF);
                int base = lo | (hi << 8);
                int addr = (base + y) & 0xFFFF;
                if (write || ((base ^ addr) & 0xFF00) != 0) read((base & 0xFF00) | (addr & 0xFF));
                return addr;
            }
        }
    }

    private void branch(boolean cond) {
        int off = (byte) fetch();
        if (cond) {
            // a taken, non-page-crossing branch polls interrupts one cycle late
            if (runIrq && !prevRunIrq) runIrq = false;
            idle();
            int target = (pc + off) & 0xFFFF;
            if ((target & 0xFF00) != (pc & 0xFF00)) idle();
            pc = target;
        }
    }

    private void serviceInterrupt(boolean brk) {
        if (!brk) {
            idle();
            idle();
        }
        push(pc >> 8);
        push(pc & 0xFF);
        push(getP(brk));
        fi = 1;
        int vec;
        if (needNmi) {
            needNmi = false;
            vec = 0xFFFA;
        } else {
            vec = 0xFFFE;
        }
        int lo = read(vec);
        int hi = read(vec + 1);
        pc = lo | (hi << 8);
    }

    // ---- execution -----------------------------------------------------------------------------

    /** Execute one instruction (and any interrupt it leaves pending). */
    public void step() {
        int op = fetch();
        execute(op);
        if (prevNeedNmi || prevRunIrq) serviceInterrupt(false);
    }

    private void execute(int op) {
        if ((op & 0x1F) == 0x10) { // conditional branches
            int aaa = op >> 5;
            int flag;
            switch (aaa >> 1) {
                case 0: flag = fn; break;
                case 1: flag = fv; break;
                case 2: flag = fc; break;
                default: flag = fz; break;
            }
            branch(flag == (aaa & 1));
            return;
        }
        switch (op) {
            case 0x00: fetch(); serviceInterrupt(true); return;
            case 0x20: {
                int lo = fetch();
                idle();
                push(pc >> 8);
                push(pc & 0xFF);
                int hi = read(pc);
                pc = lo | (hi << 8);
                return;
            }
            case 0x40: {
                idle();
                idle();
                setP(pull());
                int lo = pull();
                int hi = pull();
                pc = lo | (hi << 8);
                return;
            }
            case 0x60: {
                idle();
                idle();
                int lo = pull();
                int hi = pull();
                pc = lo | (hi << 8);
                idle();
                pc = (pc + 1) & 0xFFFF;
                return;
            }
            case 0x4C: {
                int lo = fetch();
                int hi = fetch();
                pc = lo | (hi << 8);
                return;
            }
            case 0x6C: {
                int lo = fetch();
                int hi = fetch();
                int ptr = lo | (hi << 8);
                int l = read(ptr);
                int h = read((ptr & 0xFF00) | ((ptr + 1) & 0xFF));
                pc = l | (h << 8);
                return;
            }
            case 0x08: idle(); push(getP(true)); return;
            case 0x28: idle(); idle(); setP(pull()); return;
            case 0x48: idle(); push(a); return;
            case 0x68: idle(); idle(); a = pull(); setZN(a); return;
            case 0x88: idle(); y = (y - 1) & 0xFF; setZN(y); return;
            case 0xA8: idle(); y = a; setZN(y); return;
            case 0xC8: idle(); y = (y + 1) & 0xFF; setZN(y); return;
            case 0xE8: idle(); x = (x + 1) & 0xFF; setZN(x); return;
            case 0x18: idle(); fc = 0; return;
            case 0x38: idle(); fc = 1; return;
            case 0x58: idle(); fi = 0; return;
            case 0x78: idle(); fi = 1; return;
            case 0x98: idle(); a = y; setZN(a); return;
            case 0xB8: idle(); fv = 0; return;
            case 0xD8: idle(); fd = 0; return;
            case 0xF8: idle(); fd = 1; return;
            case 0x8A: idle(); a = x; setZN(a); return;
            case 0xAA: idle(); x = a; setZN(x); return;
            case 0xCA: idle(); x = (x - 1) & 0xFF; setZN(x); return;
            case 0x9A: idle(); sp = x; return;
            case 0xBA: idle(); x = sp; setZN(x); return;
            case 0x0A: idle(); a = asl(a); return;
            case 0x2A: idle(); a = rol(a); return;
            case 0x4A: idle(); a = lsr(a); return;
            case 0x6A: idle(); a = ror(a); return;
            case 0xEA: case 0x1A: case 0x3A: case 0x5A: case 0x7A: case 0xDA: case 0xFA:
                idle();
                return;
            default:
                group(op);
        }
    }

    private void group(int op) {
        final int aaa = op >> 5;
        final int bbb = (op >> 2) & 7;
        switch (op & 3) {
            case 1: {
                if (op == 0x89) { read(ea(M_IMM, false)); return; }
                int addr = ea(bbb, aaa == 4);
                switch (aaa) {
                    case 0: a |= read(addr); setZN(a); break;
                    case 1: a &= read(addr); setZN(a); break;
                    case 2: a ^= read(addr); setZN(a); break;
                    case 3: adc(read(addr)); break;
                    case 4: write(addr, a); break;
                    case 5: a = read(addr); setZN(a); break;
                    case 6: cmp(a, read(addr)); break;
                    default: sbc(read(addr)); break;
                }
                return;
            }
            case 2: {
                if (bbb == 0) {
                    int m = read(ea(M_IMM, false));
                    if (aaa == 5) { x = m; setZN(x); }
                    return;
                }
                if (bbb == 2 || bbb == 4 || bbb == 6) { idle(); return; }
                int mode;
                if (bbb == 1) mode = M_ZP;
                else if (bbb == 3) mode = M_ABS;
                else if (bbb == 5) mode = (aaa == 4 || aaa == 5) ? M_ZPY : M_ZPX;
                else mode = aaa == 5 ? M_ABSY : M_ABSX;
                int addr = ea(mode, aaa != 5);
                switch (aaa) {
                    case 0: { int m = read(addr); write(addr, m); write(addr, asl(m)); break; }
                    case 1: { int m = read(addr); write(addr, m); write(addr, rol(m)); break; }
                    case 2: { int m = read(addr); write(addr, m); write(addr, lsr(m)); break; }
                    case 3: { int m = read(addr); write(addr, m); write(addr, ror(m)); break; }
                    case 4: if (op == 0x9E) read(addr); else write(addr, x); break;
                    case 5: x = read(addr); setZN(x); break;
                    case 6: { int m = read(addr); write(addr, m); int r = (m - 1) & 0xFF; setZN(r); write(addr, r); break; }
                    default: { int m = read(addr); write(addr, m); int r = (m + 1) & 0xFF; setZN(r); write(addr, r); break; }
                }
                return;
            }
            case 0: {
                if (bbb == 2 || bbb == 4 || bbb == 6) { idle(); return; }
                int mode = bbb == 0 ? M_IMM : bbb == 1 ? M_ZP : bbb == 3 ? M_ABS : bbb == 5 ? M_ZPX : M_ABSX;
                int addr = ea(mode, aaa == 4);
                boolean legal = bbb == 0 || bbb == 1 || bbb == 3;
                switch (aaa) {
                    case 4:
                        if (bbb == 0 || op == 0x9C) read(addr); else write(addr, y);
                        break;
                    case 5: y = read(addr); setZN(y); break;
                    case 6: { int m = read(addr); if (legal) cmp(y, m); break; }
                    case 7: { int m = read(addr); if (legal) cmp(x, m); break; }
                    case 1: {
                        int m = read(addr);
                        if (bbb == 1 || bbb == 3) {
                            fz = (a & m) == 0 ? 1 : 0;
                            fv = (m >> 6) & 1;
                            fn = (m >> 7) & 1;
                        }
                        break;
                    }
                    default: read(addr); break; // unofficial NOPs
                }
                return;
            }
            default: { // unofficial opcodes
                if (bbb == 2) {
                    int m = read(ea(M_IMM, false));
                    if (op == 0xEB) {
                        sbc(m);
                    } else if (op == 0x0B || op == 0x2B) {
                        a &= m; setZN(a); fc = fn;
                    } else if (op == 0x4B) {
                        a &= m; fc = a & 1; a >>= 1; setZN(a);
                    } else if (op == 0xCB) {
                        int ax = a & x; int r = ax - m; fc = ax >= m ? 1 : 0; x = r & 0xFF; setZN(x);
                    }
                    return;
                }
                int mode;
                switch (bbb) {
                    case 0: mode = M_INDX; break;
                    case 1: mode = M_ZP; break;
                    case 3: mode = M_ABS; break;
                    case 4: mode = M_INDY; break;
                    case 5: mode = (aaa == 4 || aaa == 5) ? M_ZPY : M_ZPX; break;
                    case 6: mode = M_ABSY; break;
                    default: mode = (aaa == 5 || aaa == 4) ? M_ABSY : M_ABSX; break;
                }
                int addr = ea(mode, aaa != 5);
                if (aaa == 4) {
                    if (bbb == 0 || bbb == 1 || bbb == 3 || bbb == 5) write(addr, a & x);
                    else read(addr);
                    return;
                }
                if (aaa == 5) {
                    int m = read(addr);
                    a = m; x = m; setZN(m);
                    return;
                }
                int m = read(addr);
                write(addr, m);
                int r;
                switch (aaa) {
                    case 0: fc = m >> 7; r = (m << 1) & 0xFF; write(addr, r); a |= r; setZN(a); break;
                    case 1: { int c = fc; fc = m >> 7; r = ((m << 1) | c) & 0xFF; write(addr, r); a &= r; setZN(a); break; }
                    case 2: fc = m & 1; r = m >> 1; write(addr, r); a ^= r; setZN(a); break;
                    case 3: { int c = fc; fc = m & 1; r = (m >> 1) | (c << 7); write(addr, r); adc(r); break; }
                    case 6: r = (m - 1) & 0xFF; write(addr, r); cmp(a, r); break;
                    default: r = (m + 1) & 0xFF; write(addr, r); sbc(r); break;
                }
            }
        }
    }
}
