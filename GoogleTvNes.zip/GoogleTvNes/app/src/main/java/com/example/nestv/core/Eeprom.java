package com.example.nestv.core;

import java.util.Arrays;

/**
 * Bit-banged I2C serial EEPROM as wired on Bandai FCG / LZ93D50 boards (mapper 16, 159).
 * The game drives SCL and SDA through register $x00D and reads SDA back on bit 4 of $6000-$7FFF.
 * Old iNES dumps label 24C01 games as mapper 16, so in AUTO mode the chip type is detected from the
 * first byte the game sends: 24C02 always starts with a 1010xxxx device address, 24C01 does not.
 */
public final class Eeprom {
    public static final int AUTO = 0, C01 = 1, C02 = 2;
    private static final int IDLE = 0, FIRST = 1, DEVADDR = 2, WORDADDR = 3, WRITE = 4, READ = 5, WAITSTOP = 6;

    public final byte[] data = new byte[256];
    /** Bumped every time a byte is committed to the array. */
    public int writeCount;
    /** Diagnostics. */
    public int starts, bytesRx;

    private int type;
    private int state = IDLE;
    private int nextState = IDLE;
    private int scl = 0, sda = 1;
    private int clk;          // SCL rising edges since the last start / byte boundary
    private int shift;
    private int addr;
    private int curByte;
    private boolean masterAck;
    private int output = 1;

    public Eeprom(int type) {
        this.type = type;
        Arrays.fill(data, (byte) 0xFF);
    }

    public int type() { return type; }

    public String typeName() { return type == C01 ? "24C01" : type == C02 ? "24C02" : "auto"; }

    private int size() { return type == C01 ? 128 : 256; }

    /** Contents to persist: 128 bytes for a 24C01, otherwise 256. */
    public byte[] snapshot() { return Arrays.copyOf(data, size()); }

    public void load(byte[] saved) {
        if (saved == null) return;
        System.arraycopy(saved, 0, data, 0, Math.min(saved.length, data.length));
    }

    /** Current SDA level driven by the chip (0/1). */
    public int read() { return output; }

    public void write(int newScl, int newSda) {
        newScl = newScl != 0 ? 1 : 0;
        newSda = newSda != 0 ? 1 : 0;

        if (scl == 1 && newScl == 1 && sda != newSda) {
            if (newSda == 0) {            // START: SDA falls while SCL high
                starts++;
                state = type == AUTO ? FIRST : (type == C01 ? WORDADDR : DEVADDR);
                clk = 0;
                shift = 0;
                output = 1;
            } else {                      // STOP: SDA rises while SCL high
                state = IDLE;
                clk = 0;
                output = 1;
            }
            sda = newSda;
            return;
        }
        if (scl == 0 && newScl == 1) rising(newSda);
        else if (scl == 1 && newScl == 0) falling();
        scl = newScl;
        sda = newSda;
    }

    private void rising(int sdaIn) {
        switch (state) {
            case FIRST:
            case DEVADDR:
            case WORDADDR:
            case WRITE:
                clk++;
                if (clk <= 8) {
                    shift = ((shift << 1) | sdaIn) & 0xFF;
                    if (clk == 8) byteReceived();
                }
                break;
            case READ:
                clk++;
                if (clk == 9) masterAck = (sdaIn == 0);
                break;
            default:
                break;
        }
    }

    private void falling() {
        switch (state) {
            case DEVADDR:
            case WORDADDR:
            case WRITE:
                if (clk == 9) {
                    clk = 0;
                    output = 1;
                    state = nextState;
                    if (state == READ) loadReadByte();
                }
                break;
            case READ:
                if (clk >= 1 && clk <= 7) {
                    output = (curByte >> (7 - clk)) & 1;
                } else if (clk == 8) {
                    output = 1;           // release SDA so the master can ACK / NACK
                } else if (clk == 9) {
                    clk = 0;
                    if (masterAck) {
                        addr = (addr + 1) & (size() - 1);
                        loadReadByte();
                    } else {
                        state = WAITSTOP;
                        output = 1;
                    }
                }
                break;
            default:
                break;
        }
    }

    private void loadReadByte() {
        curByte = data[addr] & 0xFF;
        output = (curByte >> 7) & 1;
    }

    private void byteReceived() {
        bytesRx++;
        switch (state) {
            case FIRST:
                type = (shift & 0xF0) == 0xA0 ? C02 : C01;
                state = type == C01 ? WORDADDR : DEVADDR;
                bytesRx--;
                byteReceived();
                return;
            case DEVADDR:
                if ((shift & 0xF0) == 0xA0) {
                    output = 0; // ACK
                    nextState = (shift & 1) != 0 ? READ : WORDADDR;
                } else {
                    nextState = WAITSTOP;
                }
                break;
            case WORDADDR:
                if (type == C01) {
                    // 24C01: 7-bit address followed by the R/W bit in the very first byte
                    addr = (shift >> 1) & 0x7F;
                    output = 0;
                    nextState = (shift & 1) != 0 ? READ : WRITE;
                } else {
                    addr = shift & 0xFF;
                    output = 0;
                    nextState = WRITE;
                }
                break;
            case WRITE:
                data[addr] = (byte) shift;
                writeCount++;
                output = 0;
                if (type == C01) addr = (addr + 1) & 0x7F;
                else addr = (addr & ~7) | ((addr + 1) & 7); // 8-byte page wrap
                nextState = WRITE;
                break;
            default:
                break;
        }
    }
}
