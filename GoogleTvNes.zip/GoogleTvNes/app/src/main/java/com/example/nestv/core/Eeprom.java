package com.example.nestv.core;

import java.util.Arrays;

/**
 * Bit-banged I2C serial EEPROM as wired on Bandai FCG / LZ93D50 boards (mapper 16, 159).
 * The game drives SCL and SDA through register $x00D and reads SDA back on bit 4 of $6000-$7FFF.
 */
public final class Eeprom {
    private static final int IDLE = 0, DEVADDR = 1, WORDADDR = 2, WRITE = 3, READ = 4, WAITSTOP = 5;

    public final boolean is24c01;
    public final byte[] data;
    /** Bumped every time a byte is committed to the array. */
    public int writeCount;

    private int state = IDLE;
    private int nextState = IDLE;
    private int scl = 0, sda = 1;
    private int clk;          // SCL rising edges since the last start / byte boundary
    private int shift;
    private int addr;
    private int curByte;
    private boolean masterAck;
    private int output = 1;

    public Eeprom(boolean is24c01) {
        this.is24c01 = is24c01;
        this.data = new byte[is24c01 ? 128 : 256];
        Arrays.fill(data, (byte) 0xFF);
    }

    public void load(byte[] saved) {
        if (saved == null) return;
        System.arraycopy(saved, 0, data, 0, Math.min(saved.length, data.length));
    }

    /** Current SDA level driven by the chip (0/1). */
    public int read() { return output; }

    public void write(int newScl, int newSda) {
        newScl = newScl != 0 ? 1 : 0;
        newSda = newSda != 0 ? 1 : 0;

        if (scl == 1 && newScl == 1 && sda != newSda) {
            if (newSda == 0) {            // START: SDA falls while SCL high
                state = is24c01 ? WORDADDR : DEVADDR;
                clk = 0;
                shift = 0;
                output = 1;
            } else {                      // STOP: SDA rises while SCL high
                state = IDLE;
                clk = 0;
                output = 1;
            }
            sda = newSda;
            return;
        }
        if (scl == 0 && newScl == 1) rising(newSda);
        else if (scl == 1 && newScl == 0) falling();
        scl = newScl;
        sda = newSda;
    }

    private void rising(int sdaIn) {
        switch (state) {
            case DEVADDR:
            case WORDADDR:
            case WRITE:
                clk++;
                if (clk <= 8) {
                    shift = ((shift << 1) | sdaIn) & 0xFF;
                    if (clk == 8) byteReceived();
                }
                break;
            case READ:
                clk++;
                if (clk == 9) masterAck = (sdaIn == 0);
                break;
            default:
                break;
        }
    }

    private void falling() {
        switch (state) {
            case DEVADDR:
            case WORDADDR:
            case WRITE:
                if (clk == 9) {
                    clk = 0;
                    output = 1;
                    state = nextState;
                    if (state == READ) loadReadByte();
                }
                break;
            case READ:
                if (clk >= 1 && clk <= 7) {
                    output = (curByte >> (7 - clk)) & 1;
                } else if (clk == 8) {
                    output = 1;           // release SDA so the master can ACK / NACK
                } else if (clk == 9) {
                    clk = 0;
                    if (masterAck) {
                        addr = (addr + 1) & (data.length - 1);
                        loadReadByte();
                    } else {
                        state = WAITSTOP;
                        output = 1;
                    }
                }
                break;
            default:
                break;
        }
    }

    private void loadReadByte() {
        curByte = data[addr] & 0xFF;
        output = (curByte >> 7) & 1;
    }

    private void byteReceived() {
        switch (state) {
            case DEVADDR:
                if ((shift & 0xF0) == 0xA0) {
                    output = 0; // ACK
                    nextState = (shift & 1) != 0 ? READ : WORDADDR;
                } else {
                    nextState = WAITSTOP;
                }
                break;
            case WORDADDR:
                if (is24c01) {
                    // 24C01: 7-bit address followed by the R/W bit in the very first byte
                    addr = (shift >> 1) & 0x7F;
                    output = 0;
                    nextState = (shift & 1) != 0 ? READ : WRITE;
                } else {
                    addr = shift & 0xFF;
                    output = 0;
                    nextState = WRITE;
                }
                break;
            case WRITE:
                data[addr] = (byte) shift;
                writeCount++;
                output = 0;
                if (is24c01) addr = (addr + 1) & 0x7F;
                else addr = (addr & ~7) | ((addr + 1) & 7); // 8-byte page wrap
                nextState = WRITE;
                break;
            default:
                break;
        }
    }
}
