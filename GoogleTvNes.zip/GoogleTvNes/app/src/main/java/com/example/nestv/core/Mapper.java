package com.example.nestv.core;

/** Cartridge hardware: banking, IRQ counters, battery / EEPROM saves. */
public abstract class Mapper {
    protected final Cartridge cart;
    protected final byte[] prg;
    protected final byte[] chr;
    protected final boolean chrRam;
    private final int prgMask, chrMask;

    protected Cpu cpu;
    protected Ppu ppu;

    /** Level of the cartridge /IRQ line (sampled by the CPU every cycle). */
    public boolean irqAsserted;
    /** Set by mappers that need {@link #cpuClock()} on every CPU cycle. */
    public boolean needsCpuClock;
    /** Set by mappers that watch PPU address line A12 (MMC3). */
    public boolean watchA12;
    /** Bumped whenever battery / EEPROM data changes. */
    public int saveGeneration;

    protected Mapper(Cartridge c) {
        cart = c;
        prg = c.prg;
        chr = c.chr;
        chrRam = c.chrRam;
        prgMask = Cartridge.isPow2(prg.length) ? prg.length - 1 : -1;
        chrMask = Cartridge.isPow2(chr.length) ? chr.length - 1 : -1;
    }

    public final void attach(Cpu cpu, Ppu ppu) {
        this.cpu = cpu;
        this.ppu = ppu;
        ppu.setMirroring(cart.mirroring);
        init();
    }

    protected void init() {}

    /** @return byte read, or -1 for open bus. */
    public abstract int cpuRead(int addr);

    public abstract void cpuWrite(int addr, int v);

    public int ppuRead(int addr) { return chrAt(addr); }

    public void ppuWrite(int addr, int v) {
        if (chrRam) chr[addr & (chr.length - 1)] = (byte) v;
    }

    /** Called for every PPU nametable fetch (only when watchA12). */
    public void ppuBus(int addr) {}

    /** Called once per CPU cycle (only when needsCpuClock). */
    public void cpuClock() {}

    /** @return copy of the battery / EEPROM contents, or null if this cartridge has none. */
    public byte[] getSaveData() { return null; }

    public void loadSaveData(byte[] d) {}

    // ---- helpers -------------------------------------------------------------------------

    protected final int prgAt(int offset) {
        return prg[prgMask >= 0 ? (offset & prgMask) : (offset % prg.length)] & 0xFF;
    }

    protected final int chrAt(int offset) {
        return chr[chrMask >= 0 ? (offset & chrMask) : (offset % chr.length)] & 0xFF;
    }

    protected final int prgBanks16() { return prg.length / 0x4000; }

    protected final int prgBanks8() { return prg.length / 0x2000; }

    protected final int chrBanks1k() { return Math.max(1, chr.length / 0x400); }
}
