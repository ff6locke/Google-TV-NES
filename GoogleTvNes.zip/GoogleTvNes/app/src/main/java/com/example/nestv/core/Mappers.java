package com.example.nestv.core;

/** Mapper factory plus the individual board implementations. */
public final class Mappers {
    private Mappers() {}

    public static Mapper create(Cartridge c) {
        switch (c.mapperId) {
            case 0: return new Nrom(c);
            case 1: return new Mmc1(c);
            case 2: return new UxRom(c);
            case 3: return new CnRom(c);
            case 4: return new Mmc3(c);
            case 7: return new AxRom(c);
            case 16:
            case 159: return new BandaiFcg(c);
            default:
                throw new UnsupportedOperationException("Mapper " + c.mapperId + " is not supported");
        }
    }
}

/** Boards with 8 KB of (optionally battery-backed) PRG-RAM at $6000-$7FFF. */
abstract class RamMapper extends Mapper {
    protected final byte[] ram = new byte[0x2000];

    RamMapper(Cartridge c) { super(c); }

    protected final int ramRead(int addr) { return ram[addr & 0x1FFF] & 0xFF; }

    protected final void ramWrite(int addr, int v) {
        int i = addr & 0x1FFF;
        if (ram[i] != (byte) v) {
            ram[i] = (byte) v;
            if (cart.battery) saveGeneration++;
        }
    }

    @Override
    public byte[] getSaveData() { return cart.battery ? ram.clone() : null; }

    @Override
    public void loadSaveData(byte[] d) {
        if (d != null) System.arraycopy(d, 0, ram, 0, Math.min(d.length, ram.length));
    }
}

final class Nrom extends RamMapper {
    Nrom(Cartridge c) { super(c); }

    @Override
    public int cpuRead(int addr) {
        if (addr >= 0x8000) return prgAt(addr & 0x7FFF);
        if (addr >= 0x6000) return ramRead(addr);
        return -1;
    }

    @Override
    public void cpuWrite(int addr, int v) {
        if (addr >= 0x6000 && addr < 0x8000) ramWrite(addr, v);
    }
}

final class Mmc1 extends RamMapper {
    private int shiftReg = 0x10, control = 0x0C, chr0, chr1, prgReg;

    Mmc1(Cartridge c) { super(c); }

    @Override
    protected void init() { applyMirroring(); }

    private void applyMirroring() {
        switch (control & 3) {
            case 0: ppu.setMirroring(Ppu.MIRROR_SINGLE0); break;
            case 1: ppu.setMirroring(Ppu.MIRROR_SINGLE1); break;
            case 2: ppu.setMirroring(Ppu.MIRROR_V); break;
            default: ppu.setMirroring(Ppu.MIRROR_H); break;
        }
    }

    @Override
    public int cpuRead(int addr) {
        if (addr >= 0x8000) {
            int bank;
            switch ((control >> 2) & 3) {
                case 0:
                case 1:
                    bank = (prgReg & 0x0E) + ((addr >> 14) & 1);
                    break;
                case 2:
                    bank = addr < 0xC000 ? 0 : (prgReg & 0x0F);
                    break;
                default:
                    bank = addr < 0xC000 ? (prgReg & 0x0F) : (prgBanks16() - 1);
                    break;
            }
            return prgAt(bank * 0x4000 + (addr & 0x3FFF));
        }
        if (addr >= 0x6000) return ramRead(addr);
        return -1;
    }

    @Override
    public void cpuWrite(int addr, int v) {
        if (addr < 0x6000) return;
        if (addr < 0x8000) { ramWrite(addr, v); return; }
        if ((v & 0x80) != 0) {
            shiftReg = 0x10;
            control |= 0x0C;
            applyMirroring();
            return;
        }
        boolean complete = (shiftReg & 1) != 0;
        shiftReg = (shiftReg >> 1) | ((v & 1) << 4);
        if (complete) {
            int val = shiftReg & 0x1F;
            switch ((addr >> 13) & 3) {
                case 0: control = val; applyMirroring(); break;
                case 1: chr0 = val; break;
                case 2: chr1 = val; break;
                default: prgReg = val; break;
            }
            shiftReg = 0x10;
        }
    }

    @Override
    public int ppuRead(int addr) {
        int bank4k;
        if ((control & 0x10) == 0) bank4k = (chr0 & 0x1E) + ((addr >> 12) & 1);
        else bank4k = addr < 0x1000 ? chr0 : chr1;
        return chrAt(bank4k * 0x1000 + (addr & 0xFFF));
    }
}

final class UxRom extends Mapper {
    private int bank;

    UxRom(Cartridge c) { super(c); }

    @Override
    public int cpuRead(int addr) {
        if (addr < 0x8000) return -1;
        int b = addr < 0xC000 ? bank : prgBanks16() - 1;
        return prgAt(b * 0x4000 + (addr & 0x3FFF));
    }

    @Override
    public void cpuWrite(int addr, int v) {
        if (addr >= 0x8000) bank = v & 0xFF;
    }
}

final class CnRom extends Mapper {
    private int bank;

    CnRom(Cartridge c) { super(c); }

    @Override
    public int cpuRead(int addr) { return addr >= 0x8000 ? prgAt(addr & 0x7FFF) : -1; }

    @Override
    public void cpuWrite(int addr, int v) {
        if (addr >= 0x8000) bank = v & 0xFF;
    }

    @Override
    public int ppuRead(int addr) { return chrAt(bank * 0x2000 + addr); }
}

final class AxRom extends Mapper {
    private int bank;

    AxRom(Cartridge c) { super(c); }

    @Override
    protected void init() { ppu.setMirroring(Ppu.MIRROR_SINGLE0); }

    @Override
    public int cpuRead(int addr) {
        return addr >= 0x8000 ? prgAt(bank * 0x8000 + (addr & 0x7FFF)) : -1;
    }

    @Override
    public void cpuWrite(int addr, int v) {
        if (addr < 0x8000) return;
        bank = v & 0x0F;
        ppu.setMirroring((v & 0x10) != 0 ? Ppu.MIRROR_SINGLE1 : Ppu.MIRROR_SINGLE0);
    }
}

final class Mmc3 extends RamMapper {
    private final int[] regs = new int[8];
    private final int[] chrBank = new int[8];
    private final int[] prgBank = new int[4];
    private int bankSelect;
    private int irqLatch, irqCounter;
    private boolean irqReload, irqEnabled;
    private boolean a12High;
    private long lowStart;

    Mmc3(Cartridge c) {
        super(c);
        watchA12 = true;
    }

    @Override
    protected void init() {
        regs[0] = 0; regs[1] = 2; regs[2] = 4; regs[3] = 5; regs[4] = 6; regs[5] = 7; regs[6] = 0; regs[7] = 1;
        updateBanks();
    }

    private void updateBanks() {
        int last = prgBanks8() - 1;
        if ((bankSelect & 0x40) == 0) {
            prgBank[0] = regs[6]; prgBank[1] = regs[7]; prgBank[2] = last - 1; prgBank[3] = last;
        } else {
            prgBank[0] = last - 1; prgBank[1] = regs[7]; prgBank[2] = regs[6]; prgBank[3] = last;
        }
        int[] c = chrBank;
        if ((bankSelect & 0x80) == 0) {
            c[0] = regs[0] & 0xFE; c[1] = regs[0] | 1; c[2] = regs[1] & 0xFE; c[3] = regs[1] | 1;
            c[4] = regs[2]; c[5] = regs[3]; c[6] = regs[4]; c[7] = regs[5];
        } else {
            c[4] = regs[0] & 0xFE; c[5] = regs[0] | 1; c[6] = regs[1] & 0xFE; c[7] = regs[1] | 1;
            c[0] = regs[2]; c[1] = regs[3]; c[2] = regs[4]; c[3] = regs[5];
        }
    }

    @Override
    public int cpuRead(int addr) {
        if (addr >= 0x8000) return prgAt(prgBank[(addr >> 13) & 3] * 0x2000 + (addr & 0x1FFF));
        if (addr >= 0x6000) return ramRead(addr);
        return -1;
    }

    @Override
    public void cpuWrite(int addr, int v) {
        if (addr < 0x6000) return;
        if (addr < 0x8000) { ramWrite(addr, v); return; }
        switch (addr & 0xE001) {
            case 0x8000: bankSelect = v; updateBanks(); break;
            case 0x8001: regs[bankSelect & 7] = v; updateBanks(); break;
            case 0xA000:
                if (cart.mirroring != Ppu.MIRROR_FOUR) ppu.setMirroring((v & 1) != 0 ? Ppu.MIRROR_H : Ppu.MIRROR_V);
                break;
            case 0xC000: irqLatch = v; break;
            case 0xC001: irqCounter = 0; irqReload = true; break;
            case 0xE000: irqEnabled = false; irqAsserted = false; break;
            case 0xE001: irqEnabled = true; break;
            default: break;
        }
    }

    @Override
    public int ppuRead(int addr) {
        a12(addr);
        return chrAt(chrBank[(addr >> 10) & 7] * 0x400 + (addr & 0x3FF));
    }

    @Override
    public void ppuBus(int addr) { a12(addr); }

    private void a12(int addr) {
        boolean high = (addr & 0x1000) != 0;
        if (high) {
            if (!a12High) {
                a12High = true;
                if (ppu.totalDots - lowStart >= 10) clockIrq();
            }
        } else if (a12High) {
            a12High = false;
            lowStart = ppu.totalDots;
        }
    }

    private void clockIrq() {
        if (irqCounter == 0 || irqReload) {
            irqCounter = irqLatch;
            irqReload = false;
        } else {
            irqCounter--;
        }
        if (irqCounter == 0 && irqEnabled) irqAsserted = true;
    }
}

/**
 * Bandai FCG-1/2 and LZ93D50 boards (mapper 16) plus the 24C01 variant (mapper 159).
 * Used by the Dragon Ball Z / Dragon Ball games. Registers decode at $6000-$7FFF (FCG)
 * and $8000-$FFFF (LZ93D50); the window a write lands in selects the IRQ counter style.
 * Saves live in a serial EEPROM.
 */
final class BandaiFcg extends Mapper {
    private final int[] chrBank = new int[8];
    private final Eeprom eeprom;
    private final boolean acceptLow, acceptHigh;
    private int prgBank;
    private boolean irqEnabled;
    private int irqCounter, irqLatch;
    private int lastEepromWrites, regWrites, irqFires;

    BandaiFcg(Cartridge c) {
        super(c);
        needsCpuClock = true;
        boolean none = c.mapperId == 16 && c.submapper == 4;
        int chip;
        if (c.mapperId == 159 || (c.nes2 && c.nvramSize == 128)) chip = Eeprom.C01;
        else if (c.nes2 && (c.submapper == 5 || c.nvramSize == 256)) chip = Eeprom.C02;
        else chip = Eeprom.AUTO;                         // iNES 1.0 mapper 16: work out the chip at run time
        eeprom = none ? null : new Eeprom(chip);
        acceptLow = c.submapper != 5;
        acceptHigh = c.submapper != 4;
    }

    @Override
    public int cpuRead(int addr) {
        if (addr >= 0x8000) {
            int bank = addr < 0xC000 ? prgBank : prgBanks16() - 1;
            return prgAt(bank * 0x4000 + (addr & 0x3FFF));
        }
        if (addr >= 0x6000 && eeprom != null) {
            return (cpu.openBus & 0xEF) | (eeprom.read() << 4);
        }
        return -1;
    }

    @Override
    public void cpuWrite(int addr, int v) {
        if (addr < 0x6000) return;
        boolean low = addr < 0x8000;
        if (low ? !acceptLow : !acceptHigh) return;
        regWrites++;
        switch (addr & 0x0F) {
            case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
                chrBank[addr & 7] = v & 0xFF;
                break;
            case 8:
                prgBank = v & 0x0F;
                break;
            case 9:
                switch (v & 3) {
                    case 0: ppu.setMirroring(Ppu.MIRROR_V); break;
                    case 1: ppu.setMirroring(Ppu.MIRROR_H); break;
                    case 2: ppu.setMirroring(Ppu.MIRROR_SINGLE0); break;
                    default: ppu.setMirroring(Ppu.MIRROR_SINGLE1); break;
                }
                break;
            case 0x0A:
                irqEnabled = (v & 1) != 0;
                if (!low) irqCounter = irqLatch;   // LZ93D50: counter reloads from the latch
                irqAsserted = false;
                break;
            case 0x0B:
                if (low) irqCounter = (irqCounter & 0xFF00) | v;       // FCG: direct counter write
                else irqLatch = (irqLatch & 0xFF00) | v;
                break;
            case 0x0C:
                if (low) irqCounter = (irqCounter & 0x00FF) | (v << 8);
                else irqLatch = (irqLatch & 0x00FF) | (v << 8);
                break;
            case 0x0D:
                if (eeprom != null) {
                    eeprom.write((v >> 5) & 1, (v >> 6) & 1);
                    if (eeprom.writeCount != lastEepromWrites) {
                        lastEepromWrites = eeprom.writeCount;
                        saveGeneration++;
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void cpuClock() {
        if (irqEnabled) {
            if (irqCounter == 0) { if (!irqAsserted) irqFires++; irqAsserted = true; }
            irqCounter = (irqCounter - 1) & 0xFFFF;
        }
    }

    @Override
    public int ppuRead(int addr) {
        if (chrRam) return chrAt(addr);
        return chrAt((chrBank[(addr >> 10) & 7] << 10) | (addr & 0x3FF));
    }

    @Override
    public byte[] getSaveData() { return eeprom == null ? null : eeprom.snapshot(); }

    @Override
    public String debugInfo() {
        return "sub" + cart.submapper + " regs:" + regWrites + " irq:" + irqFires + " eeprom:"
                + (eeprom == null ? "none" : eeprom.typeName() + " start:" + eeprom.starts + " bytes:" + eeprom.bytesRx);
    }

    @Override
    public void loadSaveData(byte[] d) { if (eeprom != null) eeprom.load(d); }
}
