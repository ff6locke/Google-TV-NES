package com.example.nestv.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

/** A complete NES: cartridge + CPU + PPU + APU + two controllers. */
public final class Nes {
    public static final int BTN_A = 1, BTN_B = 2, BTN_SELECT = 4, BTN_START = 8,
            BTN_UP = 16, BTN_DOWN = 32, BTN_LEFT = 64, BTN_RIGHT = 128;

    public final transient Cartridge cart;
    public final Mapper mapper;
    public final Cpu cpu;
    public final Ppu ppu;
    public final Apu apu;

    /** Controller states (bitmask of BTN_*), set by the front end before each frame. */
    public int pad0, pad1;
    /** Frames emulated since power-on (diagnostics). */
    public long frames;
    private int shift0, shift1;
    private boolean strobe;

    public Nes(byte[] rom, int sampleRate) throws IOException {
        cart = Cartridge.parse(rom);
        mapper = Mappers.create(cart);
        ppu = new Ppu();
        apu = new Apu(sampleRate);
        cpu = new Cpu(this, ppu, apu);
        ppu.attach(mapper);
        cpu.attach(mapper);
        mapper.attach(cpu, ppu);
        cpu.reset();
    }

    public void loadSave(byte[] data) { mapper.loadSaveData(data); }

    /** @return copy of battery / EEPROM data, or null when the cartridge has none. */
    public byte[] getSaveData() { return mapper.getSaveData(); }

    public int saveGeneration() { return mapper.saveGeneration; }

    private static final int STATE_MAGIC = 0x4E455353, STATE_VERSION = 1; // "NESS"

    /** Snapshot of the whole machine. Call only between frames (never while runFrame is executing). */
    public byte[] saveState() throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(48 * 1024);
        DataOutputStream o = new DataOutputStream(bo);
        o.writeInt(STATE_MAGIC);
        o.writeInt(STATE_VERSION);
        o.writeInt(cart.mapperId);
        o.writeInt(Arrays.hashCode(cart.prg));
        StateIO.write(o, this);
        byte[] chrRam = mapper.chrRamData();
        o.writeInt(chrRam == null ? -1 : chrRam.length);
        if (chrRam != null) o.write(chrRam);
        o.flush();
        return bo.toByteArray();
    }

    /** Restore a snapshot made by {@link #saveState()} for the same ROM. */
    public void loadState(byte[] data) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        if (in.readInt() != STATE_MAGIC || in.readInt() != STATE_VERSION) throw new IOException("Not a savestate of this version");
        if (in.readInt() != cart.mapperId || in.readInt() != Arrays.hashCode(cart.prg)) {
            throw new IOException("Savestate belongs to a different game");
        }
        int gen = mapper.saveGeneration;
        StateIO.read(in, this);
        int n = in.readInt();
        byte[] chrRam = mapper.chrRamData();
        if (n >= 0) {
            if (chrRam == null || chrRam.length != n) throw new IOException("CHR-RAM mismatch");
            in.readFully(chrRam);
        }
        mapper.saveGeneration = gen + 1;   // battery / EEPROM contents changed: make sure they get written
        ppu.frameReady = false;
        apu.sampleCount = 0;
    }

    /** Run until the PPU reaches vblank (one video frame). */
    public void runFrame() {
        ppu.frameReady = false;
        while (!ppu.frameReady) cpu.step();
        frames++;
    }

    int readPad(int port) {
        int bit;
        if (port == 0) {
            if (strobe) shift0 = pad0;
            bit = shift0 & 1;
            shift0 = (shift0 >> 1) | 0x80;
        } else {
            if (strobe) shift1 = pad1;
            bit = shift1 & 1;
            shift1 = (shift1 >> 1) | 0x80;
        }
        return bit;
    }

    void writePadStrobe(int v) {
        boolean s = (v & 1) != 0;
        if (s || strobe) {
            shift0 = pad0;
            shift1 = pad1;
        }
        strobe = s;
    }
}
