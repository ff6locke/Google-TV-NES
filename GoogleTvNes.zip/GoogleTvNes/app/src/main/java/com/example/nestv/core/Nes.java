package com.example.nestv.core;

import java.io.IOException;

/** A complete NES: cartridge + CPU + PPU + APU + two controllers. */
public final class Nes {
    public static final int BTN_A = 1, BTN_B = 2, BTN_SELECT = 4, BTN_START = 8,
            BTN_UP = 16, BTN_DOWN = 32, BTN_LEFT = 64, BTN_RIGHT = 128;

    public final Cartridge cart;
    public final Mapper mapper;
    public final Cpu cpu;
    public final Ppu ppu;
    public final Apu apu;

    /** Controller states (bitmask of BTN_*), set by the front end before each frame. */
    public int pad0, pad1;
    private int shift0, shift1;
    private boolean strobe;

    public Nes(byte[] rom, int sampleRate) throws IOException {
        cart = Cartridge.parse(rom);
        mapper = Mappers.create(cart);
        ppu = new Ppu();
        apu = new Apu(sampleRate);
        cpu = new Cpu(this, ppu, apu);
        ppu.attach(mapper);
        cpu.attach(mapper);
        mapper.attach(cpu, ppu);
        cpu.reset();
    }

    public void loadSave(byte[] data) { mapper.loadSaveData(data); }

    /** @return copy of battery / EEPROM data, or null when the cartridge has none. */
    public byte[] getSaveData() { return mapper.getSaveData(); }

    public int saveGeneration() { return mapper.saveGeneration; }

    /** Run until the PPU reaches vblank (one video frame). */
    public void runFrame() {
        ppu.frameReady = false;
        while (!ppu.frameReady) cpu.step();
    }

    int readPad(int port) {
        int bit;
        if (port == 0) {
            if (strobe) shift0 = pad0;
            bit = shift0 & 1;
            shift0 = (shift0 >> 1) | 0x80;
        } else {
            if (strobe) shift1 = pad1;
            bit = shift1 & 1;
            shift1 = (shift1 >> 1) | 0x80;
        }
        return bit;
    }

    void writePadStrobe(int v) {
        boolean s = (v & 1) != 0;
        if (s || strobe) {
            shift0 = pad0;
            shift1 = pad1;
        }
        strobe = s;
    }
}
