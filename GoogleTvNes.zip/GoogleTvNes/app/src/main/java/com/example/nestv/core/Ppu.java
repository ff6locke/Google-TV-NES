package com.example.nestv.core;

/**
 * NTSC 2C02. Stepped one dot at a time so mid-scanline scroll writes, sprite 0 hits and mapper
 * IRQ raster splits land on the same dot as on hardware (this is what keeps split-screen
 * dialog windows from shaking).
 */
public final class Ppu {
    public static final int MIRROR_H = 0, MIRROR_V = 1, MIRROR_SINGLE0 = 2, MIRROR_SINGLE1 = 3, MIRROR_FOUR = 4;
    public static final int WIDTH = 256, HEIGHT = 240;

    private static final int[] RGB = {
        0x666666, 0x002A88, 0x1412A7, 0x3B00A4, 0x5C007E, 0x6E0040, 0x6C0600, 0x561D00,
        0x333500, 0x0B4800, 0x005200, 0x004F08, 0x00404D, 0x000000, 0x000000, 0x000000,
        0xADADAD, 0x155FD9, 0x4240FF, 0x7527FE, 0xA01ACC, 0xB71E7B, 0xB53120, 0x994E00,
        0x6B6D00, 0x388700, 0x0C9300, 0x008F32, 0x007C8D, 0x000000, 0x000000, 0x000000,
        0xFFFEFF, 0x64B0FF, 0x9290FF, 0xC676FF, 0xF36AFF, 0xFE6ECC, 0xFE8170, 0xEA9E22,
        0xBCBE00, 0x88D800, 0x5CE430, 0x45E082, 0x48CDDE, 0x4F4F4F, 0x000000, 0x000000,
        0xFFFEFF, 0xC0DFFF, 0xD3D2FF, 0xE8C8FF, 0xFBC2FF, 0xFEC4EA, 0xFECCC5, 0xF7D8A5,
        0xE4E594, 0xCFEF96, 0xBDF4AB, 0xB3F3CC, 0xB5EBF2, 0xB8B8B8, 0x000000, 0x000000
    };

    /** ARGB colours indexed by [emphasis][palette entry]. */
    private final transient int[][] colors = new int[8][64];

    public final transient int[] frame = new int[WIDTH * HEIGHT];
    public boolean frameReady;
    /**
     * When set (fast-forward) pixels are not produced, but everything that can influence emulation,
     * notably the sprite 0 hit, is still evaluated exactly.
     */
    public transient boolean skipRender;
    /** Diagnostics / tests: dot counter value when sprite 0 last hit. */
    public transient long lastSpr0HitDot;
    /** Total dots executed since power-on (used by MMC3 A12 filtering). */
    public long totalDots;

    private transient Mapper mapper;
    private final byte[] vram = new byte[4096];
    private final int[] ntMap = new int[4];
    private final int[] pal = new int[32];
    private final int[] oam = new int[256];

    private int ctrl, mask;
    private boolean vblank, spr0Hit, sprOverflow;
    private int oamAddr;
    private int v, t, fineX;
    private boolean wLatch;
    private int readBuf, ioBus;
    private int scanline = 261, dot = 0;
    private boolean oddFrame, suppressVbl;

    // background pipeline
    private int bgNextId, bgNextAttr, bgNextLo, bgNextHi;
    private int bgPatLo, bgPatHi, bgAttrLo, bgAttrHi;

    // sprites
    private final int[] sec = new int[32];
    private int spriteCount;
    private boolean spr0Possible;
    private final int[] sprLo = new int[8], sprHi = new int[8], sprAttr = new int[8], sprX = new int[8];

    public Ppu() {
        for (int e = 0; e < 8; e++) {
            for (int i = 0; i < 64; i++) {
                int rgb = RGB[i];
                int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
                if (e != 0) {
                    float fr = 1f, fg = 1f, fb = 1f;
                    if ((e & 1) != 0) { fg *= 0.75f; fb *= 0.75f; }
                    if ((e & 2) != 0) { fr *= 0.75f; fb *= 0.75f; }
                    if ((e & 4) != 0) { fr *= 0.75f; fg *= 0.75f; }
                    r = (int) (r * fr); g = (int) (g * fg); b = (int) (b * fb);
                }
                colors[e][i] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        setMirroring(MIRROR_H);
    }

    public void attach(Mapper m) { mapper = m; }

    public void setMirroring(int mode) {
        switch (mode) {
            case MIRROR_H: ntMap[0] = 0; ntMap[1] = 0; ntMap[2] = 1; ntMap[3] = 1; break;
            case MIRROR_V: ntMap[0] = 0; ntMap[1] = 1; ntMap[2] = 0; ntMap[3] = 1; break;
            case MIRROR_SINGLE0: ntMap[0] = 0; ntMap[1] = 0; ntMap[2] = 0; ntMap[3] = 0; break;
            case MIRROR_SINGLE1: ntMap[0] = 1; ntMap[1] = 1; ntMap[2] = 1; ntMap[3] = 1; break;
            default: ntMap[0] = 0; ntMap[1] = 1; ntMap[2] = 2; ntMap[3] = 3; break;
        }
    }

    public int debugCtrl() { return ctrl; }

    public int debugMask() { return mask; }

    /** Level of the NMI output line. */
    public boolean nmiLine() { return vblank && (ctrl & 0x80) != 0; }

    // ---- memory ----------------------------------------------------------------------------

    private int ntRead(int addr) {
        if (mapper.watchA12) mapper.ppuBus(addr);
        return vram[(ntMap[(addr >> 10) & 3] << 10) | (addr & 0x3FF)] & 0xFF;
    }

    private static int palIndex(int addr) {
        int i = addr & 0x1F;
        if ((i & 0x13) == 0x10) i &= ~0x10;
        return i;
    }

    private int memRead(int addr) {
        addr &= 0x3FFF;
        if (addr < 0x2000) return mapper.ppuRead(addr);
        if (addr < 0x3F00) return vram[(ntMap[(addr >> 10) & 3] << 10) | (addr & 0x3FF)] & 0xFF;
        return pal[palIndex(addr)];
    }

    private void memWrite(int addr, int val) {
        addr &= 0x3FFF;
        if (addr < 0x2000) mapper.ppuWrite(addr, val);
        else if (addr < 0x3F00) vram[(ntMap[(addr >> 10) & 3] << 10) | (addr & 0x3FF)] = (byte) val;
        else pal[palIndex(addr)] = val & 0x3F;
    }

    // ---- CPU-visible registers ---------------------------------------------------------------

    public int readReg(int r) {
        switch (r & 7) {
            case 2: {
                int val = (vblank ? 0x80 : 0) | (spr0Hit ? 0x40 : 0) | (sprOverflow ? 0x20 : 0) | (ioBus & 0x1F);
                if (scanline == 241 && dot == 1) suppressVbl = true; // read one dot before the flag rises
                vblank = false;
                wLatch = false;
                ioBus = val;
                return val;
            }
            case 4: {
                int val = oam[oamAddr];
                if ((oamAddr & 3) == 2) val &= 0xE3;
                ioBus = val;
                return val;
            }
            case 7: {
                int a = v & 0x3FFF;
                int val;
                if (a >= 0x3F00) {
                    val = (pal[palIndex(a)] & ((mask & 1) != 0 ? 0x30 : 0x3F)) | (ioBus & 0xC0);
                    readBuf = memRead(a & 0x2FFF);
                } else {
                    val = readBuf;
                    readBuf = memRead(a);
                }
                v = (v + ((ctrl & 4) != 0 ? 32 : 1)) & 0x7FFF;
                ioBus = val;
                return val;
            }
            default:
                return ioBus;
        }
    }

    public void writeReg(int r, int val) {
        ioBus = val;
        switch (r & 7) {
            case 0:
                ctrl = val;
                t = (t & ~0x0C00) | ((val & 3) << 10);
                break;
            case 1:
                mask = val;
                break;
            case 3:
                oamAddr = val;
                break;
            case 4:
                oam[oamAddr] = val;
                oamAddr = (oamAddr + 1) & 0xFF;
                break;
            case 5:
                if (!wLatch) {
                    t = (t & ~0x001F) | (val >> 3);
                    fineX = val & 7;
                } else {
                    t = (t & ~0x73E0) | ((val & 7) << 12) | ((val >> 3) << 5);
                }
                wLatch = !wLatch;
                break;
            case 6:
                if (!wLatch) {
                    t = (t & 0x00FF) | ((val & 0x3F) << 8);
                } else {
                    t = (t & 0x7F00) | val;
                    v = t;
                }
                wLatch = !wLatch;
                break;
            case 7:
                memWrite(v, val);
                v = (v + ((ctrl & 4) != 0 ? 32 : 1)) & 0x7FFF;
                break;
            default:
                break;
        }
    }

    // ---- per-dot engine --------------------------------------------------------------------

    /** Advance the PPU by exactly one dot. */
    public void tick() {
        final int sl = scanline;
        final int d = dot;
        totalDots++;

        if (sl < 240 || sl == 261) {
            renderDot(sl, d);
        } else if (sl == 241 && d == 1) {
            if (suppressVbl) suppressVbl = false;
            else vblank = true;
            frameReady = true;
        }

        if (++dot > 340) {
            dot = 0;
            if (++scanline > 261) {
                scanline = 0;
                oddFrame = !oddFrame;
            }
        }
    }

    private void renderDot(int sl, int d) {
        final boolean rendering = (mask & 0x18) != 0;
        final boolean pre = sl == 261;

        if (pre && d == 1) {
            vblank = false;
            spr0Hit = false;
            sprOverflow = false;
        }

        if (rendering) {
            if ((d >= 2 && d <= 257) || (d >= 321 && d <= 337)) {
                updateShifters(d);
                switch ((d - 1) & 7) {
                    case 0:
                        loadBgShifters();
                        bgNextId = ntRead(0x2000 | (v & 0x0FFF));
                        break;
                    case 2: {
                        int a = 0x23C0 | (v & 0x0C00) | ((v >> 4) & 0x38) | ((v >> 2) & 0x07);
                        int at = ntRead(a);
                        if ((v & 0x40) != 0) at >>= 4;
                        if ((v & 0x02) != 0) at >>= 2;
                        bgNextAttr = at & 3;
                        break;
                    }
                    case 4:
                        bgNextLo = mapper.ppuRead(((ctrl & 0x10) << 8) + (bgNextId << 4) + ((v >> 12) & 7));
                        break;
                    case 6:
                        bgNextHi = mapper.ppuRead(((ctrl & 0x10) << 8) + (bgNextId << 4) + ((v >> 12) & 7) + 8);
                        break;
                    case 7:
                        incrementX();
                        break;
                    default:
                        break;
                }
            }
            if (d == 256) incrementY();
            if (d == 257) {
                loadBgShifters();
                v = (v & ~0x041F) | (t & 0x041F);
            }
            if (d == 338 || d == 340) bgNextId = ntRead(0x2000 | (v & 0x0FFF));
            if (pre && d >= 280 && d <= 304) v = (v & ~0x7BE0) | (t & 0x7BE0);
        }

        if (d == 257) {
            if (rendering && sl < 240) evaluateSprites(sl);
            else spriteCount = 0;
        }
        if (rendering && d >= 263 && d <= 319 && ((d - 263) & 7) == 0) fetchSprite((d - 263) >> 3, sl);

        if (sl < 240 && d >= 1 && d <= 256) {
            if (skipRender) skipPixel(d - 1);
            else outputPixel(sl, d - 1);
        }

        // odd frames skip the last dot of the pre-render line when rendering is on
        if (pre && d == 339 && oddFrame && rendering) dot++;
    }

    private void updateShifters(int d) {
        if ((mask & 0x08) != 0) {
            bgPatLo <<= 1;
            bgPatHi <<= 1;
            bgAttrLo <<= 1;
            bgAttrHi <<= 1;
        }
        if ((mask & 0x10) != 0 && d < 258) {
            for (int i = 0; i < spriteCount; i++) {
                if (sprX[i] > 0) {
                    sprX[i]--;
                } else {
                    sprLo[i] <<= 1;
                    sprHi[i] <<= 1;
                }
            }
        }
    }

    private void loadBgShifters() {
        bgPatLo = (bgPatLo & 0xFF00) | bgNextLo;
        bgPatHi = (bgPatHi & 0xFF00) | bgNextHi;
        bgAttrLo = (bgAttrLo & 0xFF00) | ((bgNextAttr & 1) != 0 ? 0xFF : 0);
        bgAttrHi = (bgAttrHi & 0xFF00) | ((bgNextAttr & 2) != 0 ? 0xFF : 0);
    }

    private void incrementX() {
        if ((v & 0x001F) == 31) {
            v &= ~0x001F;
            v ^= 0x0400;
        } else {
            v++;
        }
    }

    private void incrementY() {
        if ((v & 0x7000) != 0x7000) {
            v += 0x1000;
        } else {
            v &= ~0x7000;
            int y = (v & 0x03E0) >> 5;
            if (y == 29) {
                y = 0;
                v ^= 0x0800;
            } else if (y == 31) {
                y = 0;
            } else {
                y++;
            }
            v = (v & ~0x03E0) | (y << 5);
        }
    }

    private void evaluateSprites(int sl) {
        spriteCount = 0;
        spr0Possible = false;
        final int height = (ctrl & 0x20) != 0 ? 16 : 8;
        int found = 0;
        for (int n = 0; n < 64; n++) {
            int diff = sl - oam[n * 4];
            if (diff >= 0 && diff < height) {
                if (found < 8) {
                    int b = found * 4;
                    sec[b] = oam[n * 4];
                    sec[b + 1] = oam[n * 4 + 1];
                    sec[b + 2] = oam[n * 4 + 2];
                    sec[b + 3] = oam[n * 4 + 3];
                    if (n == 0) spr0Possible = true;
                } else {
                    sprOverflow = true;
                    break;
                }
                found++;
            }
        }
        spriteCount = Math.min(found, 8);
    }

    private static int reverse(int b) {
        b = ((b & 0xF0) >> 4) | ((b & 0x0F) << 4);
        b = ((b & 0xCC) >> 2) | ((b & 0x33) << 2);
        b = ((b & 0xAA) >> 1) | ((b & 0x55) << 1);
        return b;
    }

    private void fetchSprite(int i, int sl) {
        final boolean tall = (ctrl & 0x20) != 0;
        if (i < spriteCount) {
            int y = sec[i * 4], tile = sec[i * 4 + 1], attr = sec[i * 4 + 2], x = sec[i * 4 + 3];
            int row = sl - y;
            int addr;
            if (!tall) {
                if ((attr & 0x80) != 0) row = 7 - row;
                addr = ((ctrl & 0x08) << 9) | (tile << 4) | row;
            } else {
                if ((attr & 0x80) != 0) row = 15 - row;
                addr = ((tile & 1) << 12) + ((tile & 0xFE) << 4) + ((row & 8) << 1) + (row & 7);
            }
            int lo = mapper.ppuRead(addr);
            int hi = mapper.ppuRead(addr + 8);
            if ((attr & 0x40) != 0) {
                lo = reverse(lo);
                hi = reverse(hi);
            }
            sprLo[i] = lo;
            sprHi[i] = hi;
            sprAttr[i] = attr;
            sprX[i] = x;
        } else {
            mapper.ppuRead(tall ? 0x1FF0 : (((ctrl & 0x08) << 9) | 0x0FF0));
            mapper.ppuRead(tall ? 0x1FF8 : (((ctrl & 0x08) << 9) | 0x0FF8));
        }
    }

    /** Cheap path used while fast-forwarding: only tracks the sprite 0 hit. */
    private void skipPixel(int x) {
        if (spriteCount == 0 || !spr0Possible || spr0Hit || x == 255 || (mask & 0x18) != 0x18) return;
        if (sprX[0] != 0 || (x < 8 && (mask & 0x06) != 0x06)) return;
        int fg = (((sprHi[0] >> 7) & 1) << 1) | ((sprLo[0] >> 7) & 1);
        if (fg == 0) return;
        int bit = 15 - fineX;
        int bg = (((bgPatHi >> bit) & 1) << 1) | ((bgPatLo >> bit) & 1);
        if (bg != 0) {
            spr0Hit = true;
            lastSpr0HitDot = totalDots;
        }
    }

    private void outputPixel(int sl, int x) {
        int bgPixel = 0, bgPal = 0;
        if ((mask & 0x08) != 0 && (x >= 8 || (mask & 0x02) != 0)) {
            int bit = 15 - fineX;
            bgPixel = (((bgPatHi >> bit) & 1) << 1) | ((bgPatLo >> bit) & 1);
            bgPal = (((bgAttrHi >> bit) & 1) << 1) | ((bgAttrLo >> bit) & 1);
        }

        int fgPixel = 0, fgPal = 0;
        boolean fgPriority = false, spr0Rendered = false;
        if ((mask & 0x10) != 0 && (x >= 8 || (mask & 0x04) != 0)) {
            for (int i = 0; i < spriteCount; i++) {
                if (sprX[i] == 0) {
                    int p = (((sprHi[i] >> 7) & 1) << 1) | ((sprLo[i] >> 7) & 1);
                    if (p != 0) {
                        fgPixel = p;
                        fgPal = (sprAttr[i] & 3) + 4;
                        fgPriority = (sprAttr[i] & 0x20) == 0;
                        if (i == 0 && spr0Possible) spr0Rendered = true;
                        break;
                    }
                }
            }
        }

        int pixel, palette;
        if (bgPixel == 0 && fgPixel == 0) {
            pixel = 0;
            palette = 0;
        } else if (bgPixel == 0) {
            pixel = fgPixel;
            palette = fgPal;
        } else if (fgPixel == 0) {
            pixel = bgPixel;
            palette = bgPal;
        } else {
            if (fgPriority) {
                pixel = fgPixel;
                palette = fgPal;
            } else {
                pixel = bgPixel;
                palette = bgPal;
            }
            if (spr0Rendered && x != 255 && (mask & 0x18) == 0x18) {
                if (!spr0Hit) lastSpr0HitDot = totalDots;
                spr0Hit = true;
            }
        }

        int c = pal[pixel == 0 ? 0 : ((palette << 2) | pixel)];
        if ((mask & 1) != 0) c &= 0x30;
        frame[sl * WIDTH + x] = colors[(mask >> 5) & 7][c & 0x3F];
    }
}
