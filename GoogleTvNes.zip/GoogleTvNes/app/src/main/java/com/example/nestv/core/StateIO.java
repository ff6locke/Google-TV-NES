package com.example.nestv.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Reflection based object-graph serializer used for savestates. Walks every non-static,
 * non-transient field (sorted by name, superclass first). Final primitives are configuration and
 * are skipped; final arrays and nested objects are restored in place.
 */
final class StateIO {
    private StateIO() {}

    private static List<Field> fields(Class<?> c) {
        List<Class<?>> chain = new ArrayList<>();
        for (Class<?> k = c; k != null && k != Object.class; k = k.getSuperclass()) chain.add(0, k);
        List<Field> out = new ArrayList<>();
        for (Class<?> k : chain) {
            Field[] fs = k.getDeclaredFields();
            Arrays.sort(fs, new Comparator<Field>() {
                @Override public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            for (Field f : fs) {
                int m = f.getModifiers();
                if (Modifier.isStatic(m) || Modifier.isTransient(m) || f.isSynthetic()) continue;
                if (f.getType().isPrimitive() && Modifier.isFinal(m)) continue;
                f.setAccessible(true);
                out.add(f);
            }
        }
        return out;
    }

    static void write(DataOutputStream o, Object obj) throws IOException {
        try {
            for (Field f : fields(obj.getClass())) {
                Class<?> t = f.getType();
                if (t == int.class) o.writeInt(f.getInt(obj));
                else if (t == boolean.class) o.writeBoolean(f.getBoolean(obj));
                else if (t == long.class) o.writeLong(f.getLong(obj));
                else if (t == float.class) o.writeFloat(f.getFloat(obj));
                else if (t == short.class) o.writeShort(f.getShort(obj));
                else if (t == byte.class) o.writeByte(f.getByte(obj));
                else if (t == int[].class) {
                    int[] a = (int[]) f.get(obj);
                    o.writeInt(a.length);
                    for (int v : a) o.writeInt(v);
                } else if (t == byte[].class) {
                    byte[] a = (byte[]) f.get(obj);
                    o.writeInt(a.length);
                    o.write(a);
                } else if (t == short[].class) {
                    short[] a = (short[]) f.get(obj);
                    o.writeInt(a.length);
                    for (short v : a) o.writeShort(v);
                } else if (t.isArray() || t.isPrimitive()) {
                    throw new IllegalStateException("Unsupported state field " + f);
                } else {
                    Object v = f.get(obj);
                    o.writeBoolean(v != null);
                    if (v != null) write(o, v);
                }
            }
        } catch (IllegalAccessException e) {
            throw new IOException(e);
        }
    }

    static void read(DataInputStream in, Object obj) throws IOException {
        try {
            for (Field f : fields(obj.getClass())) {
                Class<?> t = f.getType();
                if (t == int.class) f.setInt(obj, in.readInt());
                else if (t == boolean.class) f.setBoolean(obj, in.readBoolean());
                else if (t == long.class) f.setLong(obj, in.readLong());
                else if (t == float.class) f.setFloat(obj, in.readFloat());
                else if (t == short.class) f.setShort(obj, in.readShort());
                else if (t == byte.class) f.setByte(obj, in.readByte());
                else if (t == int[].class) {
                    int[] a = (int[]) f.get(obj);
                    if (in.readInt() != a.length) throw new IOException("State size mismatch: " + f.getName());
                    for (int i = 0; i < a.length; i++) a[i] = in.readInt();
                } else if (t == byte[].class) {
                    byte[] a = (byte[]) f.get(obj);
                    if (in.readInt() != a.length) throw new IOException("State size mismatch: " + f.getName());
                    in.readFully(a);
                } else if (t == short[].class) {
                    short[] a = (short[]) f.get(obj);
                    if (in.readInt() != a.length) throw new IOException("State size mismatch: " + f.getName());
                    for (int i = 0; i < a.length; i++) a[i] = in.readShort();
                } else {
                    boolean present = in.readBoolean();
                    Object v = f.get(obj);
                    if (present != (v != null)) throw new IOException("State mismatch: " + f.getName());
                    if (present) read(in, v);
                }
            }
        } catch (IllegalAccessException e) {
            throw new IOException(e);
        }
    }
}
