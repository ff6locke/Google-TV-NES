package com.example.nestv.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Headless self-test for the emulator core (no ROM files needed).
 * Build/run (from project root):
 *   javac -d /tmp/out app/src/main/java/com/example/nestv/core/*.java core-test/CoreTest.java
 *   java -cp /tmp/out com.example.nestv.core.CoreTest
 */
public final class CoreTest {
    static int failures;

    static void check(String name, boolean ok, String detail) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + name + (detail.isEmpty() ? "" : "  [" + detail + "]"));
        if (!ok) failures++;
    }

    // ---- tiny 6502 assembler -------------------------------------------------------------------
    static final class Asm {
        final int org;
        final List<Integer> out = new ArrayList<>();
        final Map<String, Integer> labels = new HashMap<>();
        final List<Object[]> fix = new ArrayList<>();

        Asm(int org) { this.org = org; }

        Asm b(int... v) { for (int x : v) out.add(x & 0xFF); return this; }

        Asm label(String n) { labels.put(n, org + out.size()); return this; }

        Asm br(int op, String l) { b(op); fix.add(new Object[]{out.size(), l, 0}); b(0); return this; }

        Asm abs(int op, String l) { b(op); fix.add(new Object[]{out.size(), l, 1}); b(0, 0); return this; }

        int addr(String l) { return labels.get(l); }

        byte[] bytes() {
            for (Object[] f : fix) {
                int pos = (Integer) f[0];
                int target = labels.get((String) f[1]);
                if ((Integer) f[2] == 0) {
                    int rel = target - (org + pos + 1);
                    if (rel < -128 || rel > 127) throw new RuntimeException("branch out of range " + f[1]);
                    out.set(pos, rel & 0xFF);
                } else {
                    out.set(pos, target & 0xFF);
                    out.set(pos + 1, (target >> 8) & 0xFF);
                }
            }
            byte[] r = new byte[out.size()];
            for (int i = 0; i < r.length; i++) r[i] = (byte) (int) out.get(i);
            return r;
        }
    }

    static byte[] chr() {
        byte[] c = new byte[0x2000];
        for (int i = 0; i < 8; i++) c[16 + i] = (byte) 0xFF; // tile 1: solid colour 1
        return c;
    }

    /** 128 KB PRG, 8 KB CHR; program at $C000 of the last bank. */
    static byte[] rom(int mapper, Asm a, String nmi, String irq) {
        byte[] code = a.bytes();
        int prgSize = 8 * 0x4000;
        byte[] r = new byte[16 + prgSize + 0x2000];
        r[0] = 'N'; r[1] = 'E'; r[2] = 'S'; r[3] = 0x1A;
        r[4] = 8; r[5] = 1;
        r[6] = (byte) ((mapper & 0x0F) << 4);
        r[7] = (byte) (mapper & 0xF0);
        int base = 16 + 7 * 0x4000;
        System.arraycopy(code, 0, r, base, code.length);
        int nmiA = nmi == null ? 0xC000 : a.addr(nmi);
        int irqA = irq == null ? 0xC000 : a.addr(irq);
        r[base + 0x3FFA] = (byte) nmiA; r[base + 0x3FFB] = (byte) (nmiA >> 8);
        r[base + 0x3FFC] = 0x00;        r[base + 0x3FFD] = (byte) 0xC0;
        r[base + 0x3FFE] = (byte) irqA; r[base + 0x3FFF] = (byte) (irqA >> 8);
        System.arraycopy(chr(), 0, r, 16 + prgSize, 0x2000);
        return r;
    }

    // ---- tests ---------------------------------------------------------------------------------

    static void testCpu() throws Exception {
        Asm a = new Asm(0xC000);
        a.b(0x78, 0xD8, 0xA2, 0xFF, 0x9A);                 // SEI CLD LDX #$FF TXS
        a.b(0xA9, 0x00, 0x85, 0x00, 0xA2, 0x0A);           // sum = 0; X = 10
        a.label("loop").b(0x8A, 0x18, 0x65, 0x00, 0x85, 0x00, 0xCA).br(0xD0, "loop"); // sum += X
        a.abs(0x20, "sub");                                // JSR sub  -> $01 = $42
        a.b(0xA9, 0x03, 0x85, 0x10, 0xA9, 0x03, 0x85, 0x11); // ptr $10 -> $0303
        a.b(0xA0, 0x02, 0xA9, 0x77, 0x91, 0x10);           // LDY #2; LDA #$77; STA ($10),Y -> $0305
        a.b(0xAD, 0x05, 0x03, 0x85, 0x02);                 // LDA $0305; STA $02
        a.b(0x38, 0xA9, 0x50, 0xE9, 0x10, 0x85, 0x03);     // SEC LDA #$50 SBC #$10 STA $03 ($40)
        a.b(0xA9, 0x81, 0x0A, 0x2A, 0x85, 0x04);           // ASL A; ROL A -> 5 ; STA $04
        a.b(0xA9, 0xC0, 0xC9, 0xC0, 0xF0, 0x02, 0xA9, 0x00, 0x85, 0x05); // CMP eq -> $05 stays $C0
        a.b(0xA2, 0x05, 0xBD, 0x00, 0x03, 0x8D, 0x00, 0x03); // (zero page X etc. smoke)
        a.b(0xA9, 0x55, 0x48, 0xA9, 0x00, 0x68, 0x85, 0x06); // PHA / PLA -> $06 = $55
        a.b(0xE6, 0x07, 0xE6, 0x07, 0xC6, 0x07, 0xC6, 0x08); // INC INC DEC -> $07=1 ; DEC $08 -> $FF
        a.label("end").abs(0x4C, "end");
        a.label("sub").b(0xA9, 0x42, 0x85, 0x01, 0x60);
        Nes nes = new Nes(rom(16, a, null, null), 48000);
        for (int i = 0; i < 200; i++) nes.cpu.step();
        Cpu c = nes.cpu;
        check("CPU sum 1..10 via loop", c.peek(0) == 55, "got " + c.peek(0));
        check("CPU JSR/RTS", c.peek(1) == 0x42, "got " + c.peek(1));
        check("CPU (zp),Y store/load", c.peek(2) == 0x77, "got " + c.peek(2));
        check("CPU SBC", c.peek(3) == 0x40, "got " + c.peek(3));
        check("CPU ASL/ROL carry chain", c.peek(4) == 5, "got " + c.peek(4));
        check("CPU CMP/BEQ", c.peek(5) == 0 || c.peek(5) == 0xC0, "got " + c.peek(5));
        check("CPU PHA/PLA", c.peek(6) == 0x55, "got " + c.peek(6));
        check("CPU INC/DEC zp", c.peek(7) == 1 && c.peek(8) == 0xFF, "got " + c.peek(7) + "," + c.peek(8));
    }

    /** Program shared by the PPU/raster tests: fills nametable 0, enables rendering, optional NMI+IRQ split. */
    static Asm renderProgram(boolean stripes, boolean split, int irqCycles) {
        Asm a = new Asm(0xC000);
        a.b(0x78, 0xD8, 0xA2, 0xFF, 0x9A, 0xA9, 0x40, 0x8D, 0x17, 0x40);
        a.label("w1").b(0x2C, 0x02, 0x20).br(0x10, "w1");
        a.label("w2").b(0x2C, 0x02, 0x20).br(0x10, "w2");
        a.b(0xA9, 0x3F, 0x8D, 0x06, 0x20, 0xA9, 0x00, 0x8D, 0x06, 0x20, 0xA2, 0x00);
        a.label("pl").abs(0xBD, "pal").b(0x8D, 0x07, 0x20, 0xE8, 0xE0, 0x20).br(0xD0, "pl");
        a.b(0xA9, 0x20, 0x8D, 0x06, 0x20, 0xA9, 0x00, 0x8D, 0x06, 0x20, 0xA0, 0x02);
        a.label("o").b(0xA2, 0x00);
        a.label("i");
        a.b(0xA9, 0x01, 0x8D, 0x07, 0x20);
        a.b(0xA9, stripes ? 0x00 : 0x01, 0x8D, 0x07, 0x20);
        a.b(0xE8).br(0xD0, "i");
        a.b(0x88).br(0xD0, "o");
        a.b(0xA9, 0x00, 0x8D, 0x05, 0x20, 0x8D, 0x05, 0x20);
        if (split) a.b(0xA9, 0x80, 0x8D, 0x00, 0x20);
        a.b(0xA9, 0x1E, 0x8D, 0x01, 0x20);
        if (split) a.b(0x58);
        a.label("forever").abs(0x4C, "forever");
        a.label("pal");
        for (int i = 0; i < 8; i++) a.b(0x0F, 0x30, 0x30, 0x30);
        a.label("nmi");
        a.b(0xA9, 0x00, 0x8D, 0x05, 0x20, 0x8D, 0x05, 0x20);   // reset scroll every frame
        a.b(0xA9, irqCycles & 0xFF, 0x8D, 0x0B, 0x80, 0xA9, (irqCycles >> 8) & 0xFF, 0x8D, 0x0C, 0x80,
                0xA9, 0x01, 0x8D, 0x0A, 0x80, 0x40);
        a.label("irq");
        a.b(0xA9, 0x00, 0x8D, 0x0A, 0x80);                 // ack + disable
        a.b(0xA9, 0x04, 0x8D, 0x05, 0x20, 0xA9, 0x00, 0x8D, 0x05, 0x20); // scroll X = 4
        a.b(0x40);
        return a;
    }

    static void testPpuAndSpeed() throws Exception {
        Nes nes = new Nes(rom(16, renderProgram(false, false, 0), "nmi", "irq"), 48000);
        for (int i = 0; i < 6; i++) nes.runFrame();
        int white = 0xFF000000 | 0xFFFEFF;
        boolean all = true;
        for (int p : nes.ppu.frame) if (p != white) { all = false; break; }
        check("PPU renders solid tile frame (all white)", all, "pixel(100,100)=" + Integer.toHexString(nes.ppu.frame[100 * 256 + 100]));

        long c0 = nes.cpu.cycles;
        int n = 600;
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) { nes.runFrame(); nes.apu.sampleCount = 0; }
        double secs = (System.nanoTime() - t0) / 1e9;
        double cpf = (nes.cpu.cycles - c0) / (double) n;
        check("Frame length ~29780.5 CPU cycles", Math.abs(cpf - 29780.5) < 1.0, String.format("%.2f", cpf));
        check("Speed >= 120 fps headless", n / secs >= 120, String.format("%.0f fps on this machine", n / secs));
    }

    static void testSplitStable() throws Exception {
        int target = 100;
        int cycles = (int) ((21 + target) * 113.667) - 55;
        Nes nes = new Nes(rom(16, renderProgram(true, true, cycles), "nmi", "irq"), 48000);
        for (int i = 0; i < 4; i++) nes.runFrame();
        int first = -1;
        boolean stable = true;
        for (int f = 0; f < 12; f++) {
            nes.runFrame();
            int[] fr = nes.ppu.frame;
            int split = -1;
            for (int y = 1; y < 240 && split < 0; y++) {
                for (int x = 0; x < 256; x++) {
                    if (fr[y * 256 + x] != fr[x]) { split = y; break; }
                }
            }
            if (f == 0) first = split;
            else if (split != first) stable = false;
        }
        check("Mapper-16 IRQ raster split lands near line " + target, first >= target - 3 && first <= target + 3, "split at line " + first);
        check("Raster split identical on every frame (no shaking)", stable, "");
    }

    // ---- EEPROM through the mapper registers -------------------------------------------------
    static Mapper mapper;

    static void pins(int scl, int sda) { mapper.cpuWrite(0x800D, (scl << 5) | (sda << 6)); }

    static void start() { pins(0, 1); pins(1, 1); pins(1, 0); pins(0, 0); }

    static void stop() { pins(0, 0); pins(1, 0); pins(1, 1); }

    static int sendByte(int v) {
        for (int i = 7; i >= 0; i--) { int bit = (v >> i) & 1; pins(0, bit); pins(1, bit); pins(0, bit); }
        pins(0, 1); pins(1, 1);
        int ack = (mapper.cpuRead(0x6000) >> 4) & 1;
        pins(0, 1);
        return ack;
    }

    static int recvByte(boolean ack) {
        int v = 0;
        for (int i = 0; i < 8; i++) {
            pins(0, 1); pins(1, 1);
            v = (v << 1) | ((mapper.cpuRead(0x6000) >> 4) & 1);
            pins(0, 1);
        }
        int s = ack ? 0 : 1;
        pins(0, s); pins(1, s); pins(0, s);
        return v;
    }

    static void testEeprom() throws Exception {
        Asm a = new Asm(0xC000);
        a.label("e").abs(0x4C, "e");
        // 24C02 (mapper 16)
        Nes nes = new Nes(rom(16, a, null, null), 48000);
        mapper = nes.mapper;
        start();
        int a1 = sendByte(0xA0), a2 = sendByte(0x10), a3 = sendByte(0x5A), a4 = sendByte(0x6B);
        stop();
        check("24C02 write acks", a1 == 0 && a2 == 0 && a3 == 0 && a4 == 0, a1 + "" + a2 + a3 + a4);
        start(); sendByte(0xA0); sendByte(0x10); start();
        int r1 = sendByte(0xA1);
        int d1 = recvByte(true), d2 = recvByte(false);
        stop();
        check("24C02 read back written bytes", r1 == 0 && d1 == 0x5A && d2 == 0x6B, Integer.toHexString(d1) + " " + Integer.toHexString(d2));
        byte[] save = nes.getSaveData();
        check("EEPROM save data + generation updated", save != null && (save[0x10] & 0xFF) == 0x5A && nes.saveGeneration() > 0, "gen=" + nes.saveGeneration());
        Nes nes2 = new Nes(rom(16, a, null, null), 48000);
        nes2.loadSave(save);
        mapper = nes2.mapper;
        start(); sendByte(0xA0); sendByte(0x11); start(); sendByte(0xA1);
        int d = recvByte(false); stop();
        check("Save reload into fresh console", d == 0x6B, Integer.toHexString(d));

        // 24C01 (mapper 159)
        Nes n3 = new Nes(rom(159, a, null, null), 48000);
        mapper = n3.mapper;
        start(); int b1 = sendByte(0x20), b2 = sendByte(0x33); stop();
        start(); int b3 = sendByte(0x21); int e = recvByte(false); stop();
        // mapper 16 header + a 24C01-style game: chip type must be detected automatically
        Nes n4 = new Nes(rom(16, a, null, null), 48000);
        mapper = n4.mapper;
        start(); int c1 = sendByte(0x20), c2 = sendByte(0x44); stop();
        start(); int c3 = sendByte(0x21); int f = recvByte(false); stop();
        check("Mapper 16 auto-detects a 24C01 game", c1 == 0 && c2 == 0 && c3 == 0 && f == 0x44 && n4.getSaveData().length == 128, Integer.toHexString(f));
        check("24C01 write/read (mapper 159)", b1 == 0 && b2 == 0 && b3 == 0 && e == 0x33, Integer.toHexString(e));
    }

    static void testIrqTiming() throws Exception {
        Asm a = new Asm(0xC000);
        a.b(0x78, 0xD8, 0xA2, 0xFF, 0x9A, 0xA9, 0x40, 0x8D, 0x17, 0x40);
        a.b(0xA9, 0xE8, 0x8D, 0x0B, 0x80, 0xA9, 0x03, 0x8D, 0x0C, 0x80); // latch = 1000
        a.b(0xA9, 0x01, 0x8D, 0x0A, 0x80);
        a.label("cli").b(0x58);
        a.label("f").abs(0x4C, "f");
        a.label("irq").b(0xA9, 0x00, 0x8D, 0x0A, 0x80, 0xE6, 0x20, 0x40);
        Nes nes = new Nes(rom(16, a, null, "irq"), 48000);
        long t0 = -1, t1 = -1;
        for (int i = 0; i < 2000 && t1 < 0; i++) {
            nes.cpu.step();
            if (t0 < 0 && nes.cpu.getPc() == a.addr("cli")) t0 = nes.cpu.cycles; // right after STA $800A
            if (nes.cpu.peek(0x20) != 0) t1 = nes.cpu.cycles;
        }
        long d = t1 - t0;
        check("Bandai LZ93D50 IRQ fires ~latch cycles after enable (+ IRQ entry)", t0 > 0 && d >= 1000 && d <= 1030, "delta=" + d);
    }

    static void testApu() throws Exception {
        Asm a = new Asm(0xC000);
        a.b(0x78, 0xD8, 0xA2, 0xFF, 0x9A);
        a.b(0xA9, 0x01, 0x8D, 0x15, 0x40, 0xA9, 0xBF, 0x8D, 0x00, 0x40, 0xA9, 0xFD, 0x8D, 0x02, 0x40, 0xA9, 0x00, 0x8D, 0x03, 0x40);
        a.label("f").abs(0x4C, "f");
        Nes nes = new Nes(rom(16, a, null, null), 48000);
        int total = 0, cross = 0, prev = 0, peak = 0;
        for (int f = 0; f < 60; f++) {
            nes.runFrame();
            for (int i = 0; i < nes.apu.sampleCount; i++) {
                int s = nes.apu.samples[i];
                if (f > 5) { if ((s > 0) != (prev > 0)) cross++; peak = Math.max(peak, Math.abs(s)); total++; }
                prev = s;
            }
            nes.apu.sampleCount = 0;
        }
        double secs = total / 48000.0;
        double hz = cross / 2.0 / secs;
        check("APU pulse ~440 Hz tone", hz > 400 && hz < 480 && peak > 1000, String.format("%.1f Hz, peak %d", hz, peak));
        check("APU produces ~48000 samples/s", Math.abs(total / secs - 48000) < 100, String.format("%.0f", total / secs));
    }

    static long hash(int[] f) { long h = 1469598103934665603L; for (int v : f) { h ^= v; h *= 1099511628211L; } return h; }

    static void testStates() throws Exception {
        int cycles = (int) ((21 + 100) * 113.667) - 55;
        byte[] r = rom(16, renderProgram(true, true, cycles), "nmi", "irq");
        Nes a = new Nes(r, 48000);
        for (int i = 0; i < 8; i++) a.runFrame();
        mapper = a.mapper;
        // write something into the EEPROM so it is part of the state
        start(); sendByte(0xA0); sendByte(0x20); sendByte(0x99); stop();
        byte[] st = a.saveState();
        long[] h1 = new long[10]; long c1;
        for (int i = 0; i < 10; i++) { a.runFrame(); h1[i] = hash(a.ppu.frame); }
        c1 = a.cpu.cycles;
        // overwrite EEPROM after the snapshot, then restore
        mapper = a.mapper; start(); sendByte(0xA0); sendByte(0x20); sendByte(0x11); stop();
        a.loadState(st);
        boolean same = true;
        for (int i = 0; i < 10; i++) { a.runFrame(); if (hash(a.ppu.frame) != h1[i]) same = false; }
        check("Savestate replay is frame-exact for 10 frames", same && a.cpu.cycles == c1, "state=" + st.length + " bytes");
        check("Savestate restores EEPROM contents", (a.getSaveData()[0x20] & 0xFF) == 0x99, Integer.toHexString(a.getSaveData()[0x20] & 0xFF));
        // load into a brand new console of the same ROM
        Nes b = new Nes(r, 48000);
        b.loadState(st);
        boolean same2 = true;
        for (int i = 0; i < 10; i++) { b.runFrame(); if (hash(b.ppu.frame) != h1[i]) same2 = false; }
        check("Savestate loads into a fresh console", same2, "");
        boolean rejected = false;
        try { new Nes(rom(16, renderProgram(false, false, 0), "nmi", "irq"), 48000).loadState(st); } catch (java.io.IOException e) { rejected = true; }
        check("Savestate from another game is rejected", rejected, "");
    }

    public static void main(String[] args) throws Exception {
        testCpu();
        testEeprom();
        testIrqTiming();
        testPpuAndSpeed();
        testSplitStable();
        testApu();
        testStates();
        System.out.println(failures == 0 ? "ALL TESTS PASSED" : failures + " TEST(S) FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
