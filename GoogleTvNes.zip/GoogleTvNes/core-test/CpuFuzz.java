package com.example.nestv.core;

import java.util.Random;

/** Differential test: the real cycle-stepped CPU versus a small independent reference model. */
public final class CpuFuzz {
    static final class Ref {
        int a, x, y, sp, pc, c, z, i, d, v, n;
        final int[] m = new int[65536];
        long cyc;

        int rd(int ad) { return m[ad & 0xFFFF]; }
        void wr(int ad, int val) { m[ad & 0xFFFF] = val & 0xFF; }
        void nz(int val) { z = (val & 0xFF) == 0 ? 1 : 0; n = (val >> 7) & 1; }
        int p() { return c | z << 1 | i << 2 | d << 3 | 0x20 | v << 6 | n << 7; }
        void setP(int q) { c = q & 1; z = (q >> 1) & 1; i = (q >> 2) & 1; d = (q >> 3) & 1; v = (q >> 6) & 1; n = (q >> 7) & 1; }
        void push(int val) { wr(0x100 + sp, val); sp = (sp - 1) & 0xFF; }
        int pull() { sp = (sp + 1) & 0xFF; return rd(0x100 + sp); }
        void adc(int val) {
            int sum = a + val + c;
            c = sum > 0xFF ? 1 : 0;
            v = (((a ^ sum) & (val ^ sum) & 0x80) != 0) ? 1 : 0;
            a = sum & 0xFF;
            nz(a);
        }
        void cmp(int reg, int val) { c = reg >= val ? 1 : 0; nz((reg - val) & 0xFF); }
        int shift(int kind, int val) {
            int r;
            switch (kind) {
                case 0: c = val >> 7; r = (val << 1) & 0xFF; break;
                case 1: { int oc = c; c = val >> 7; r = ((val << 1) | oc) & 0xFF; break; }
                case 2: c = val & 1; r = val >> 1; break;
                default: { int oc = c; c = val & 1; r = (val >> 1) | (oc << 7); break; }
            }
            nz(r);
            return r;
        }

        void step() {
            int op = rd(pc), b1 = rd(pc + 1), b2 = rd(pc + 2);
            int cc = op & 3, bbb = (op >> 2) & 7, aaa = op >> 5;
            if ((op & 0x1F) == 0x10) {
                int f = new int[]{n, v, c, z}[aaa >> 1];
                pc = (pc + 2) & 0xFFFF; cyc += 2;
                if (f == (aaa & 1)) {
                    int t = (pc + (byte) b1) & 0xFFFF;
                    cyc += 1 + (((t ^ pc) & 0xFF00) != 0 ? 1 : 0);
                    pc = t;
                }
                return;
            }
            switch (op) {
                case 0x20: { int r = (pc + 2) & 0xFFFF; push(r >> 8); push(r & 0xFF); pc = b1 | b2 << 8; cyc += 6; return; }
                case 0x60: { int lo = pull(), hi = pull(); pc = ((lo | hi << 8) + 1) & 0xFFFF; cyc += 6; return; }
                case 0x4C: pc = b1 | b2 << 8; cyc += 3; return;
                case 0x6C: { int ptr = b1 | b2 << 8; pc = rd(ptr) | rd((ptr & 0xFF00) | ((ptr + 1) & 0xFF)) << 8; cyc += 5; return; }
                case 0x08: push(p() | 0x10); pc++; cyc += 3; return;
                case 0x28: setP(pull()); pc++; cyc += 4; return;
                case 0x48: push(a); pc++; cyc += 3; return;
                case 0x68: a = pull(); nz(a); pc++; cyc += 4; return;
                default: break;
            }
            pc = (pc + 1) & 0xFFFF; // implied-type single byte ops
            switch (op) {
                case 0x88: y = (y - 1) & 0xFF; nz(y); cyc += 2; return;
                case 0xA8: y = a; nz(y); cyc += 2; return;
                case 0xC8: y = (y + 1) & 0xFF; nz(y); cyc += 2; return;
                case 0xE8: x = (x + 1) & 0xFF; nz(x); cyc += 2; return;
                case 0x18: c = 0; cyc += 2; return;
                case 0x38: c = 1; cyc += 2; return;
                case 0x58: i = 0; cyc += 2; return;
                case 0x78: i = 1; cyc += 2; return;
                case 0x98: a = y; nz(a); cyc += 2; return;
                case 0xB8: v = 0; cyc += 2; return;
                case 0xD8: d = 0; cyc += 2; return;
                case 0xF8: d = 1; cyc += 2; return;
                case 0x8A: a = x; nz(a); cyc += 2; return;
                case 0xAA: x = a; nz(x); cyc += 2; return;
                case 0xCA: x = (x - 1) & 0xFF; nz(x); cyc += 2; return;
                case 0x9A: sp = x; cyc += 2; return;
                case 0xBA: x = sp; nz(x); cyc += 2; return;
                case 0xEA: cyc += 2; return;
                case 0x0A: a = shift(0, a); cyc += 2; return;
                case 0x2A: a = shift(1, a); cyc += 2; return;
                case 0x4A: a = shift(2, a); cyc += 2; return;
                case 0x6A: a = shift(3, a); cyc += 2; return;
                default: break;
            }
            pc = (pc - 1) & 0xFFFF;
            // addressing
            int mode; // 0 indX 1 zp 2 imm 3 abs 4 indY 5 zpX 6 absY 7 absX 8 zpY
            if (cc == 1) mode = bbb;
            else if (cc == 2) mode = bbb == 0 ? 2 : bbb == 1 ? 1 : bbb == 3 ? 3 : bbb == 5 ? ((aaa == 4 || aaa == 5) ? 8 : 5) : (aaa == 5 ? 6 : 7);
            else mode = bbb == 0 ? 2 : bbb == 1 ? 1 : bbb == 3 ? 3 : bbb == 5 ? 5 : 7;
            int len = (mode == 3 || mode == 6 || mode == 7) ? 3 : 2;
            int ea = 0, cross = 0;
            switch (mode) {
                case 0: { int zz = (b1 + x) & 0xFF; ea = rd(zz) | rd((zz + 1) & 0xFF) << 8; break; }
                case 1: ea = b1; break;
                case 2: ea = (pc + 1) & 0xFFFF; break;
                case 3: ea = b1 | b2 << 8; break;
                case 4: { int base = rd(b1) | rd((b1 + 1) & 0xFF) << 8; ea = (base + y) & 0xFFFF; cross = (base & 0xFF00) != (ea & 0xFF00) ? 1 : 0; break; }
                case 5: ea = (b1 + x) & 0xFF; break;
                case 6: { int base = b1 | b2 << 8; ea = (base + y) & 0xFFFF; cross = (base & 0xFF00) != (ea & 0xFF00) ? 1 : 0; break; }
                case 7: { int base = b1 | b2 << 8; ea = (base + x) & 0xFFFF; cross = (base & 0xFF00) != (ea & 0xFF00) ? 1 : 0; break; }
                default: ea = (b1 + y) & 0xFF; break;
            }
            int[] readBase = {6, 3, 2, 4, 5, 4, 4, 4, 4};
            int[] writeBase = {6, 3, 2, 4, 6, 4, 5, 5, 4};
            int[] rmwBase = {0, 5, 0, 6, 0, 6, 0, 7, 0};
            pc = (pc + len) & 0xFFFF;
            if (cc == 1) {
                if (aaa == 4) { wr(ea, a); cyc += writeBase[mode]; return; }
                int val = rd(ea);
                switch (aaa) {
                    case 0: a |= val; nz(a); break;
                    case 1: a &= val; nz(a); break;
                    case 2: a ^= val; nz(a); break;
                    case 3: adc(val); break;
                    case 5: a = val; nz(a); break;
                    case 6: cmp(a, val); break;
                    default: adc(val ^ 0xFF); break;
                }
                cyc += readBase[mode] + ((mode == 4 || mode == 6 || mode == 7) ? cross : 0);
            } else if (cc == 2) {
                if (aaa == 4) { wr(ea, x); cyc += writeBase[mode]; return; }
                if (aaa == 5) { x = rd(ea); nz(x); cyc += readBase[mode] + (mode == 6 ? cross : 0); return; }
                int val = rd(ea), r;
                if (aaa < 4) r = shift(aaa, val);
                else if (aaa == 6) { r = (val - 1) & 0xFF; nz(r); }
                else { r = (val + 1) & 0xFF; nz(r); }
                wr(ea, r);
                cyc += rmwBase[mode];
            } else {
                if (aaa == 4) { wr(ea, y); cyc += writeBase[mode]; return; }
                int val = rd(ea);
                switch (aaa) {
                    case 1: z = (a & val) == 0 ? 1 : 0; v = (val >> 6) & 1; n = (val >> 7) & 1; break;
                    case 5: y = val; nz(y); break;
                    case 6: cmp(y, val); break;
                    default: cmp(x, val); break;
                }
                cyc += readBase[mode] + (mode == 7 ? cross : 0);
            }
        }
    }

    static boolean official(int op) {
        int cc = op & 3, bbb = (op >> 2) & 7, aaa = op >> 5;
        if (op == 0x00 || op == 0x40) return false;                // BRK / RTI covered elsewhere
        if (cc == 3) return false;
        if (cc == 1) return op != 0x89;
        if (cc == 2) {
            if (bbb == 0) return aaa == 5;
            if (bbb == 4) return false;
            if (bbb == 6) return aaa == 4 || aaa == 5;
            if (bbb == 7) return aaa != 4;
            return true;
        }
        switch (bbb) {
            case 0: return aaa >= 4 ? aaa != 4 : aaa == 1;          // JSR, RTS only below
            case 1: return aaa == 1 || aaa >= 4;
            case 2: return true;
            case 3: return aaa >= 1;
            case 4: return true;
            case 5: return aaa == 4 || aaa == 5;
            case 6: return true;
            default: return aaa == 5;
        }
    }

    public static void main(String[] args) throws Exception {
        CoreTest.Asm a = new CoreTest.Asm(0xC000);
        a.label("e").abs(0x4C, "e");
        Nes nes = new Nes(CoreTest.rom(16, a, null, null), 48000);
        nes.apu.write(0x4017, 0x40);
        Cpu cpu = nes.cpu;
        int[] ops = new int[256]; int nops = 0;
        for (int op = 0; op < 256; op++) if (official(op)) ops[nops++] = op;
        ops[nops++] = 0x20; ops[nops++] = 0x60;
        Random r = new Random(1234);
        Ref ref = new Ref();
        int fails = 0, trials = 40000;
        boolean[] seen = new boolean[256];
        for (int t = 0; t < trials && fails < 8; t++) {
            int op = ops[r.nextInt(nops)];
            seen[op] = true;
            for (int i = 0; i < 0x800; i++) { int val = r.nextInt(256); cpu.poke(i, val); ref.m[i] = val; }
            int cc = op & 3, bbb = (op >> 2) & 7, aaa = op >> 5;
            int mode = op == 0x20 || op == 0x4C ? 3 : op == 0x6C ? 9 : op == 0x60 ? 10 : (cc == 1 ? bbb
                    : cc == 2 ? (bbb == 0 ? 2 : bbb == 1 ? 1 : bbb == 3 ? 3 : bbb == 5 ? ((aaa == 4 || aaa == 5) ? 8 : 5) : bbb == 7 ? (aaa == 5 ? 6 : 7) : 11)
                    : (bbb == 0 ? 2 : bbb == 1 ? 1 : bbb == 3 ? 3 : bbb == 5 ? 5 : bbb == 7 ? 7 : 11));
            int xr = r.nextInt(0x20), yr = r.nextInt(0x20);
            if (mode == 5 || mode == 8 || mode == 0) { xr = r.nextInt(256); }
            if (mode == 8) yr = r.nextInt(256);
            int b1 = r.nextInt(256), b2 = r.nextInt(256);
            if (mode == 3 || mode == 6 || mode == 7) { int ad = 0x200 + r.nextInt(0x5C0); if (op == 0x4C || op == 0x20) ad = r.nextInt(0x10000); b1 = ad & 0xFF; b2 = ad >> 8; }
            if (mode == 9) { int ad = 0x200 + r.nextInt(0x5C0); if (r.nextInt(4) == 0) ad |= 0xFF; b1 = ad & 0xFF; b2 = ad >> 8; }
            if (mode == 0) { int zz = (b1 + xr) & 0xFF; int ad = 0x200 + r.nextInt(0x500); cpu.poke(zz, ad & 0xFF); cpu.poke((zz + 1) & 0xFF, ad >> 8); ref.m[zz] = ad & 0xFF; ref.m[(zz + 1) & 0xFF] = ad >> 8; }
            if (mode == 4) { int ad = 0x200 + r.nextInt(0x5C0); cpu.poke(b1, ad & 0xFF); cpu.poke((b1 + 1) & 0xFF, ad >> 8); ref.m[b1] = ad & 0xFF; ref.m[(b1 + 1) & 0xFF] = ad >> 8; }
            int[] code = {op, b1, b2};
            for (int k = 0; k < 3; k++) { cpu.poke(0x300 + k, code[k]); ref.m[0x300 + k] = code[k]; }
            int av = r.nextInt(256), sp = r.nextInt(256), pf = (r.nextInt(256) | 0x04) & 0xCF | 0x20;
            if (op == 0x60) { int lo = r.nextInt(256), hi = r.nextInt(8); int s = (sp + 1) & 0xFF; int s2 = (sp + 2) & 0xFF; cpu.poke(0x100 + s, lo); cpu.poke(0x100 + s2, hi); ref.m[0x100 + s] = lo; ref.m[0x100 + s2] = hi; }
            if (op == 0x28) { /* PLP could clear I; keep both models identical anyway */ }
            cpu.debugSet(av, xr, yr, sp, 0x300, pf);
            ref.a = av; ref.x = xr; ref.y = yr; ref.sp = sp; ref.pc = 0x300; ref.setP(pf); ref.cyc = 0;
            long c0 = cpu.cycles;
            cpu.step();
            ref.step();
            int[] g = cpu.debugGet();
            int[] e = {ref.a, ref.x, ref.y, ref.sp, ref.pc, ref.p()};
            boolean bad = false;
            for (int k = 0; k < 6; k++) if (g[k] != e[k]) bad = true;
            long dc = cpu.cycles - c0;
            if (dc != ref.cyc) bad = true;
            for (int i = 0; i < 0x800 && !bad; i++) if (cpu.peek(i) != ref.m[i]) { bad = true; }
            if (bad) {
                fails++;
                System.out.printf("MISMATCH op=%02X (%02X %02X) in a=%02X x=%02X y=%02X sp=%02X p=%02X%n  cpu a=%02X x=%02X y=%02X sp=%02X pc=%04X p=%02X cyc=%d%n  ref a=%02X x=%02X y=%02X sp=%02X pc=%04X p=%02X cyc=%d%n",
                        op, b1, b2, av, xr, yr, sp, pf, g[0], g[1], g[2], g[3], g[4], g[5], dc, e[0], e[1], e[2], e[3], e[4], e[5], ref.cyc);
            }
        }
        int covered = 0; for (int op : ops) if (seen[op]) covered++;
        System.out.println(fails == 0 ? "CPU FUZZ PASSED (" + trials + " trials, " + covered + "/" + nops + " opcodes)" : "CPU FUZZ FAILED: " + fails);
    }
}
